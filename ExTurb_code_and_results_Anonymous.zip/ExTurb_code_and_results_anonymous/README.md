# ExTurb — extremal-statistics turbidity estimation

Code for the manuscript *"Extreme Value Gradient Statistics for Underwater Turbidity Estimation and Their Validation in Real Water"* submitted to *Measurement* (Elsevier).

Repository: the public link is withheld during double-blind review and will be given on acceptance.

## Files

| File | Purpose |
|---|---|
| `exturb.py` | The estimator (Algorithm 1): Weber-normalised gradient maxima, PWM GEV fit, `T_c`, probe ratio, `sigma_b` |
| `render.py` | Physically based underwater renderer (Jaffe–McGlamery, spectral IOPs, Poisson forward-scatter PSF, depth layering) |
| `deadleaves.py` | Dead-leaves scene generator (SynDL) |
| `baselines.py` | UCIQE, UIQM, DCP, UDCP, dynamic range, RMS contrast, Tenengrad, Laplacian variance, entropy, PCD |
| `datasets.py`, `build_sets.py` | Benchmark construction (BSDS-UW, KM-UW, Robust-UW, Range-UW) |
| `tune_syndl.py` | Parameter selection on SynDL only |
| `compute.py` | Runs every method on a set and caches scores |
| `cnn_baseline.py` | Supervised CNN-R baseline |
| `theory_exp.py` | Numerical checks of Propositions 1–3 and GEV adequacy |
| `ablation.py` | Ablation and sensitivity |
| `exposure_test.py` | Exposure-invariance test on real UIQS images |
| `plume_sim.py` | Dynamic AUV survey through an advection–diffusion sediment plume |
| `analysis.py`, `analysis2.py`, `stats_eval.py` | Tables, figures, bootstrap/Holm/Friedman statistics, LaTeX macros |
| `run_real_ntu.py` | Scores every method on TUB, MFT (and TURBID); reads `av_turbidity.csv` and `Multimodal Metadata.xlsx` automatically |
| `real_calib.py` | Train-only calibration (ExTurb-C), protocols P1–P3, paired bootstrap + Holm |
| `real_ref.py` | Scene-referenced estimation on TUB; split-conformal NTU intervals |
| `syn_revision.py` | Revision experiments: PSF-approximation error map, edge types, camera pipeline, full GEV ablation, conformal ĉ |
| `real_figs.py`, `make_rev_tex.py` | Revision figures, tables and LaTeX macros |
| `real_data/` | Per-image scores of all methods on TUB (1315), MFT Train (4320) and MFT Test (540), and derived results |

## Data used

* Clear scenes: BSDS500 (`github.com/BIDS/BSDS500`), Kodak24 and McMaster (test sets bundled in `github.com/cszn/FFDNet`).
* Real underwater: RUIE (`github.com/dlut-dimt/Realworld-Underwater-Image-Enhancement-RUIE-Benchmark`), U45 (`github.com/IPNUISTlegal/underwater-test-dataset-U45-`), EUVP samples (`github.com/xahidbuffon/FUnIE-GAN`, `data/test`).
* Measured-turbidity sets: TUB (`huggingface.co/datasets/vapaau/TUB`), MFT (IEEE Dataport doi:10.21227/gd5d-ns10; mirror `huggingface.co/datasets/mieraehh/5_Malaysian_Fish_Species_in_Turbid_Water`). TURBID (`amandaduarte.com.br/turbid`) was not obtained.

## Reproduce

```bash
pip install numpy scipy scikit-image scikit-learn matplotlib joblib pillow phasepack torch openpyxl
python tune_syndl.py                    # parameter selection (writes exturb_params.json)
python build_sets.py bsds; python build_sets.py km; python build_sets.py robust; python build_sets.py range
./pipeline.sh                           # scores, CNN, theory checks, ablation, sensitivity
python exposure_test.py
python plume_sim.py fixed; python plume_sim.py adaptive <target>
python analysis.py; python analysis2.py # tables, figures and paper/results_macros.tex
```
Paths at the top of some scripts point to the folders used during development; change them to your local folders.

## Run on real turbidimeter data

```bash
python run_real_ntu.py --tub_dir data/tub                         # NTU from av_turbidity.csv
python run_real_ntu.py --mft_dir data/mft --mft_split Train       # NTU from Multimodal Metadata.xlsx
python run_real_ntu.py --mft_dir data/mft --mft_split Test
python real_calib.py real_data; python real_ref.py real_data      # calibration, significance, intervals
```
Rename the MFT outputs to `MFT_train_scores.csv` and `MFT_test_scores.csv` after each split, as in `real_data/`.
