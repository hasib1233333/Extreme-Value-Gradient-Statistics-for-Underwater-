"""Evaluation statistics."""
import numpy as np
from scipy.optimize import curve_fit
from scipy.stats import kendalltau, pearsonr, spearmanr


def logistic4(x, b1, b2, b3, b4):
    return (b1 - b2) / (1 + np.exp(-(x - b3) / (np.abs(b4) + 1e-9))) + b2


def fit_logistic(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    p0 = [y.max(), y.min(), np.median(x), x.std() + 1e-6]
    try:
        p, _ = curve_fit(logistic4, x, y, p0=p0, maxfev=20000)
        return logistic4(x, *p)
    except Exception:
        a, b = np.polyfit(x, y, 1)
        return a * x + b


def corr_suite(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    yh = fit_logistic(x, y)
    return {
        "SROCC": spearmanr(x, y)[0],
        "KROCC": kendalltau(x, y)[0],
        "PLCC": pearsonr(yh, y)[0],
        "RMSE": float(np.sqrt(np.mean((yh - y) ** 2))),
    }


def cluster_bootstrap(x, y, groups, stat=lambda a, b: spearmanr(a, b)[0], B=1000, seed=0):
    rng = np.random.default_rng(seed)
    x, y, groups = map(np.asarray, (x, y, groups))
    ug = np.unique(groups)
    idx = {g: np.where(groups == g)[0] for g in ug}
    vals = []
    for _ in range(B):
        gs = rng.choice(ug, ug.size, replace=True)
        ii = np.concatenate([idx[g] for g in gs])
        vals.append(stat(x[ii], y[ii]))
    vals = np.array(vals)
    return np.nanpercentile(vals, [2.5, 97.5])


def paired_bootstrap_diff(xa, xb, y, groups, B=2000, seed=0):
    """Scene-clustered bootstrap of SROCC(a)-SROCC(b); two-sided p-value."""
    rng = np.random.default_rng(seed)
    xa, xb, y, groups = map(np.asarray, (xa, xb, y, groups))
    ug = np.unique(groups)
    idx = {g: np.where(groups == g)[0] for g in ug}
    d0 = spearmanr(xa, y)[0] - spearmanr(xb, y)[0]
    ds = []
    for _ in range(B):
        gs = rng.choice(ug, ug.size, replace=True)
        ii = np.concatenate([idx[g] for g in gs])
        ds.append(spearmanr(xa[ii], y[ii])[0] - spearmanr(xb[ii], y[ii])[0])
    ds = np.array(ds)
    p = 2 * min(np.mean(ds <= 0), np.mean(ds >= 0))
    return d0, max(p, 1.0 / B), np.percentile(ds, [2.5, 97.5])


def holm(pvals):
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    m = p.size
    adj = np.empty(m)
    run = 0
    for r, i in enumerate(order):
        run = max(run, (m - r) * p[i])
        adj[i] = min(1.0, run)
    return adj


def within_scene_kendall(x, y, groups):
    """Mean Kendall tau inside each scene (monotonicity under fixed content)."""
    x, y, groups = map(np.asarray, (x, y, groups))
    taus = []
    for g in np.unique(groups):
        m = groups == g
        if m.sum() >= 3:
            taus.append(kendalltau(x[m], y[m])[0])
    return float(np.nanmean(taus))


def auc(pos, neg):
    pos = np.asarray(pos)
    neg = np.asarray(neg)
    gt = (pos[:, None] > neg[None, :]).mean()
    eq = (pos[:, None] == neg[None, :]).mean()
    return gt + 0.5 * eq
