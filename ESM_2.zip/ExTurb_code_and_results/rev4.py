"""Revision 4 analyses.

(1) Do the GEV location, scale and shape carry complementary information, and does it
    survive camera and water changes?  Raw SROCC of each GEV component with turbidity on
    MFT Train, MFT Eva and TUB; and ExTurb-C / q99 / full-GEV models under camera
    (TUB leave-one-camera-out), scene (MFT leave-one-species-out) and dataset transfer.
(2) Identifiability: share of each feature's variance explained by turbidity within a
    scene versus by the scene, on BSDS-UW renders (200 scenes x 4 levels) and on TUB
    (33 scenes x 10 stages x 4 cameras).
(3) Abstention: a bootstrap-ensemble disagreement score and a Mahalanobis out-of-
    distribution score, with the abstention threshold fixed on MFT Test and applied
    unchanged to MFT Eva and to TUB -> MFT Eva transfer (risk-coverage).
"""
import json

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

R = "/home/claude/real"
RES = "/home/claude/results"
OUT = f"{RES}/revision"
rng = np.random.default_rng(44)


def fullX(d):
    lmu1, lmu2 = np.log(d["mu_1.5"].values), np.log(d["mu_3"].values)
    return np.c_[-lmu1, lmu1 - lmu2, np.log(d["sg_1.5"].values), np.log(d["sg_3"].values),
                 d["xi_1.5"].values, d["xi_3"].values]


def X_of(d, k):
    F = fullX(d)
    if k == "ExTurb-C":
        return F[:, :2]
    if k == "location+scale":
        return F[:, :4]
    if k == "q99":
        a, b = np.log(d["gq99_1.5"].values), np.log(d["gq99_3"].values)
        return np.c_[-a, a - b]
    return F


def fit(X, y):
    return np.linalg.lstsq(np.c_[X, np.ones(len(X))], y, rcond=None)[0]


def pred(c, X):
    return np.c_[X, np.ones(len(X))] @ c


def medre(p, y):
    return float(np.median(np.abs(np.exp(p) - np.exp(y)) / np.exp(y)))


MODELS = ["ExTurb-C", "q99", "location+scale", "full GEV"]
COMP = {"-ln mu(s1)": 0, "ln rho_mu": 1, "ln sigma_G(s1)": 2, "ln sigma_G(s2)": 3, "xi(s1)": 4, "xi(s2)": 5}


def part1(fm, ft):
    tr, ev = fm[fm.split == "Train"], fm[fm.split == "Eva"]
    sg = {}
    for name, d in (("MFT Train", tr), ("MFT Eva", ev), ("TUB", ft)):
        F = fullX(d); y = np.log(d.ntu.values)
        sg[name] = {k: spearmanr(F[:, j], y)[0] for k, j in COMP.items()}
    rows = []
    def add(split, fitd, testd, extra=None):
        for k in MODELS:
            c = fit(X_of(fitd, k), np.log(fitd.ntu.values))
            p = pred(c, X_of(testd, k)); y = np.log(testd.ntu.values)
            rows.append(dict(split=split, model=k, SROCC=spearmanr(p, y)[0], medRE=medre(p, y), **(extra or {})))
    for cam in sorted(ft.cam.unique()):
        add("TUB leave-one-camera-out", ft[ft.cam != cam], ft[ft.cam == cam], {"held": cam})
    te = fm[fm.split == "Test"]
    for sp in sorted(tr.group.unique()):
        add("MFT leave-one-species-out", tr[tr.group != sp], pd.concat([te[te.group == sp], ev[ev.group == sp]]), {"held": sp})
    add("MFT Train -> MFT Eva", tr, ev)
    add("MFT Train -> TUB", tr, ft)
    add("TUB -> MFT Eva", ft, ev)
    T = pd.DataFrame(rows)
    A = T.groupby(["split", "model"], sort=False).agg(SROCC=("SROCC", "mean"), medRE=("medRE", "median")).reset_index()
    A.to_csv(f"{OUT}/rev4_components_transfer.csv", index=False)
    json.dump(sg, open(f"{OUT}/rev4_component_srocc.json", "w"), indent=1)
    pd.set_option("display.width", 200)
    print(pd.DataFrame(sg).round(3)); print(A.round(3).to_string())


def var_share(v, scene, level):
    """Two-way decomposition: share of variance explained by scene means and by level means within scenes."""
    v = np.asarray(v, float)
    tot = np.var(v)
    sm = pd.Series(v).groupby(scene).transform("mean").values
    within = v - sm
    lm = pd.Series(within).groupby(level).transform("mean").values
    return float(np.var(sm) / tot), float(np.var(lm) / tot)


def part2(ft):
    out = {}
    g = pd.read_csv(f"{RES}/revision/gevfeat_bsds_test.csv")
    s = pd.read_csv(f"{RES}/scores_bsds_test.csv")
    # BSDS-UW levels are drawn at random per render: use ln b550 regression within scene instead of level means
    feats = {"T_c": -g["mu_1.5"], "ln rho": g["mu_1.5"] - g["mu_3.0"], "ln sigma_G": g["sg_1.5"], "xi": g["xi_1.5"]}
    res = {}
    lb = np.log(s.b550.values)
    for k, v in feats.items():
        v = v.values; tot = np.var(v)
        sm = pd.Series(v).groupby(s.scene).transform("mean").values
        w = v - sm; x = lb - pd.Series(lb).groupby(s.scene).transform("mean").values
        beta = np.dot(w, x) / np.dot(x, x)
        res[k] = {"scene": float(np.var(sm) / tot), "turbidity": float(np.var(beta * x) / tot)}
    out["BSDS-UW"] = res
    F = fullX(ft)
    feats = {"T_c": F[:, 0], "ln rho": F[:, 1], "ln sigma_G": F[:, 2], "xi": F[:, 4]}
    res = {}
    for k, v in feats.items():
        a, b = var_share(v, ft.group.values + "_" + ft.cam.astype(str).values, ft.stage.values)
        res[k] = {"scene": a, "turbidity": b}
    out["TUB"] = res
    json.dump(out, open(f"{OUT}/rev4_identifiability.json", "w"), indent=1)
    print(json.dumps(out, indent=1))


def ensemble(X, y, B=60):
    cs = []
    for _ in range(B):
        i = rng.integers(0, len(y), len(y))
        cs.append(fit(X[i], y[i]))
    return cs


def part3(fm, ft):
    tr, te, ev = (fm[fm.split == s] for s in ("Train", "Test", "Eva"))
    out = {}
    for src_name, src, cal, tgt in (("MFT Train -> Eva", tr, te, ev), ("TUB -> MFT Eva", ft, None, ev)):
        y_s = np.log(src.ntu.values)
        Xs_full = fullX(src)
        mu, cov = Xs_full.mean(0), np.cov(Xs_full.T) + 1e-9 * np.eye(Xs_full.shape[1])
        icov = np.linalg.inv(cov)
        maha = lambda d: np.einsum("ij,jk,ik->i", fullX(d) - mu, icov, fullX(d) - mu)
        ens = {k: ensemble(X_of(src, k), y_s) for k in ("ExTurb-C", "q99", "full GEV")}
        def scores(d):
            P = {k: np.array([pred(c, X_of(d, k)) for c in cs]) for k, cs in ens.items()}
            means = np.vstack([P[k].mean(0) for k in P])
            return {"ensemble disagreement": means.std(0), "Mahalanobis": maha(d)}
        c_main = fit(X_of(src, "ExTurb-C"), y_s)
        res = {}
        ref = cal if cal is not None else src
        sc_ref = scores(ref)
        sc_t = scores(tgt)
        y_t = np.log(tgt.ntu.values)
        p_t = pred(c_main, X_of(tgt, "ExTurb-C"))
        err = np.abs(np.exp(p_t) - np.exp(y_t)) / np.exp(y_t)
        for name in sc_t:
            for keep in (1.0, 0.8, 0.6):
                thr = np.quantile(sc_ref[name], keep) if keep < 1 else np.inf  # threshold fixed on the reference set
                m = sc_t[name] <= thr
                res[f"{name}|{keep}"] = dict(kept=float(m.mean()), medRE=float(np.median(err[m])) if m.any() else np.nan,
                                             SROCC=float(spearmanr(p_t[m], y_t[m])[0]) if m.sum() > 10 else np.nan)
        res["oracle|0.8"] = dict(kept=0.8, medRE=float(np.median(np.sort(err)[: int(0.8 * len(err))])))
        out[src_name] = res
    json.dump(out, open(f"{OUT}/rev4_abstention.json", "w"), indent=1)
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    fm = pd.read_csv(f"{R}/features_MFT.csv")
    ft = pd.read_csv(f"{R}/features_TUB.csv")
    part1(fm, ft)
    part2(ft)
    part3(fm, ft)
