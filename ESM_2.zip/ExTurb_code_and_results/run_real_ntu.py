"""Evaluate ExTurb and all baselines on real datasets with measured turbidity.

These datasets could not be downloaded in the environment used for the paper.
Run this script locally after downloading them.

  TUB  (Ismiroglou et al., 2026): https://huggingface.co/datasets/vapaau/TUB
       expects --tub_dir with images and a CSV  file,ntu,scene
  MFT  (Mahadi & Hashim, 2026, IEEE Dataport doi:10.21227/gd5d-ns10,
        mirror https://huggingface.co/datasets/mieraehh/5_Malaysian_Fish_Species_in_Turbid_Water)
       expects --mft_dir (folders 'Turbidity 0..3') and --mft_xlsx metadata
  TURBID (Duarte et al., 2016): http://amandaduarte.com.br/turbid/
       expects --turbid_dir with sub-folders per series; images sorted by
       increasing turbidity within each series (file order = level)

Example:
  python run_real_ntu.py --mft_dir data/mft --mft_xlsx "data/mft/Multimodal Metadata.xlsx"
"""
import argparse
import csv
import glob
import os
import re

import numpy as np

from compute import score_one
from stats_eval import cluster_bootstrap, corr_suite, within_scene_kendall

RES = "results_real"
os.environ.setdefault("EXTURB_RES", RES)


def evaluate(rows, label, group, name, extra=()):
    os.makedirs(RES, exist_ok=True)
    with open(f"{RES}/{name}_scores.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    keys = [k for k in rows[0] if k not in ("file", label, group, *extra) and not k.startswith("t_")]
    y = np.array([float(r[label]) for r in rows])
    g = np.array([r[group] for r in rows])
    out = []
    for k in keys:
        x = np.array([float(r[k]) for r in rows])
        s = corr_suite(x, y)
        lo, hi = cluster_bootstrap(x, y, g)
        s.update(method=k, ci_lo=lo, ci_hi=hi, within=within_scene_kendall(x, y, g))
        out.append(s)
    with open(f"{RES}/{name}_summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
    for s in sorted(out, key=lambda z: -z["SROCC"]):
        print(f"{name:7s} {s['method']:12s} SROCC={s['SROCC']:.3f} [{s['ci_lo']:.3f},{s['ci_hi']:.3f}] "
              f"PLCC={s['PLCC']:.3f} within={s['within']:.3f}")


IMG_EXT = (".jpg", ".jpeg", ".png")


def _score_all(paths):
    from joblib import Parallel, delayed
    return Parallel(n_jobs=-1, batch_size=8, verbose=5)(delayed(score_one)(p) for p in paths)


def _norm(h):
    return re.sub(r"[^a-z0-9]", "", str(h).lower()) if h is not None else ""


def _mft_xlsx_labels(xlsx):
    """Return {file-stem: ntu} from the MFT metadata sheet, or {} if no usable columns."""
    if not xlsx or not os.path.exists(xlsx):
        return {}
    import openpyxl
    wb = openpyxl.load_workbook(xlsx, read_only=True, data_only=True)
    meta = {}
    for ws in wb.worksheets:
        rows = ws.iter_rows(values_only=True)
        try:
            hdr = [_norm(c) for c in next(rows)]
        except StopIteration:
            continue
        print(f"MFT sheet '{ws.title}' columns:", hdr)
        ci = next((i for i, h in enumerate(hdr) if "image" in h or "file" in h or "name" in h), None)
        ti = next((i for i, h in enumerate(hdr) if "ntu" in h), None)
        if ti is None:
            ti = next((i for i, h in enumerate(hdr) if "turbid" in h), None)
        if ci is None or ti is None:
            continue
        for r in rows:
            if r is None or len(r) <= max(ci, ti) or r[ci] is None or r[ti] is None:
                continue
            try:
                v = float(r[ti])
            except (TypeError, ValueError):
                continue
            meta[os.path.splitext(os.path.basename(str(r[ci])))[0]] = v
    return meta


def run_mft(mft_dir, xlsx, split=None, max_per_cell=None, seed=0):
    """MFT: folders Turbidity <k>/<split>/<species>/*.jpg.

    Label = measured NTU from the metadata sheet when the file name matches,
    otherwise the folder turbidity level k (ordinal 0..3). Group = species.
    """
    meta = _mft_xlsx_labels(xlsx)
    rng = np.random.default_rng(seed)
    items = []
    for lvl_dir in sorted(glob.glob(os.path.join(mft_dir, "Turbidity *"))):
        k = int(re.findall(r"\d+", os.path.basename(lvl_dir))[0])
        for sp_dir in sorted(glob.glob(os.path.join(lvl_dir, "*", "*"))):
            sp_split = os.path.basename(os.path.dirname(sp_dir))
            if split and sp_split.lower() != split.lower():
                continue
            fs = sorted(p for p in glob.glob(os.path.join(sp_dir, "*")) if p.lower().endswith(IMG_EXT))
            if max_per_cell and len(fs) > max_per_cell:
                fs = sorted(rng.choice(fs, max_per_cell, replace=False))
            for p in fs:
                items.append((p, k, os.path.basename(sp_dir), sp_split))
    if not items:
        raise SystemExit(f"No MFT images found under {mft_dir}")
    n_match = sum(os.path.splitext(os.path.basename(p))[0] in meta for p, *_ in items)
    use_ntu = n_match >= 0.9 * len(items)
    print(f"MFT images: {len(items)}; metadata NTU matched: {n_match}"
          f" -> label = {'measured NTU' if use_ntu else 'folder turbidity level (ordinal)'}")
    scores = _score_all([p for p, *_ in items])
    rows = []
    for (p, k, sp, spl), s in zip(items, scores):
        stem = os.path.splitext(os.path.basename(p))[0]
        y = meta[stem] if use_ntu else k
        rows.append({"file": p, "ntu": y, "level": k, "split": spl, "group": sp, **s})
    evaluate(rows, "ntu", "group", "MFT", extra=("level", "split"))


def inspect(root):
    """Print folder structure and label-file headers so labels can be matched."""
    import collections
    exts = collections.Counter()
    dirs = collections.Counter()
    for dp, dn, fn in os.walk(root):
        if ".cache" in dp:
            continue
        for f in fn:
            e = os.path.splitext(f)[1].lower()
            exts[e] += 1
            if e in (".jpg", ".jpeg", ".png"):
                dirs[os.path.relpath(dp, root)] += 1
            if e in (".csv", ".json", ".jsonl", ".txt", ".md", ".xlsx", ".parquet", ".yaml"):
                p = os.path.join(dp, f)
                print("\n==== LABEL/INFO FILE:", os.path.relpath(p, root), os.path.getsize(p), "bytes")
                try:
                    if e == ".xlsx":
                        import openpyxl
                        ws = openpyxl.load_workbook(p, read_only=True).active
                        for i, row in enumerate(ws.iter_rows(values_only=True)):
                            print(row)
                            if i >= 5:
                                break
                    elif e == ".parquet":
                        import pandas as pd
                        df = pd.read_parquet(p)
                        print(df.columns.tolist())
                        print(df.drop(columns=[c for c in df.columns if "image" in c.lower()], errors="ignore").head())
                    else:
                        with open(p, encoding="utf-8", errors="replace") as fh:
                            for i, line in enumerate(fh):
                                print(line.rstrip()[:300])
                                if i >= 12:
                                    break
                except Exception as ex:
                    print("  (could not read:", ex, ")")
    print("\n==== FILE TYPES:", dict(exts))
    print("==== IMAGE FOLDERS (first 40):")
    for d, n in sorted(dirs.items())[:40]:
        print(f"  {n:6d}  {d}")
    print("  ... total image folders:", len(dirs))


TUB_RE = re.compile(r"Exp(\d+)_Cam(\d+)_Stage(\d+)", re.I)


def _tub_ntu_table(csv_path):
    """Parse av_turbidity.csv into {(exp, stage): ntu}. Handles long or wide layouts."""
    import pandas as pd
    df = pd.read_csv(csv_path, sep=None, engine="python")
    print("TUB av_turbidity.csv columns:", list(df.columns))
    print(df.head(12).to_string())
    cols = {_norm(c): c for c in df.columns}
    table = {}
    # long layout with a file/image name column containing ExpN_..._StageSS
    for c in df.columns:
        if df[c].astype(str).str.contains(r"Exp\d+", case=False, regex=True).mean() > 0.5:
            val = next((cols[k] for k in cols if "ntu" in k or "turb" in k or k in ("avg", "mean")), None)
            if val is None:
                num = [x for x in df.columns if x != c and pd.api.types.is_numeric_dtype(df[x])]
                val = num[-1] if num else None
            if val is not None:
                for name, v in zip(df[c].astype(str), df[val]):
                    m = re.search(r"Exp(\d+)", name, re.I)
                    st = re.search(r"Stage(\d+)", name, re.I) or re.search(r"(?:level|lvl|s)(\d+)", name, re.I)
                    if m and st and pd.notna(v):
                        table[(int(m.group(1)), int(st.group(1)))] = float(v)
                if table:
                    return table
            # name holds experiment only -> other columns are stages (wide)
            for name, row in zip(df[c].astype(str), df.itertuples(index=False)):
                m = re.search(r"Exp(\d+)", name, re.I)
                if not m:
                    continue
                for col, v in zip(df.columns, row):
                    st = re.findall(r"\d+", str(col))
                    if col != c and st and pd.notna(v):
                        try:
                            table[(int(m.group(1)), int(st[-1]))] = float(v)
                        except ValueError:
                            pass
            if table:
                return table
    # long layout with separate numeric exp / stage columns
    ek = next((cols[k] for k in cols if k.startswith("exp") or "scene" in k), None)
    sk = next((cols[k] for k in cols if "stage" in k or "level" in k or "step" in k), None)
    vk = next((cols[k] for k in cols if "ntu" in k or "turb" in k or k in ("avg", "mean")), None)
    if ek and sk and vk:
        for e, st, v in zip(df[ek], df[sk], df[vk]):
            try:
                table[(int(re.findall(r"\d+", str(e))[0]), int(re.findall(r"\d+", str(st))[0]))] = float(v)
            except (IndexError, ValueError):
                pass
    return table


def run_tub(tub_dir, csv_path=None):
    """TUB: images/ExpN_CamK_StageSS.jpg; NTU from av_turbidity.csv (per experiment and stage).

    Group = experiment (one static scene); camera views of the same scene share a group.
    Falls back to the stage index (ordinal 1..10) if the NTU table cannot be parsed.
    """
    csv_path = csv_path or os.path.join(tub_dir, "av_turbidity.csv")
    paths = sorted(p for p in glob.glob(os.path.join(tub_dir, "images", "*")) if p.lower().endswith(IMG_EXT))
    if not paths:
        paths = sorted(p for p in glob.glob(os.path.join(tub_dir, "**", "*"), recursive=True)
                       if p.lower().endswith(IMG_EXT))
    table = _tub_ntu_table(csv_path) if os.path.exists(csv_path) else {}
    items = []
    for p in paths:
        m = TUB_RE.search(os.path.basename(p))
        if m:
            items.append((p, int(m.group(1)), int(m.group(2)), int(m.group(3))))
    n_match = sum((e, st) in table for _, e, _, st in items)
    use_ntu = n_match >= 0.9 * len(items)
    print(f"TUB images: {len(items)}; NTU table entries: {len(table)}; matched: {n_match}"
          f" -> label = {'measured NTU' if use_ntu else 'stage index (ordinal)'}")
    scores = _score_all([p for p, *_ in items])
    rows = []
    for (p, e, cam, st), s in zip(items, scores):
        y = table[(e, st)] if use_ntu else st
        rows.append({"file": p, "ntu": y, "stage": st, "cam": cam, "group": f"Exp{e}", **s})
    evaluate(rows, "ntu", "group", "TUB", extra=("stage", "cam"))
    if use_ntu:
        _fit_ntu_map(rows)


def _fit_ntu_map(rows, key="ExTurb_Tc"):
    """Leave-one-scene-out linear map from T_c to ln(NTU): an honest predicted-vs-measured test."""
    y = np.log(np.maximum([float(r["ntu"]) for r in rows], 0.1))
    x = np.array([float(r[key]) for r in rows])
    g = np.array([r["group"] for r in rows])
    pred = np.full_like(y, np.nan)
    for gg in np.unique(g):
        tr = g != gg
        A = np.c_[x[tr], np.ones(tr.sum())]
        coef = np.linalg.lstsq(A, y[tr], rcond=None)[0]
        pred[~tr] = coef[0] * x[~tr] + coef[1]
    rel = np.abs(np.exp(pred) - np.exp(y)) / np.exp(y)
    with open(f"{RES}/TUB_loso_ntu.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["file", "group", "ntu", "pred_ntu"])
        for r, pv in zip(rows, np.exp(pred)):
            w.writerow([r["file"], r["group"], r["ntu"], pv])
    print(f"TUB leave-one-scene-out NTU from {key}: median rel. error {np.median(rel):.3e}")


def run_turbid(turbid_dir):
    rows = []
    for series in sorted(glob.glob(f"{turbid_dir}/*/")):
        fs = sorted(p for p in glob.glob(series + "*") if p.lower().endswith((".jpg", ".png", ".jpeg")))
        for lvl, p in enumerate(fs):
            rows.append({"file": p, "level": lvl, "group": series, **score_one(p)})
    evaluate(rows, "level", "group", "TURBID")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mft_dir")
    ap.add_argument("--mft_xlsx")
    ap.add_argument("--mft_split", help="Eva, Test or Train (default: all)")
    ap.add_argument("--max_per_cell", type=int, help="random subsample per level/split/species")
    ap.add_argument("--tub_dir")
    ap.add_argument("--tub_csv")
    ap.add_argument("--turbid_dir")
    ap.add_argument("--inspect", help="print structure and label headers of a dataset folder")
    a = ap.parse_args()
    if a.inspect:
        inspect(a.inspect)
    if a.mft_dir:
        xlsx = a.mft_xlsx or os.path.join(a.mft_dir, "Multimodal Metadata.xlsx")
        run_mft(a.mft_dir, xlsx, a.mft_split, a.max_per_cell)
    if a.tub_dir:
        run_tub(a.tub_dir, a.tub_csv)
    if a.turbid_dir:
        run_turbid(a.turbid_dir)
