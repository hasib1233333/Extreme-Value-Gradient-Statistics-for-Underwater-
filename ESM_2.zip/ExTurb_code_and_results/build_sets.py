"""Render the semi-synthetic benchmarks and store them as PNG + CSV metadata.

Usage: python build_sets.py bsds|km|robust|range
"""
import csv
import os
import sys

import numpy as np
from joblib import Parallel, delayed
from PIL import Image

from datasets import B_LEVELS, bsds_paths, km_paths, load_rgb, render_sample

OUT = "/home/claude/bench"
WT = ["oceanic", "coastal", "harbor"]


def save(img, path):
    Image.fromarray((np.clip(img, 0, 1) * 255 + 0.5).astype(np.uint8)).save(path)


def job_bsds(split, k, path, nlev=4):
    rng = np.random.default_rng({"train": 0, "val": 1, "test": 2}[split] * 1000 + k)
    J = load_rgb(path)
    levels = rng.choice(B_LEVELS, nlev, replace=False)
    rows = []
    for j, b in enumerate(levels):
        w = WT[rng.integers(3)]
        dmean = rng.uniform(1.0, 3.5)
        I, d = render_sample(J, rng, float(b), w, dmean=dmean)
        fn = f"{OUT}/bsds_{split}/{k:03d}_{j}.png"
        save(I, fn)
        rows.append([fn, split, k, float(b), w, float(d.mean()), os.path.basename(path)])
    return rows


def job_km(k, path):
    rng = np.random.default_rng(5000 + k)
    J = load_rgb(path, long_side=512)
    rows = []
    w = WT[k % 3]
    dmean = rng.uniform(1.0, 3.5)
    for j, b in enumerate(B_LEVELS):
        I, d = render_sample(J, rng, float(b), w, dmean=dmean)
        fn = f"{OUT}/km/{k:03d}_{j}.png"
        save(I, fn)
        rows.append([fn, "km", k, float(b), w, float(d.mean()), os.path.basename(path)])
    return rows


ROBUST = {
    "noise": [("noise", v) for v in (0.002, 0.01, 0.02, 0.04)],
    "jpeg": [("jpeg_q", v) for v in (95, 70, 40, 15)],
    "gain": [("gain", v) for v in (0.4, 0.7, 1.0, 1.6)],
    "range": [("dmean", v) for v in (0.8, 1.5, 2.5, 4.0)],
    "water": [("water", v) for v in WT],
}


def job_robust(k, path, factor, setting):
    name, val = setting
    rng = np.random.default_rng(9000 + k)
    J = load_rgb(path)
    rows = []
    for j, b in enumerate(B_LEVELS):
        kw = dict(water=WT[k % 3], dmean=2.0, gain=1.0, noise=0.006, jpeg_q=None)
        kw[name] = val
        w = kw.pop("water")
        I, d = render_sample(J, rng, float(b), w, **kw)
        fn = f"{OUT}/robust/{factor}_{val}_{k:03d}_{j}.png"
        save(I, fn)
        rows.append([fn, f"{factor}={val}", k, float(b), w, float(d.mean()), os.path.basename(path)])
    return rows


def job_range(k, path):
    """Known-range (altimeter) setting: flat range map, store c550 truth."""
    from render import WATERS, coefficients
    rng = np.random.default_rng(12000 + k)
    J = load_rgb(path)
    H, W = J.shape[:2]
    rows = []
    for j in range(6):
        b = float(rng.uniform(0.05, 1.5))
        w = WT[rng.integers(3)]
        dz = float(rng.uniform(0.8, 4.0))
        depth = np.full((H, W), dz)
        I, _ = render_sample(J, rng, b, w, depth=depth)
        a, bb, c = coefficients(WATERS[w], b)
        c550 = float(np.interp(550, [460, 540, 600], c[::-1]))
        fn = f"{OUT}/range/{k:03d}_{j}.png"
        save(I, fn)
        rows.append([fn, "range", k, b, w, dz, os.path.basename(path), c550])
    return rows


def write(rows, name, extra=()):
    with open(f"{OUT}/{name}.csv", "w", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["file", "set", "scene", "b550", "water", "dmean", "source", *extra])
        wr.writerows(rows)


if __name__ == "__main__":
    which = sys.argv[1]
    if which == "bsds":
        for split in ("train", "val", "test"):
            os.makedirs(f"{OUT}/bsds_{split}", exist_ok=True)
            ps = bsds_paths(split)
            R = Parallel(n_jobs=2)(delayed(job_bsds)(split, k, p) for k, p in enumerate(ps))
            write(sum(R, []), f"bsds_{split}")
    elif which == "km":
        os.makedirs(f"{OUT}/km", exist_ok=True)
        R = Parallel(n_jobs=2)(delayed(job_km)(k, p) for k, p in enumerate(km_paths()))
        write(sum(R, []), "km")
    elif which == "robust":
        os.makedirs(f"{OUT}/robust", exist_ok=True)
        ps = bsds_paths("test")[:20]
        R = []
        for factor, settings in ROBUST.items():
            for s in settings:
                R += Parallel(n_jobs=2)(delayed(job_robust)(k, p, factor, s) for k, p in enumerate(ps))
        write(sum(R, []), "robust")
    elif which == "range":
        os.makedirs(f"{OUT}/range", exist_ok=True)
        ps = bsds_paths("test")
        R = Parallel(n_jobs=2)(delayed(job_range)(k, p) for k, p in enumerate(ps))
        write(sum(R, []), "range", extra=("c550",))
