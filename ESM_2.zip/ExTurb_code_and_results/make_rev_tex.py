"""Write LaTeX macros and table rows for the revision results."""
import json
import re

import numpy as np
import pandas as pd

R = "/home/claude/real"
C = f"{R}/calib"
REV = "/home/claude/results/revision"
PAP = "/home/claude/paper"
MAC = {}
NAME = {"UCIQE": "UCIQE", "UIQM": "UIQM", "DCP": "DCP", "UDCP": "UDCP", "DynRange": "Dynamic range",
        "RMSC": "RMS contrast", "Tenengrad": "Tenengrad", "LapVar": "Laplacian variance",
        "Entropy": "Entropy", "PCD": "PCD"}
BASE = list(NAME)


def sci(x, nd=2):
    """Scientific notation for |x|<1 (author preference), plain otherwise."""
    if x == 0 or not np.isfinite(x):
        return f"{x:.{nd}f}"
    if abs(x) >= 1:
        return f"{x:.{nd}f}"
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    if round(abs(m), nd) >= 10:
        m /= 10; e += 1
    if e == 0:
        return f"{x:.{nd}f}"
    return f"\\ensuremath{{{m:.{nd}f}\\times10^{{{e}}}}}"


def mac(k, v):
    MAC[k] = v


def p100(x):
    return f"{100 * x:.1f}"


def main():
    mtr = pd.read_csv(f"{R}/MFT_train_scores.csv")
    mte = pd.read_csv(f"{R}/MFT_test_scores.csv")
    tub = pd.read_csv(f"{R}/TUB_scores.csv")
    mac("TUBntuMin", f"{tub.ntu.min():.1f}"); mac("TUBntuMax", f"{tub.ntu.max():.1f}")
    for L in range(4):
        mac(f"MFTlev{L}", f"{mte[mte.level == L].ntu.median():.1f}")
    mac("nMFTtrain", str(len(mtr))); mac("nMFTtest", str(len(mte))); mac("nTUB", str(len(tub)))

    # ---------- uncalibrated table (frozen scores, from the per-image CSVs) ----------
    from scipy.stats import kendalltau, spearmanr
    rng = np.random.default_rng(5)

    def ci(x, y, g=None, nb=1000):
        n = len(y)
        if g is None:
            idx = [rng.integers(0, n, n) for _ in range(nb)]
        else:
            G = np.unique(g); mem = {k: np.where(g == k)[0] for k in G}
            idx = [np.concatenate([mem[k] for k in rng.choice(G, len(G))]) for _ in range(nb)]
        v = [spearmanr(x[i], y[i])[0] for i in idx]
        return np.percentile(v, [2.5, 97.5])

    def within(x, y, g):
        return np.nanmean([kendalltau(x[g == k], y[g == k])[0] for k in np.unique(g)])

    rows = []
    cols = [("ExTurb", r"\textbf{ExTurb (frozen)}"), ("ExTurb_Tc", r"\quad $T_c$ alone"),
            ("ExTurb_rho", r"\quad $\rho$ alone"), ("ExTurb_sigma", r"\quad $\hat\sigma_b$ alone"),
            ("ExTurb_xi", r"\quad $\hat\xi$ alone")] + [(b, NAME[b]) for b in BASE]
    raw = {}
    for k, lab in cols:
        yt, gt = np.log(tub.ntu.values), tub.group.values
        st = spearmanr(tub[k], yt)[0]; lt, ht = ci(tub[k].values, yt, gt)
        wt = within(tub[k].values, yt, gt)
        ym = np.log(mte.ntu.values)
        sm = spearmanr(mte[k], ym)[0]; lm, hm = ci(mte[k].values, ym)
        sr = spearmanr(mtr[k], np.log(mtr.ntu))[0]
        raw[k] = dict(tub=st, mft=sm, mtr=sr)
        rows.append([lab, p100(st), f"[{p100(lt)}, {p100(ht)}]", p100(wt), p100(sm),
                     f"[{p100(lm)}, {p100(hm)}]", p100(sr)])
    # bold best (largest) per numeric column among all rows, columns 1,3,4,6
    for c in (1, 3, 4, 6):
        vals = [float(r[c]) for r in rows]
        j = int(np.argmax(vals))
        rows[j][c] = r"\textbf{" + rows[j][c] + "}"
    open(f"{PAP}/tab_ntu_raw_rows.tex", "w").write("\n".join(" & ".join(r) + r" \\" for r in rows) + "\n")
    mac("RawExTUB", sci(raw["ExTurb"]["tub"])); mac("RawExMFT", sci(raw["ExTurb"]["mft"]))
    mac("RawTcTUB", sci(raw["ExTurb_Tc"]["tub"])); mac("RawTcMFT", sci(raw["ExTurb_Tc"]["mft"]))
    mac("RawRhoTUB", sci(raw["ExTurb_rho"]["tub"])); mac("RawRhoMFT", sci(raw["ExTurb_rho"]["mft"]))
    mac("RawSigMFT", sci(raw["ExTurb_sigma"]["mft"])); mac("RawSigTUB", sci(raw["ExTurb_sigma"]["tub"]))
    mac("RawXiMFT", sci(raw["ExTurb_xi"]["mft"])); mac("RawXiTUB", sci(raw["ExTurb_xi"]["tub"]))
    mac("RawUCIQETUB", sci(raw["UCIQE"]["tub"])); mac("RawDynMFT", sci(raw["DynRange"]["mft"]))
    mac("RawPCDMFT", sci(raw["PCD"]["mft"])); mac("RawUIQMTUB", sci(raw["UIQM"]["tub"]))

    # ---------- calibrated protocols ----------
    M = pd.read_csv(f"{C}/real_metrics.csv")
    S = pd.read_csv(f"{C}/real_significance.csv")
    prots = ["P1 MFT Train->Test", "P2 TUB leave-one-scene-out", "P3a MFT Train->TUB", "P3b TUB->MFT Test"]
    EC = "ExTurb-C (T_c + ln rho)"

    def key(m):
        if m.startswith("Best baseline pair"):
            return "PAIR"
        return m
    order = ["ExTurb (frozen, uncalibrated)", "ExTurb T_c only", EC] + BASE + ["PAIR"]
    labels = {"ExTurb (frozen, uncalibrated)": r"ExTurb (frozen) + affine map", "ExTurb T_c only": r"$T_c$ + affine map",
              EC: r"\textbf{ExTurb-C} ($T_c$, $\ln\rho$)", "PAIR": r"Best baseline pair$^\S$"}
    tab = {}
    for p in prots:
        d = M[M.protocol == p].copy(); d["k"] = d.model.map(key)
        s = S[S.protocol == p].copy(); s["k"] = s.vs.map(key)
        tab[p] = (d.set_index("k"), s.set_index("k"))
    lines = []
    for k in order:
        cells = [labels.get(k, NAME.get(k, k))]
        for p in prots:
            d, s = tab[p]
            r = d.loc[k]
            mark = ""
            if k != EC:
                q = s.loc[k]
                if q.p_holm < 0.05:
                    mark = r"$^{+}$" if q.dSROCC > 0 else r"$^{-}$"
            cells += [p100(r.SROCC) + mark, p100(r.medrel)]
        lines.append(cells)
    # bold best SROCC (max) and best medrel (min) per protocol
    for j in range(len(prots)):
        cs, cm = 1 + 2 * j, 2 + 2 * j
        sv = [float(re.sub(r"\$.*", "", l[cs])) for l in lines]
        mv = [float(l[cm]) for l in lines]
        a, b = int(np.argmax(sv)), int(np.argmin(mv))
        lines[a][cs] = r"\textbf{" + re.sub(r"(\$.*)", "", lines[a][cs]) + "}" + (re.search(r"\$.*", lines[a][cs]).group(0) if "$" in lines[a][cs] else "")
        lines[b][cm] = r"\textbf{" + lines[b][cm] + "}"
    open(f"{PAP}/tab_ntu_cal_rows.tex", "w").write("\n".join(" & ".join(l) + r" \\" for l in lines) + "\n")
    info = json.load(open(f"{C}/real_info.json"))
    for p, tag in zip(prots, ["P1", "P2", "P3a", "P3b"]):
        d, s = tab[p]
        mac(f"{tag}ExC", sci(d.loc[EC].SROCC)); mac(f"{tag}ExCmed", p100(d.loc[EC].medrel))
        mac(f"{tag}ExF", sci(d.loc["ExTurb (frozen, uncalibrated)"].SROCC))
        mac(f"{tag}Tc", sci(d.loc["ExTurb T_c only"].SROCC))
        mac(f"{tag}Pair", sci(d.loc["PAIR"].SROCC)); mac(f"{tag}Pairmed", p100(d.loc["PAIR"].medrel))
        for b in BASE:
            mac(f"{tag}{b}", sci(d.loc[b].SROCC)); mac(f"{tag}{b}med", p100(d.loc[b].medrel))
            mac(f"{tag}{b}p", sci(s.loc[b].p_holm))
            mac(f"{tag}{b}d", sci(s.loc[b].dSROCC))
        mac(f"{tag}Pairp", sci(s.loc["PAIR"].p_holm)); mac(f"{tag}Paird", sci(s.loc["PAIR"].dSROCC))
        mac(f"{tag}Tcp", sci(s.loc["ExTurb T_c only"].p_holm))
        if "within" in d.columns and np.isfinite(d.loc[EC].within):
            mac(f"{tag}ExCwithin", sci(d.loc[EC].within))
    c1 = info["P1_coefs"][EC]
    mac("CalAone", f"{c1[0]:.2f}"); mac("CalAtwo", f"{c1[1]:.2f}"); mac("CalAzero", f"{c1[2]:.2f}")
    c4 = info["P3b_coefs"][EC]
    mac("CalTUBAone", f"{c4[0]:.2f}"); mac("CalTUBAtwo", f"{c4[1]:.2f}")
    mac("PairP1", "+".join(NAME[x] for x in info["P1_coefs"]["pair"]["cols"]))
    mac("SigZeroMFT", f"{100 * info['sigma_zero_frac']['MFT Train']:.0f}")
    mac("SigZeroTUB", sci(100 * info['sigma_zero_frac']['TUB']))
    mac("RhoMedMFT", f"{info['rho_median']['MFT']:.2f}"); mac("RhoMedTUB", f"{info['rho_median']['TUB']:.2f}")

    # ---------- conformal and scene-referenced ----------
    cf = json.load(open(f"{C}/conformal.json"))
    for m, t in [("ExTurb-C", "ExC"), ("DynRange", "Dyn"), ("UCIQE", "UCIQE")]:
        for ds in ("MFT", "TUB"):
            mac(f"Cov{t}{ds}", f"{100 * cf[m][ds]['coverage']:.1f}")
            mac(f"Wid{t}{ds}", f"{np.sqrt(cf[m][ds]['width_factor']):.2f}")
        mac(f"CovLev0{t}", f"{100 * cf[m]['MFT']['cov_by_level']['0']:.1f}")
    ref = pd.read_csv(f"{C}/tub_scene_referenced.csv").set_index("model")
    mac("RefTc", sci(ref.loc["Tc"].SROCC)); mac("RefTcW", sci(ref.loc["Tc"].within))
    mac("RefTcMed", p100(ref.loc["Tc"].medrel))
    best = ref.SROCC.idxmax()
    mac("RefBest", NAME.get(best, best)); mac("RefBestS", sci(ref.loc[best].SROCC))
    mac("RefUCIQE", sci(ref.loc["UCIQE"].SROCC))

    # ---------- synthetic revision studies ----------
    ps = pd.read_csv(f"{REV}/psf_study.csv")
    ps = ps[ps.w > 0]
    for kind, t in [("gauss", "G"), ("poisson", "P"), ("moffat", "M")]:
        v = ps[ps.kind == kind]
        mac(f"Psf{t}med", f"{100 * np.nanmedian(np.abs(v.rel_err_tot)):.1f}")
        mac(f"Psf{t}small", f"{100 * np.nanmedian(np.abs(v[v.sigma_f < 1.5].rel_err_tot)):.1f}")
        mac(f"Psf{t}large", f"{100 * np.nanmedian(np.abs(v[v.sigma_f >= 3].rel_err_tot)):.1f}")
    ed = json.load(open(f"{REV}/edge_study.json"))
    mac("RhoStep", f"{ed['edges']['step'][0]:.2f}"); mac("RhoLine", f"{ed['edges']['bar_1px'][0]:.2f}")
    fr = ed["rho_ge_2_renders"]
    mac("RhoGeBSDS", f"{100 * fr['scores_bsds_test.csv']:.0f}"); mac("RhoGeKM", f"{100 * fr['scores_km.csv']:.0f}")
    mac("RhoGeRange", f"{100 * fr['scores_range.csv']:.0f}")
    g = pd.read_csv(f"{REV}/gev_ablation.csv")
    gl = []
    for f in g.features.unique():
        a = g[(g.features == f) & (g.set == "bsds_test")].iloc[0]
        b = g[(g.features == f) & (g.set == "km")].iloc[0]
        gl.append([f, str(int(a.n)), p100(a.SROCC), f"[{p100(a.lo)}, {p100(a.hi)}]", p100(a.within),
                   p100(b.SROCC), f"[{p100(b.lo)}, {p100(b.hi)}]", p100(b.within)])
    lab = {"mean Weber gradient (s1)": r"Mean Weber gradient ($s_1$)",
           "mean of block maxima (s1)": r"Mean of block maxima ($s_1$)",
           "GEV location (s1) = T_c": r"GEV $\mu$ ($s_1$) $=T_c$",
           "GEV location (s1, s2)": r"GEV $\mu$ ($s_1,s_2$)",
           "GEV location+scale (s1, s2)": r"GEV $\mu,\sigma_G$ ($s_1,s_2$)",
           "full GEV (s1, s2)": r"GEV $\mu,\sigma_G,\xi$ ($s_1,s_2$)",
           "GEV location (4 scales)": r"GEV $\mu$ (4 scales)",
           "full GEV (4 scales)": r"GEV $\mu,\sigma_G,\xi$ (4 scales)",
           "block-maxima mean (4 scales)": r"Mean of block maxima (4 scales)"}
    for c in (2, 4, 5, 7):
        j = int(np.argmax([float(r[c]) for r in gl]))
        gl[j][c] = r"\textbf{" + gl[j][c] + "}"
    open(f"{PAP}/tab_gev_rows.tex", "w").write(
        "\n".join(" & ".join([lab[r[0]]] + r[1:]) + r" \\" for r in gl) + "\n")
    gi = g.set_index(["features", "set"])
    mac("GevLocB", sci(gi.loc[("GEV location (s1) = T_c", "bsds_test")].SROCC))
    mac("GevFullB", sci(gi.loc[("full GEV (s1, s2)", "bsds_test")].SROCC))
    mac("GevFullFourB", sci(gi.loc[("full GEV (4 scales)", "bsds_test")].SROCC))
    mac("GevMaxFourB", sci(gi.loc[("block-maxima mean (4 scales)", "bsds_test")].SROCC))
    mac("GevLocK", sci(gi.loc[("GEV location (s1) = T_c", "km")].SROCC))
    mac("GevFullK", sci(gi.loc[("full GEV (s1, s2)", "km")].SROCC))
    mac("GevFullFourK", sci(gi.loc[("full GEV (4 scales)", "km")].SROCC))
    mac("GevMaxFourK", sci(gi.loc[("block-maxima mean (4 scales)", "km")].SROCC))
    mono = json.load(open(f"{REV}/gev_monotonicity.json"))
    mac("MonoXi", sci(mono["xi_1.5"])); mac("MonoSg", sci(mono["sg_1.5"]))
    mac("MonoXiSix", sci(mono["xi_6.0"]))
    rc = json.load(open(f"{REV}/range_conformal.json"))
    mac("RangeCov", f"{100 * rc['coverage_mean']:.1f}")
    mac("RangeCovLo", f"{100 * rc['coverage_p05']:.1f}"); mac("RangeCovHi", f"{100 * rc['coverage_p95']:.1f}")
    mac("RangeFac", f"{rc['factor_median']:.2f}")
    mac("RangeCovTlo", f"{100 * rc['by_cd_tercile']['0']:.1f}"); mac("RangeCovThi", f"{100 * rc['by_cd_tercile']['2']:.1f}")
    try:
        cam = pd.read_csv(f"{REV}/camera_summary.csv").set_index("method")
        tf = ["gain x0.6", "gain x1.5 (clips)", "offset +0.05", "gamma 0.8", "gamma 1.25", "white balance",
              "auto-exposure", "JPEG q=40"]
        order = ["ExTurb", "ExTurb T_c"] + BASE
        cl = []
        for m in order:
            r = cam.loc[m]
            cl.append([{"ExTurb": r"\textbf{ExTurb (frozen)}", "ExTurb T_c": r"\quad $T_c$"}.get(m, NAME.get(m, m)),
                       p100(r["SROCC orig"])] + [p100(r[f"stab {t}"]) for t in tf])
        for c in range(1, len(cl[0])):
            j = int(np.argmax([float(x[c]) for x in cl]))
            cl[j][c] = r"\textbf{" + cl[j][c] + "}"
        open(f"{PAP}/tab_camera_rows.tex", "w").write("\n".join(" & ".join(x) + r" \\" for x in cl) + "\n")
        for t, k in zip(tf, ["GainLo", "GainHi", "Off", "GamLo", "GamHi", "WB", "AE", "JPEG"]):
            mac(f"Cam{k}", sci(cam.loc["ExTurb T_c"][f"stab {t}"]))
            mac(f"CamFull{k}", sci(cam.loc["ExTurb"][f"stab {t}"]))
            mac(f"CamS{k}", sci(cam.loc["ExTurb T_c"][f"SROCC {t}"]))
        stab = cam[[f"stab {t}" for t in tf]].mean(axis=1)
        mac("CamMeanTc", sci(stab.loc["ExTurb T_c"])); mac("CamMeanEx", sci(stab.loc["ExTurb"]))
        best = stab.drop(["ExTurb", "ExTurb T_c"]).idxmax()
        mac("CamBest", NAME.get(best, best)); mac("CamBestMean", sci(stab.loc[best]))
        mac("CamRankTc", str(int((stab > stab.loc["ExTurb T_c"]).sum() + 1)))
        print("camera stab means:\n", stab.sort_values(ascending=False).round(3))
        cs = pd.read_csv(f"{REV}/camera_scores.csv")
        for t, k in [("gamma 0.8", "Gam"), ("gamma 1.25", "GamHi"), ("gain x1.5 (clips)", "Clip"),
                     ("offset +0.05", "Off"), ("gain x0.6", "GainLo"), ("auto-exposure", "AE")]:
            mac(f"CamShift{k}", sci(float((cs[f"ExTurb T_c|{t}"] - cs["ExTurb T_c|orig"]).median())))
        mac("CamShiftGamPred", sci(-np.log(0.8)))
    except FileNotFoundError:
        print("camera results not yet available")
    with open(f"{PAP}/results_rev_macros.tex", "w") as f:
        f.write("% auto-generated by make_rev_tex.py -- revision results\n")
        for k, v in MAC.items():
            assert re.fullmatch(r"[A-Za-z0-9]+", k), k
            f.write(f"\\expandafter\\def\\csname R@{k}\\endcsname{{{v}}}\n")
    print(len(MAC), "macros")


if __name__ == "__main__":
    main()
