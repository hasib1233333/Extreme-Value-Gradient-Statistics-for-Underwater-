"""Experiments that check the analytical claims (Section 3).

E-T1  probe-ratio inversion on blurred step-edge mosaics with random contrast
E-T2  T_c versus optical depth (uniform range) and invariance to camera gain
E-T3  GEV adequacy: Anderson-Darling / QQ on real UIQS images; PWM vs MLE
"""
import json
import time

import numpy as np
from scipy import ndimage as ndi
from scipy.stats import genextreme, kendalltau, spearmanr

from datasets import bsds_paths, camera_out, load_rgb, uiqs_items
from exturb import (ExTurbParams, block_maxima, exturb, gev_pwm, grad_mag,
                    luminance)
from render import WATERS, RenderCfg, coefficients, render, to_linear

RES = "/home/claude/results"
P = ExTurbParams(**{k: v for k, v in json.load(open(f"{RES}/exturb_params.json")).items() if k != "lam"})


def step_mosaic(rng, n=512, cells=8):
    """Piecewise-constant Voronoi-like mosaic: every boundary is a step edge."""
    pts = rng.uniform(0, n, (cells * cells, 2))
    yy, xx = np.mgrid[0:n, 0:n]
    d = (yy[..., None] - pts[:, 0]) ** 2 + (xx[..., None] - pts[:, 1]) ** 2
    lab = d.argmin(-1)
    vals = rng.uniform(0.2, 0.8, pts.shape[0])
    return vals[lab]


def e_t1():
    rng = np.random.default_rng(0)
    out = []
    for trial in range(30):
        base = step_mosaic(rng)
        for sig in [0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 5.0]:
            for amp in [0.1, 0.3, 1.0]:
                img = 0.5 + amp * (ndi.gaussian_filter(base, sig) - 0.5)
                img = img + rng.normal(0, 0.002, img.shape)
                p = ExTurbParams(**{**P.__dict__, "weber": False, "work_size": None})
                r = exturb(np.clip(img, 0, 1), p)
                out.append(dict(trial=trial, sigma=sig, amp=amp, sigma_hat=r["sigma_b"], rho=r["rho"]))
    json.dump(out, open(f"{RES}/theory_t1.json", "w"))
    s = np.array([o["sigma"] for o in out])
    h = np.array([o["sigma_hat"] for o in out])
    print("T1 spearman", spearmanr(s, h)[0])


def e_t2():
    rng = np.random.default_rng(1)
    paths = bsds_paths("test")[:40]
    out = []
    for k, pth in enumerate(paths):
        J = to_linear(load_rgb(pth))
        H, W = J.shape[:2]
        for b in [0.02, 0.05, 0.1, 0.2, 0.35, 0.5, 0.75, 1.0, 1.5, 2.0]:
            for dz in [1.0, 2.5]:
                for gain in [0.5, 1.0, 1.5]:
                    I = render(J, np.full((H, W), dz), WATERS["coastal"], b,
                               RenderCfg(res_scale=max(H, W) / 512), rng=rng,
                               noise_sigma=0.004, gain=gain)
                    I = camera_out(I)
                    r = exturb(I, P)
                    _, _, c = coefficients(WATERS["coastal"], b)
                    c550 = float(np.interp(550, [460, 540, 600], c[::-1]))
                    out.append(dict(scene=k, b=b, d=dz, gain=gain, tau=c550 * dz,
                                    Tc=r["T_c"], sigma=r["sigma_b"]))
    json.dump(out, open(f"{RES}/theory_t2.json", "w"))
    tau = np.array([o["tau"] for o in out])
    Tc = np.array([o["Tc"] for o in out])
    m = tau > 1.0
    print("T2 slope (tau>1)", np.polyfit(tau[m], Tc[m], 1))


def e_t3():
    rng = np.random.default_rng(2)
    items = uiqs_items()
    sel = rng.choice(len(items), 200, replace=False)
    ad_pass, rows = 0, []
    t_pwm = t_mle = 0
    for i in sel:
        img = load_rgb(items[i][0])
        L = luminance(img)
        den = ndi.gaussian_filter(L, P.sw) + P.eps
        # use 16-px blocks here so each image yields enough maxima for the test
        m = block_maxima(grad_mag(L, P.s1) / den, 16)
        t = time.perf_counter()
        g = gev_pwm(m)
        t_pwm += time.perf_counter() - t
        t = time.perf_counter()
        c, loc, sc = genextreme.fit(m)
        t_mle += time.perf_counter() - t
        # KS-type check with fitted parameters (descriptive, not exact)
        u = np.sort(genextreme.cdf(m, -g.xi, g.loc, g.scale))
        n = u.size
        ii = np.arange(1, n + 1)
        A2 = -n - np.mean((2 * ii - 1) * (np.log(np.clip(u, 1e-12, 1)) + np.log(np.clip(1 - u[::-1], 1e-12, 1))))
        rows.append(dict(file=items[i][0], grade=items[i][1], n=int(n), loc_pwm=g.loc, loc_mle=float(loc),
                         xi_pwm=g.xi, xi_mle=float(-c), A2=float(A2)))
    json.dump(dict(rows=rows, t_pwm=t_pwm / len(sel), t_mle=t_mle / len(sel)),
              open(f"{RES}/theory_t3.json", "w"))
    A2 = np.array([r["A2"] for r in rows])
    lp = np.array([r["loc_pwm"] for r in rows])
    lm = np.array([r["loc_mle"] for r in rows])
    print("T3 A2 median", np.median(A2), "frac A2<2.5", np.mean(A2 < 2.5),
          "loc corr", np.corrcoef(lp, lm)[0, 1], "t_pwm", t_pwm / len(sel), "t_mle", t_mle / len(sel))


if __name__ == "__main__":
    import sys
    for w in sys.argv[1:]:
        globals()["e_" + w]()
