import sys
from huggingface_hub import snapshot_download
jobs={
 'mft':('mieraehh/5_Malaysian_Fish_Species_in_Turbid_Water',None),
 'uieb':('yxnd150150/uieb_raw',None),
 'euvp':('Ken1053/EUVP',None),
 'suim':('SatwikKambham/suim',None),
 'seathru':('bhowmikabhimanyu/seathru-dataset',None),
}
for k in sys.argv[1:]:
    rid,pat=jobs[k]
    p=snapshot_download(repo_id=rid,repo_type='dataset',local_dir=f'/home/claude/data/{k}',allow_patterns=pat,max_workers=4)
    print('done',k,p,flush=True)
