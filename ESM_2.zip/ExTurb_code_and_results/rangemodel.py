"""Population model of T_c versus beam optical depth, and its inversion.

T_c(c, d) = T_s + ln(1 + beta * (exp(kappa*c*d) - exp((kappa-1)*c*d)))
with G = kappa*c (attenuation of image-forming light as a fraction of c).
T_s, beta, kappa are fitted once on BSDS-UW training renders; c is recovered
from (T_c, d) by bisection because the model is strictly increasing in c.
"""
import numpy as np
from scipy.optimize import least_squares


def model(cd, Ts, beta, kappa):
    cd = np.asarray(cd, float)
    return Ts + np.log1p(beta * (np.exp(kappa * cd) - np.exp((kappa - 1) * cd)))


def fit(Tc, cd):
    def res(p):
        return model(cd, p[0], np.exp(p[1]), 1 / (1 + np.exp(-p[2]))) - Tc
    r = least_squares(res, x0=[np.percentile(Tc, 5), 0.0, -1.0], loss="soft_l1")
    Ts, lb, lk = r.x
    return float(Ts), float(np.exp(lb)), float(1 / (1 + np.exp(-lk)))


def invert(Tc, d, Ts, beta, kappa, cmax=8.0):
    Tc = np.atleast_1d(np.asarray(Tc, float))
    d = np.broadcast_to(np.asarray(d, float), Tc.shape)
    lo = np.full(Tc.shape, 1e-4)
    hi = np.full(Tc.shape, cmax)
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        up = model(mid * d, Ts, beta, kappa) < Tc
        lo = np.where(up, mid, lo)
        hi = np.where(up, hi, mid)
    return 0.5 * (lo + hi)
