"""Experiments added for the revision (synthetic and analytic).

PART=psf     Gaussian-equivalent edge model versus Poisson (the renderer's kernel),
             Moffat and Gaussian line-spread functions: error of the probe-ratio
             inversion over a grid of intrinsic width sigma_0 and scatter width w.
PART=edges   Step edge versus thin line (bar) versus texture: where rho > s2/s1.
PART=camera  Camera-pipeline perturbations on BSDS-UW test renders.
PART=gev     Full GEV parameter (mu, sigma_G, xi) multiscale ablation, BSDS-UW
             train -> BSDS-UW test and KM-UW.
PART=range   Split-conformal interval for the range-aware attenuation estimate c_hat.
"""
import json
import math
import os
import sys

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from scipy import ndimage as ndi
from scipy.stats import kendalltau, spearmanr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exturb import block_maxima, gev_pwm, grad_mag, luminance, resize_long  # noqa: E402

RES = "/home/claude/results"
OUT = f"{RES}/revision"
os.makedirs(OUT, exist_ok=True)
S1, S2 = 1.5, 3.0


# ---------------------------------------------------------------- PSF study
def lsf(kind, w, x):
    """Normalised line-spread functions with width parameter w (px)."""
    if w <= 0:
        f = np.zeros_like(x); f[len(x) // 2] = 1; return f
    if kind == "gauss":
        f = np.exp(-0.5 * (x / w) ** 2)
    elif kind == "poisson":   # OTF exp(-2 pi w |f|)  <=>  Cauchy/Lorentzian LSF, HWHM = w
        f = w / (np.pi * (x ** 2 + w ** 2))
    elif kind == "moffat":    # beta = 2.5, HWHM = w
        a = w / math.sqrt(2 ** (1 / 2.5) - 1)
        f = (1 + (x / a) ** 2) ** -2.5
    return f / f.sum()


def peak_response(profile, s):
    return np.abs(ndi.gaussian_filter1d(profile, s, order=1)).max()


def psf_study():
    x = np.arange(-2048, 2049, dtype=float)
    step = (x >= 0).astype(float)
    rows = []
    for s0 in [0.0, 0.5, 1.0, 1.5]:
        base = ndi.gaussian_filter1d(step, s0) if s0 > 0 else step
        for kind in ["gauss", "poisson", "moffat"]:
            for w in np.round(np.linspace(0, 6, 25), 3):
                prof = np.convolve(base, lsf(kind, w, x), mode="same") if w > 0 else base
                r = peak_response(prof, S1) / peak_response(prof, S2)
                r2 = r * r
                sb = math.sqrt(max((S2 ** 2 - r2 * S1 ** 2) / (r2 - 1), 0)) if r2 > 1 else np.inf
                # matched width: Gaussian of the same HWHM (w in all three kernels is the HWHM
                # for poisson/moffat; for gauss w is sigma)
                sig_f = w if kind == "gauss" else w / math.sqrt(2 * math.log(2))
                true_tot = math.sqrt(s0 ** 2 + sig_f ** 2)
                sf_hat = math.sqrt(max(sb ** 2 - s0 ** 2, 0)) if np.isfinite(sb) else np.inf
                rows.append(dict(sigma0=s0, kind=kind, w=w, rho=r, sigma_hat=sb, sigma_tot=true_tot,
                                 sigma_f=sig_f, sigma_f_hat=sf_hat,
                                 rel_err_tot=(sb - true_tot) / true_tot if true_tot > 0 else np.nan))
    df = pd.DataFrame(rows)
    df.to_csv(f"{OUT}/psf_study.csv", index=False)
    s = df[(df.w > 0)].groupby(["kind", "sigma0"]).rel_err_tot.agg(lambda v: np.nanmedian(np.abs(v)))
    print(s)
    return df


# ------------------------------------------------------------- edge types
def edge_study():
    x = np.arange(-1024, 1025, dtype=float)
    out = {}
    for name, prof in {"step": (x >= 0).astype(float),
                       "bar_1px": (np.abs(x) < 0.5).astype(float),
                       "bar_2px": (np.abs(x) < 1.0).astype(float),
                       "bar_4px": (np.abs(x) < 2.0).astype(float)}.items():
        vals = []
        for s0 in [0.0, 0.5, 1.0, 2.0]:
            p = ndi.gaussian_filter1d(prof, s0) if s0 > 0 else prof
            vals.append(peak_response(p, S1) / peak_response(p, S2))
        out[name] = vals
    print("rho for step and bars at sigma0=0,0.5,1,2:", json.dumps(out, indent=0))
    sim = {}
    for f in ["scores_bsds_test.csv", "scores_km.csv", "scores_range.csv"]:
        d = pd.read_csv(f"{RES}/{f}")
        sim[f] = float((d.ExTurb_rho >= S2 / S1).mean())
    print("fraction rho >= s2/s1 on renders:", sim)
    json.dump({"edges": out, "rho_ge_2_renders": sim}, open(f"{OUT}/edge_study.json", "w"), indent=1)


# ---------------------------------------------------------- camera pipeline
def srgb_to_lin(x):
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4)


def lin_to_srgb(x):
    x = np.clip(x, 0, 1)
    return np.where(x <= 0.0031308, 12.92 * x, 1.055 * x ** (1 / 2.4) - 0.055)


def q8(x):
    return np.round(np.clip(x, 0, 1) * 255) / 255.0


TRANSFORMS = {
    "gain x0.6": lambda im: q8(lin_to_srgb(srgb_to_lin(im) * 0.6)),
    "gain x1.5 (clips)": lambda im: q8(lin_to_srgb(srgb_to_lin(im) * 1.5)),
    "offset +0.05": lambda im: q8(im + 0.05),
    "gamma 0.8": lambda im: q8(im ** 0.8),
    "gamma 1.25": lambda im: q8(im ** 1.25),
    "white balance": lambda im: q8(lin_to_srgb(srgb_to_lin(im) * np.array([1.35, 1.0, 0.75]))),
    "auto-exposure": lambda im: q8(lin_to_srgb(srgb_to_lin(im) * (0.18 / max(
        float(np.mean(srgb_to_lin(im) @ np.array([0.2126, 0.7152, 0.0722]))), 1e-3)))),
    "JPEG q=40": None,
}


def jpeg(im, q=40):
    import io
    from PIL import Image
    buf = io.BytesIO()
    Image.fromarray((im * 255 + 0.5).astype(np.uint8)).save(buf, "JPEG", quality=q)
    return np.asarray(Image.open(buf).convert("RGB"), float) / 255.0


def cam_one(path):
    from baselines import metric_suite
    from compute import frozen_params
    from datasets import load_rgb
    from exturb import exturb
    img = load_rgb(path, 512)
    p, lam = frozen_params()
    suite = metric_suite()
    out = {}
    for tname, fn in [("orig", lambda x: x)] + list(TRANSFORMS.items()):
        im = jpeg(img) if tname.startswith("JPEG") else fn(img)
        r = exturb(im, p)
        out[f"ExTurb|{tname}"] = r["T_c"] + lam * math.log(r["sigma_b"] + 0.25)
        out[f"ExTurb T_c|{tname}"] = r["T_c"]
        for k, f in suite.items():
            try:
                out[f"{k}|{tname}"] = float(f(im))
            except Exception:
                out[f"{k}|{tname}"] = np.nan
    return out


def camera_study(n_scenes=80):
    d = pd.read_csv(f"{RES}/scores_bsds_test.csv")
    scenes = sorted(d.scene.unique())[:n_scenes]
    d = d[d.scene.isin(scenes)].reset_index(drop=True)
    res = Parallel(n_jobs=2, batch_size=4)(delayed(cam_one)(f) for f in d.file)
    R = pd.DataFrame(res)
    R["b550"], R["scene"] = d.b550.values, d.scene.values
    R.to_csv(f"{OUT}/camera_scores.csv", index=False)
    methods = sorted({c.split("|")[0] for c in R.columns if "|" in c})
    rows = []
    for m in methods:
        o = R[f"{m}|orig"].values
        row = {"method": m, "SROCC orig": spearmanr(o, R.b550)[0]}
        for t in TRANSFORMS:
            v = R[f"{m}|{t}"].values
            row[f"stab {t}"] = spearmanr(o, v)[0]
            row[f"SROCC {t}"] = spearmanr(v, R.b550)[0]
        rows.append(row)
    T = pd.DataFrame(rows)
    T.to_csv(f"{OUT}/camera_summary.csv", index=False)
    print(T[["method", "SROCC orig"] + [f"stab {t}" for t in TRANSFORMS]].round(3).to_string())
    print(T[["method"] + [f"SROCC {t}" for t in TRANSFORMS]].round(3).to_string())


# ------------------------------------------------------------- GEV ablation
SCALES = [0.75, 1.5, 3.0, 6.0]


def gev_feats(path):
    from datasets import load_rgb
    img = resize_long(load_rgb(path, 512), 512)
    L = luminance(img)
    den = ndi.gaussian_filter(L, 8.0) + 1e-3
    f = {}
    for s in SCALES:
        W = grad_mag(L, s) / den
        m = block_maxima(W, 32)
        g = gev_pwm(m)
        f[f"mu_{s}"] = math.log(max(g.loc, 1e-9))
        f[f"sg_{s}"] = math.log(max(g.scale, 1e-9))
        f[f"xi_{s}"] = g.xi
        f[f"maxmean_{s}"] = math.log(max(m.mean(), 1e-9))
        f[f"gradmean_{s}"] = math.log(max(W.mean(), 1e-9))
    return f


FEATSETS = {
    "mean Weber gradient (s1)": ["gradmean_1.5"],
    "mean of block maxima (s1)": ["maxmean_1.5"],
    "GEV location (s1) = T_c": ["mu_1.5"],
    "GEV location (s1, s2)": ["mu_1.5", "mu_3.0"],
    "GEV location+scale (s1, s2)": ["mu_1.5", "mu_3.0", "sg_1.5", "sg_3.0"],
    "full GEV (s1, s2)": ["mu_1.5", "mu_3.0", "sg_1.5", "sg_3.0", "xi_1.5", "xi_3.0"],
    "GEV location (4 scales)": [f"mu_{s}" for s in SCALES],
    "full GEV (4 scales)": [f"{p}_{s}" for s in SCALES for p in ("mu", "sg", "xi")],
    "block-maxima mean (4 scales)": [f"maxmean_{s}" for s in SCALES],
}


def lsq(X, y):
    A = np.c_[X, np.ones(len(X))]
    return np.linalg.lstsq(A, y, rcond=None)[0]


def within_k(p, y, g):
    return float(np.nanmean([kendalltau(p[g == s], y[g == s])[0] for s in np.unique(g)]))


def cluster_ci(p, y, g, nb=1000, seed=3):
    rng = np.random.default_rng(seed)
    G = np.unique(g)
    mem = {k: np.where(g == k)[0] for k in G}
    v = []
    for _ in range(nb):
        i = np.concatenate([mem[k] for k in rng.choice(G, len(G))])
        v.append(spearmanr(p[i], y[i])[0])
    return np.percentile(v, [2.5, 97.5])


def gev_study():
    sets = {k: pd.read_csv(f"{RES}/scores_{k}.csv") for k in ["bsds_train", "bsds_test", "km"]}
    feats = {}
    for k, d in sets.items():
        cache = f"{OUT}/gevfeat_{k}.csv"
        if os.path.exists(cache):
            feats[k] = pd.read_csv(cache)
        else:
            feats[k] = pd.DataFrame(Parallel(n_jobs=2, batch_size=8)(delayed(gev_feats)(f) for f in d.file))
            feats[k].to_csv(cache, index=False)
    ytr = np.log(sets["bsds_train"].b550.values)
    rows = []
    for name, cols in FEATSETS.items():
        c = lsq(feats["bsds_train"][cols].values, ytr)
        for k in ["bsds_test", "km"]:
            p = np.c_[feats[k][cols].values, np.ones(len(feats[k]))] @ c
            y = np.log(sets[k].b550.values)
            g = sets[k].scene.values
            lo, hi = cluster_ci(p, y, g)
            rows.append(dict(features=name, n=len(cols), set=k, SROCC=spearmanr(p, y)[0],
                             lo=lo, hi=hi, within=within_k(p, y, g)))
    T = pd.DataFrame(rows)
    T.to_csv(f"{OUT}/gev_ablation.csv", index=False)
    print(T.round(3).to_string())
    # monotonicity of xi with b550 (not assumed): within-scene Kendall of xi_s vs b550
    mono = {}
    for s in SCALES:
        for p in ("xi", "sg"):
            mono[f"{p}_{s}"] = within_k(feats["bsds_test"][f"{p}_{s}"].values,
                                        sets["bsds_test"].b550.values, sets["bsds_test"].scene.values)
    print("within-scene Kendall of GEV scale/shape vs b550 (BSDS test):", json.dumps(mono, indent=0))
    json.dump(mono, open(f"{OUT}/gev_monotonicity.json", "w"), indent=1)


# --------------------------------------------------------- range conformal
def range_study(alpha=0.10, reps=200):
    from rangemodel import invert
    d = pd.read_csv(f"{RES}/scores_range.csv")
    k = json.load(open(f"{RES}/range_constants.json"))
    chat = invert(d.ExTurb_Tc.values, d.dmean.values, k["Ts"], k["beta"], k["kappa"])
    r = np.abs(np.log(chat) - np.log(d.c550.values))
    g = d.scene.values
    G = np.unique(g)
    rng = np.random.default_rng(11)
    cov, wid, cov_cal = [], [], []
    for _ in range(reps):
        cal = rng.choice(G, len(G) // 2, replace=False)
        m = np.isin(g, cal)
        q = np.quantile(r[m], min(1, np.ceil((m.sum() + 1) * (1 - alpha)) / m.sum()))
        cov.append(np.mean(r[~m] <= q))
        wid.append(math.exp(q))
    # one-point calibration variant: per-scene offset removed with one known frame
    out = dict(alpha=alpha, coverage_mean=float(np.mean(cov)), coverage_p05=float(np.percentile(cov, 5)),
               coverage_p95=float(np.percentile(cov, 95)), factor_median=float(np.median(wid)),
               median_rel_err=float(np.median(np.abs(chat - d.c550) / d.c550)))
    # coverage by water type and by optical depth tercile
    cd = d.c550.values * d.dmean.values
    q = np.quantile(r, 1 - alpha)
    out["by_water"] = {w: float(np.mean(r[d.water == w] <= q)) for w in d.water.unique()}
    terc = np.digitize(cd, np.quantile(cd, [1 / 3, 2 / 3]))
    out["by_cd_tercile"] = {int(t): float(np.mean(r[terc == t] <= q)) for t in range(3)}
    print(json.dumps(out, indent=1))
    json.dump(out, open(f"{OUT}/range_conformal.json", "w"), indent=1)
    pd.DataFrame({"c": d.c550, "chat": chat, "d": d.dmean, "water": d.water, "scene": g}).to_csv(
        f"{OUT}/range_pred.csv", index=False)


if __name__ == "__main__":
    part = os.environ.get("PART", "all")
    for name, fn in [("psf", psf_study), ("edges", edge_study), ("range", range_study),
                     ("gev", gev_study), ("camera", camera_study)]:
        if part in ("all", name):
            print(f"===== {name}")
            fn()
