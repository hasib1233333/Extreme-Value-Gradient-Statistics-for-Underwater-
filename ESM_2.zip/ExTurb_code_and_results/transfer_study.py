"""Revision 2, comments 5 and 6: calibration transfer by factor, and conformal coverage after transfer.

Every model is an affine map to ln NTU with the number of inputs shown, fitted on
the training part; q is the split-conformal 90% quantile of |residual| on a
calibration part drawn from the SAME domain as the training part; coverage and
width are then measured on the target domain.

Splits
  cross-dataset   MFT(Train fit, Test calib) -> TUB;  TUB(scenes 1..k fit / rest calib) -> MFT Test
  camera          TUB leave-one-camera-out (fit and calibrate on 3 cameras, test on the 4th)
  scene/background MFT leave-one-species-out (fit on Train of 4 species, calib on their Test, test on Test of 5th)
  turbidity range MFT: fit/calib on NTU < 20, test on NTU >= 20, and reverse; TUB: stages 1-5 -> 6-10, reverse
"""
import json

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

R = "/home/claude/real"
OUT = "/home/claude/results/revision"
ALPHA = 0.1
MODELS = {"ExTurb-C": ["Tc", "lnrho"], "T_c": ["Tc"], "Dynamic range": ["DynRange"],
          "UCIQE": ["UCIQE"], "Tenengrad": ["Tenengrad"], "UCIQE+DynRange": ["UCIQE", "DynRange"]}


def F(df):
    f = pd.DataFrame({"Tc": df.ExTurb_Tc.values, "lnrho": np.log(df.ExTurb_rho.values),
                      "DynRange": df.DynRange.values, "UCIQE": df.UCIQE.values, "Tenengrad": df.Tenengrad.values})
    f["y"] = np.log(df.ntu.values)
    return f


def lsq(X, y):
    return np.linalg.lstsq(np.c_[X, np.ones(len(X))], y, rcond=None)[0]


def pred(c, X):
    return np.c_[X, np.ones(len(X))] @ c


def qconf(r):
    n = len(r)
    return float(np.quantile(r, min(1, np.ceil((n + 1) * (1 - ALPHA)) / n)))


def evaluate(split, fit, cal, test, rows, extra=None):
    for name, cols in MODELS.items():
        c = lsq(fit[cols].values, fit.y.values)
        q = qconf(np.abs(cal.y.values - pred(c, cal[cols].values)))
        p = pred(c, test[cols].values)
        r = np.abs(test.y.values - p)
        ntu, pn = np.exp(test.y.values), np.exp(p)
        rows.append(dict(split=split, model=name, n_test=len(test),
                         SROCC=spearmanr(p, test.y)[0] if test.y.nunique() > 1 else np.nan,
                         medRE=float(np.median(np.abs(pn - ntu) / ntu)),
                         coverage=float(np.mean(r <= q)), width=float(np.exp(q)), **(extra or {})))


def main():
    tr, te, tub = (pd.read_csv(f"{R}/{k}_scores.csv") for k in ("MFT_train", "MFT_test", "TUB"))
    Ftr, Fte, Ft = F(tr), F(te), F(tub)
    rows = []
    # in-domain references
    evaluate("in-domain MFT (Train/Test half A -> half B)", Ftr, Fte.iloc[::2], Fte.iloc[1::2], rows)
    # cross-dataset
    evaluate("MFT -> TUB", Ftr, Fte, Ft, rows)
    g = tub.group.values
    sc = np.unique(g)
    rng = np.random.default_rng(3)
    calsc = rng.choice(sc, len(sc) // 3, replace=False)
    m = np.isin(g, calsc)
    evaluate("TUB -> MFT Test", Ft[~m], Ft[m], Fte, rows)
    # camera: TUB leave-one-camera-out (calibration on held-out scenes of the 3 training cameras)
    for cam in sorted(tub.cam.unique()):
        tr_m = (tub.cam != cam).values
        fit, cal = Ft[tr_m & ~m], Ft[tr_m & m]
        evaluate("TUB leave-one-camera-out", fit, cal, Ft[(tub.cam == cam).values], rows, {"held_out": f"camera {cam}"})
    # scene/background: MFT leave-one-species-out
    for sp in sorted(tr.group.unique()):
        evaluate("MFT leave-one-species-out", Ftr[(tr.group != sp).values], Fte[(te.group != sp).values],
                 Fte[(te.group == sp).values], rows, {"held_out": sp})
    # turbidity range
    thr = 20.0
    lo_tr, hi_tr = Ftr[tr.ntu.values < thr], Ftr[tr.ntu.values >= thr]
    lo_te, hi_te = Fte[te.ntu.values < thr], Fte[te.ntu.values >= thr]
    evaluate("MFT range: NTU<20 -> NTU>=20", lo_tr, lo_te, hi_te, rows)
    evaluate("MFT range: NTU>=20 -> NTU<20", hi_tr, hi_te, lo_te, rows)
    early, late = (tub.stage <= 5).values, (tub.stage > 5).values
    evaluate("TUB range: stages 1-5 -> 6-10", Ft[early & ~m], Ft[early & m], Ft[late], rows)
    evaluate("TUB range: stages 6-10 -> 1-5", Ft[late & ~m], Ft[late & m], Ft[early], rows)
    T = pd.DataFrame(rows)
    T.to_csv(f"{OUT}/transfer_study.csv", index=False)
    # aggregate the leave-one-out splits
    agg = (T.groupby(["split", "model"], sort=False)
             .agg(SROCC=("SROCC", "mean"), medRE=("medRE", "median"), coverage=("coverage", "mean"),
                  cov_min=("coverage", "min"), width=("width", "median")).reset_index())
    agg.to_csv(f"{OUT}/transfer_summary.csv", index=False)
    pd.set_option("display.width", 220)
    print(agg.round(3).to_string())
    # coverage by category after transfer (ExTurb-C and the best single baseline)
    cats = {}
    for name in ("ExTurb-C", "Dynamic range", "UCIQE"):
        cols = MODELS[name]
        c = lsq(Ft[~m][cols].values, Ft[~m].y.values)
        q = qconf(np.abs(Ft[m].y.values - pred(c, Ft[m][cols].values)))
        r = np.abs(Fte.y.values - pred(c, Fte[cols].values))
        cats[name] = {"TUB->MFT by level": {int(L): float(np.mean(r[te.level.values == L] <= q))
                                           for L in sorted(te.level.unique())}}
        c = lsq(Ftr[cols].values, Ftr.y.values)
        q = qconf(np.abs(Fte.y.values - pred(c, Fte[cols].values)))
        r = np.abs(Ft.y.values - pred(c, Ft[cols].values))
        cats[name]["MFT->TUB by stage group"] = {"1-3": float(np.mean(r[tub.stage.values <= 3] <= q)),
                                                "4-7": float(np.mean(r[(tub.stage.values > 3) & (tub.stage.values <= 7)] <= q)),
                                                "8-10": float(np.mean(r[tub.stage.values > 7] <= q))}
        r_in = np.abs(Fte.y.values - pred(c, Fte[cols].values))
        cats[name]["MFT in-domain by level"] = {int(L): float(np.mean(r_in[te.level.values == L] <= q))
                                               for L in sorted(te.level.unique())}
    json.dump(cats, open(f"{OUT}/transfer_coverage_by_category.json", "w"), indent=1)
    print(json.dumps(cats, indent=1))


if __name__ == "__main__":
    main()
