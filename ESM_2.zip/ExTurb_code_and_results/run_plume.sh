#!/bin/sh
cd /home/claude/code
until grep -q PIPELINE_DONE /home/claude/results/pipeline.log; do sleep 30; done
python3 -W ignore exposure_test.py > /home/claude/results/exposure.log 2>&1
python3 -W ignore analysis.py > /home/claude/results/analysis.log 2>&1
python3 -W ignore plume_sim.py fixed > /home/claude/results/plume_fixed.log 2>&1
T=$(python3 -c "import json;print(json.load(open('/home/claude/results/range_constants.json'))['target'])")
echo "target $T" > /home/claude/results/plume_target.txt
python3 -W ignore plume_sim.py adaptive $T > /home/claude/results/plume_adaptive.log 2>&1
python3 -W ignore analysis2.py > /home/claude/results/analysis2.log 2>&1
echo ALL_DONE >> /home/claude/results/plume_target.txt
