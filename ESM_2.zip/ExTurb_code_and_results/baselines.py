"""Training-free baselines. Every function returns a scalar oriented so that a
LARGER value means MORE turbid / lower visibility (quality metrics are negated)."""
from __future__ import annotations

import math
import warnings

import numpy as np
from scipy import ndimage as ndi
from skimage import color

warnings.filterwarnings("ignore")


def _lum(img):
    return 0.2126 * img[..., 0] + 0.7152 * img[..., 1] + 0.0722 * img[..., 2]


# ---------------------------------------------------------------- UCIQE
def uciqe(img):
    """Yang & Sowmya (2015). c1=0.4680, c2=0.2745, c3=0.2576 (CIELab)."""
    lab = color.rgb2lab(np.clip(img, 0, 1))
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    chroma = np.sqrt(a ** 2 + b ** 2)
    sc = chroma.std()
    Ls = np.sort(L.ravel())
    n = Ls.size
    conl = Ls[int(0.99 * (n - 1))] - Ls[int(0.01 * (n - 1))]
    sat = chroma / (np.sqrt(chroma ** 2 + L ** 2) + 1e-9)
    us = sat.mean()
    return 0.4680 * sc + 0.2745 * conl + 0.2576 * us


# ---------------------------------------------------------------- UIQM
def _alpha_trimmed(x, a=0.1):
    x = np.sort(x.ravel())
    k = int(a * x.size)
    return x[k:x.size - k] if x.size - 2 * k > 0 else x


def _uicm(img):
    R, Gc, B = img[..., 0] * 255, img[..., 1] * 255, img[..., 2] * 255
    rg = R - Gc
    yb = (R + Gc) / 2 - B
    rgt, ybt = _alpha_trimmed(rg), _alpha_trimmed(yb)
    mu = math.sqrt(rgt.mean() ** 2 + ybt.mean() ** 2)
    s = math.sqrt(rgt.var() + ybt.var())
    return -0.0268 * mu + 0.1586 * s


def _eme(ch, k=8):
    H, W = ch.shape
    h, w = H // k, W // k
    ch = ch[: h * k, : w * k].reshape(h, k, w, k)
    mx = ch.max(axis=(1, 3))
    mn = ch.min(axis=(1, 3))
    ok = (mn > 0) & (mx > 0)
    r = np.where(ok, mx / np.maximum(mn, 1e-9), 1.0)
    return 2.0 / (h * w) * np.sum(np.log(r))


def _uism(img):
    s = 0
    lam = (0.299, 0.587, 0.114)
    for c in range(3):
        ch = img[..., c] * 255
        sob = np.hypot(ndi.sobel(ch, 0), ndi.sobel(ch, 1))
        s += lam[c] * _eme(sob * ch / 255.0 + 1e-3)
    return s


def _plip_amee(ch, k=8):
    H, W = ch.shape
    h, w = H // k, W // k
    ch = ch[: h * k, : w * k].reshape(h, k, w, k)
    mx = ch.max(axis=(1, 3)).astype(np.float64)
    mn = ch.min(axis=(1, 3)).astype(np.float64)
    gamma = 1026.0
    num = (mx - mn) / (1 - mn * mx / gamma ** 2 + 1e-9)  # PLIP-like
    den = mx + mn + 1e-9
    r = np.clip(num / den, 1e-9, None)
    return -1.0 / (h * w) * np.sum(r * np.log(r))  # sign per Panetta: higher better


def _uiconm(img):
    return _plip_amee(_lum(img) * 255)


def uiqm(img):
    """Panetta, Gao & Agaian (2016): 0.0282 UICM + 0.2953 UISM + 3.5753 UIConM."""
    return 0.0282 * _uicm(img) + 0.2953 * _uism(img) + 3.5753 * _uiconm(img)


# ------------------------------------------------------- dark-channel priors
def _min_filter(x, r=7):
    return ndi.minimum_filter(x, size=2 * r + 1)


def dcp_transmission(img, omega=0.95, r=7):
    dark = _min_filter(img.min(axis=2), r)
    flat = dark.ravel()
    idx = np.argsort(flat)[-max(1, flat.size // 1000):]
    A = img.reshape(-1, 3)[idx].mean(axis=0)
    t = 1 - omega * _min_filter((img / np.maximum(A, 1e-3)).min(axis=2), r)
    return np.clip(t, 0.05, 1)


def udcp_transmission(img, omega=0.95, r=7):
    """Drews et al. (2013): dark channel on G and B only."""
    gb = img[..., 1:]
    dark = _min_filter(gb.min(axis=2), r)
    flat = dark.ravel()
    idx = np.argsort(flat)[-max(1, flat.size // 1000):]
    A = gb.reshape(-1, 2)[idx].mean(axis=0)
    t = 1 - omega * _min_filter((gb / np.maximum(A, 1e-3)).min(axis=2), r)
    return np.clip(t, 0.05, 1)


# ------------------------------------------------ simple contrast / focus
def dynamic_range(img):
    L = _lum(img)
    return np.percentile(L, 99) - np.percentile(L, 1)


def rms_contrast(img):
    L = _lum(img)
    return L.std() / (L.mean() + 1e-6)


def tenengrad(img):
    L = _lum(img)
    return np.mean(ndi.sobel(L, 0) ** 2 + ndi.sobel(L, 1) ** 2)


def lap_var(img):
    return ndi.laplace(_lum(img)).var()


def entropy(img):
    h, _ = np.histogram(_lum(img), bins=256, range=(0, 1))
    p = h / h.sum()
    p = p[p > 0]
    return -np.sum(p * np.log2(p))


# --------------------------------------- phase-congruency delentropy (PCD)
def pcd(img, nscale=6, minWaveLength=2):
    """Contrast-invariant information metric of Ismiroglou et al. (2026):
    delentropy of a phase-congruency gradient field."""
    from phasepack import phasecong
    L = _lum(img)
    M, m, ori, ft, PC, EO, T = phasecong(L, nscale=nscale, minWaveLength=minWaveLength,
                                         norient=2)
    # PC is a list per orientation (0 and 90 deg) -> gradient-like components
    gx, gy = PC[0], PC[1]
    H, xe, ye = np.histogram2d(gx.ravel(), gy.ravel(), bins=64)
    p = H / H.sum()
    p = p[p > 0]
    return -0.5 * np.sum(p * np.log2(p))


# --------------------------------------------------------------- registry
def metric_suite():
    """name -> callable returning turbidity-oriented score (larger = turbid)."""
    return {
        "UCIQE": lambda x: -uciqe(x),
        "UIQM": lambda x: -uiqm(x),
        "DCP": lambda x: -dcp_transmission(x).mean(),
        "UDCP": lambda x: -udcp_transmission(x).mean(),
        "DynRange": lambda x: -dynamic_range(x),
        "RMSC": lambda x: -rms_contrast(x),
        "Tenengrad": lambda x: -math.log(tenengrad(x) + 1e-12),
        "LapVar": lambda x: -math.log(lap_var(x) + 1e-12),
        "Entropy": lambda x: -entropy(x),
        "PCD": lambda x: -pcd(x),
    }
