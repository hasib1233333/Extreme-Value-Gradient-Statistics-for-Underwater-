"""Train-only calibration and held-out evaluation on real NTU data (MFT, TUB).

Protocols
  P1  MFT: fit on official Train split (4320 images), evaluate on Test (540).
  P2  TUB: leave-one-scene-out over its 33 static scenes.
  P3  Transfer: fit on MFT Train -> evaluate on all of TUB, and fit on TUB -> MFT Test.

Every model maps features to ln(NTU) by ordinary least squares fitted on the
training part only. Single-cue baselines get the same treatment (sign and scale
fitted on training data), so their SROCC equals |SROCC| whenever the sign is
learned correctly. The ExTurb calibrated model uses the two extremal cues
(T_c, ln rho). For a like-for-like comparison we also fit the best pair of
baseline cues, the pair chosen by training SROCC only.
"""
import itertools
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy.stats import kendalltau, pearsonr, spearmanr

D = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/real"
OUT = os.path.join(D, "calib")
os.makedirs(OUT, exist_ok=True)
BASE = ["UCIQE", "UIQM", "DCP", "UDCP", "DynRange", "RMSC", "Tenengrad", "LapVar", "Entropy", "PCD"]
RNG = np.random.default_rng(2026)
NB = 2000


def feats(df):
    f = pd.DataFrame({"Tc": df.ExTurb_Tc, "lnrho": np.log(df.ExTurb_rho),
                      "ExTurb_raw": df.ExTurb})
    for b in BASE:
        f[b] = df[b]
    return f


MODELS = {"ExTurb (frozen, uncalibrated)": ["ExTurb_raw"],
          "ExTurb T_c only": ["Tc"],
          "ExTurb-C (T_c + ln rho)": ["Tc", "lnrho"]}
MODELS.update({b: [b] for b in BASE})


def fit(X, y):
    A = np.c_[X, np.ones(len(X))]
    return np.linalg.lstsq(A, y, rcond=None)[0]


def predict(coef, X):
    return np.c_[X, np.ones(len(X))] @ coef


def best_pair(F, y):
    best, bp = -1, None
    for a, b in itertools.combinations(BASE, 2):
        X = F[[a, b]].values
        s = spearmanr(predict(fit(X, y), X), y)[0]
        if s > best:
            best, bp = s, [a, b]
    return bp


def metrics(p, y, g=None):
    ntu, pn = np.exp(y), np.exp(p)
    m = dict(SROCC=spearmanr(p, y)[0], KROCC=kendalltau(p, y)[0], PLCC=pearsonr(pn, ntu)[0],
             medrel=float(np.median(np.abs(pn - ntu) / ntu)),
             RMSE=float(np.sqrt(np.mean((pn - ntu) ** 2))))
    if g is not None:
        ks = [kendalltau(p[g == k], y[g == k])[0] for k in np.unique(g) if (g == k).sum() > 2]
        m["within"] = float(np.nanmean(ks))
    return m


def paired_boot(pa, pb, y, g=None):
    """Bootstrap of SROCC(a) - SROCC(b); clusters resampled when g is given."""
    n = len(y)
    if g is None:
        idx = [RNG.integers(0, n, n) for _ in range(NB)]
    else:
        groups = np.unique(g)
        members = {k: np.where(g == k)[0] for k in groups}
        idx = [np.concatenate([members[k] for k in RNG.choice(groups, len(groups))]) for _ in range(NB)]
    d = np.array([spearmanr(pa[i], y[i])[0] - spearmanr(pb[i], y[i])[0] for i in idx])
    obs = spearmanr(pa, y)[0] - spearmanr(pb, y)[0]
    p = 2 * min((d <= 0).mean(), (d >= 0).mean())
    return obs, np.percentile(d, 2.5), np.percentile(d, 97.5), max(p, 1 / NB)


def holm(ps):
    order = np.argsort(ps)
    adj = np.empty(len(ps))
    run = 0
    for r, i in enumerate(order):
        run = max(run, min(1, (len(ps) - r) * ps[i]))
        adj[i] = run
    return adj


def evaluate(tag, preds, y, g=None, ref="ExTurb-C (T_c + ln rho)"):
    rows = []
    for k, p in preds.items():
        rows.append({"protocol": tag, "model": k, **metrics(p, y, g)})
    tab = pd.DataFrame(rows)
    comp = [k for k in preds if k != ref]
    tests = [paired_boot(preds[ref], preds[k], y, g) for k in comp]
    adj = holm(np.array([t[3] for t in tests]))
    sig = pd.DataFrame({"protocol": tag, "vs": comp, "dSROCC": [t[0] for t in tests],
                        "lo": [t[1] for t in tests], "hi": [t[2] for t in tests],
                        "p": [t[3] for t in tests], "p_holm": adj})
    return tab, sig


def run_fixed(tag, Ftr, ytr, Fte, yte, gte=None):
    preds, coefs = {}, {}
    for k, cols in MODELS.items():
        c = fit(Ftr[cols].values, ytr)
        preds[k] = predict(c, Fte[cols].values)
        coefs[k] = c.tolist()
    bp = best_pair(Ftr, ytr)
    c = fit(Ftr[bp].values, ytr)
    preds["Best baseline pair (" + "+".join(bp) + ")"] = predict(c, Fte[bp].values)
    coefs["pair"] = {"cols": bp, "coef": c.tolist()}
    return preds, coefs


def run_loso(F, y, g):
    preds = {k: np.zeros(len(y)) for k in MODELS}
    pair_pred = np.zeros(len(y))
    pairs = []
    for k in np.unique(g):
        tr, te = g != k, g == k
        for m, cols in MODELS.items():
            preds[m][te] = predict(fit(F[cols].values[tr], y[tr]), F[cols].values[te])
        bp = best_pair(F[tr], y[tr])
        pairs.append("+".join(bp))
        pair_pred[te] = predict(fit(F[bp].values[tr], y[tr]), F[bp].values[te])
    top = pd.Series(pairs).value_counts()
    preds[f"Best baseline pair (per fold; most often {top.index[0]})"] = pair_pred
    return preds, top.to_dict()


def main():
    mtr = pd.read_csv(f"{D}/MFT_train_scores.csv")
    mte = pd.read_csv(f"{D}/MFT_test_scores.csv")
    tub = pd.read_csv(f"{D}/TUB_scores.csv")
    Ftr, Fte, Ft = feats(mtr), feats(mte), feats(tub)
    ytr, yte, yt = np.log(mtr.ntu.values), np.log(mte.ntu.values), np.log(tub.ntu.values)
    gt = tub.group.values
    tabs, sigs, info = [], [], {}

    p1, c1 = run_fixed("P1 MFT Train->Test", Ftr, ytr, Fte, yte)
    info["P1_coefs"] = c1
    t, s = evaluate("P1 MFT Train->Test", p1, yte)
    tabs.append(t); sigs.append(s)
    pd.DataFrame({"ntu": mte.ntu, "level": mte.level,
                  **{k: np.exp(v) for k, v in p1.items()}}).to_csv(f"{OUT}/P1_pred.csv", index=False)

    p2, top = run_loso(Ft, yt, gt)
    info["P2_pairs"] = top
    t, s = evaluate("P2 TUB leave-one-scene-out", p2, yt, gt)
    tabs.append(t); sigs.append(s)
    pd.DataFrame({"ntu": tub.ntu, "group": gt, "stage": tub.stage,
                  **{k: np.exp(v) for k, v in p2.items()}}).to_csv(f"{OUT}/P2_pred.csv", index=False)

    p3, c3 = run_fixed("P3a MFT Train->TUB", Ftr, ytr, Ft, yt, gt)
    t, s = evaluate("P3a MFT Train->TUB", p3, yt, gt)
    tabs.append(t); sigs.append(s)
    p4, c4 = run_fixed("P3b TUB->MFT Test", Ft, yt, Fte, yte)
    t, s = evaluate("P3b TUB->MFT Test", p4, yte)
    tabs.append(t); sigs.append(s)
    info["P3a_coefs"], info["P3b_coefs"] = c3, c4

    # raw cue sign on each dataset (training data only) for the cue-contrast figure
    cues = ["Tc", "lnrho"] + BASE
    info["cue_srocc"] = {"MFT Train": {c: spearmanr(Ftr[c], ytr)[0] for c in cues},
                         "TUB": {c: spearmanr(Ft[c], yt)[0] for c in cues}}
    info["sigma_zero_frac"] = {"MFT Train": float((mtr.ExTurb_sigma == 0).mean()),
                               "MFT Test": float((mte.ExTurb_sigma == 0).mean()),
                               "TUB": float((tub.ExTurb_sigma == 0).mean())}
    info["rho_median"] = {"MFT": float(mtr.ExTurb_rho.median()), "TUB": float(tub.ExTurb_rho.median())}
    pd.concat(tabs).to_csv(f"{OUT}/real_metrics.csv", index=False)
    pd.concat(sigs).to_csv(f"{OUT}/real_significance.csv", index=False)
    with open(f"{OUT}/real_info.json", "w") as f:
        json.dump(info, f, indent=1, default=float)
    pd.set_option("display.width", 200)
    print(pd.concat(tabs).round(3).to_string())
    print(pd.concat(sigs).round(4).to_string())
    print(json.dumps({k: info[k] for k in ("P2_pairs", "sigma_zero_frac", "rho_median")}, indent=1))
    print("P1 ExTurb-C coef", c1["ExTurb-C (T_c + ln rho)"], "pair", c1["pair"])
    print("P3b ExTurb-C coef", c4["ExTurb-C (T_c + ln rho)"])


if __name__ == "__main__":
    main()
