import numpy as np
from scipy import ndimage as ndi
def dead_leaves(H=512,W=512,rng=None,rmin=3,rmax=200,alpha=3.0,n=6000,color=True,edge_sigma=0.6):
    rng=rng or np.random.default_rng()
    img=np.full((H,W,3),-1.0); filled=np.zeros((H,W),bool)
    yy,xx=np.mgrid[0:H,0:W]
    # power-law radii p(r) ~ r^-alpha on [rmin,rmax]
    u=rng.random(n)
    a1=1-alpha
    r=( (rmax**a1-rmin**a1)*u + rmin**a1 )**(1/a1)
    for k in range(n):
        if filled.all(): break
        cx,cy=rng.uniform(-rmax/4,W+rmax/4),rng.uniform(-rmax/4,H+rmax/4); rr=r[k]
        x0,x1=int(max(cx-rr,0)),int(min(cx+rr+1,W)); y0,y1=int(max(cy-rr,0)),int(min(cy+rr+1,H))
        if x0>=x1 or y0>=y1: continue
        m=((xx[y0:y1,x0:x1]-cx)**2+(yy[y0:y1,x0:x1]-cy)**2<=rr*rr)&~filled[y0:y1,x0:x1]
        if not m.any(): continue
        col=rng.uniform(0.05,0.95,3) if color else np.repeat(rng.uniform(0.05,0.95),3)
        sub=img[y0:y1,x0:x1]; sub[m]=col; filled[y0:y1,x0:x1]|=m
    img[~filled]=0.5
    return ndi.gaussian_filter(img,(edge_sigma,edge_sigma,0))
