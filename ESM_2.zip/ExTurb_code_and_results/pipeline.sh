#!/bin/sh
set -x
cd /home/claude/code
until grep -q BUILD_DONE /home/claude/results/build.log; do sleep 20; done
python3 -W ignore export_syndl.py
for s in bsds_test km syndl bsds_train range; do python3 -W ignore compute.py $s /home/claude/bench/$s.csv; done
for s in uiqs uccs u45 euvp; do python3 -W ignore compute.py $s $s; done
python3 -W ignore compute.py robust /home/claude/bench/robust.csv
python3 -W ignore cnn_baseline.py train > /home/claude/results/cnn.log 2>&1
python3 -W ignore theory_exp.py t1 t2 t3 > /home/claude/results/theory.log 2>&1
python3 -W ignore ablation.py ablate > /home/claude/results/ablation.log 2>&1
python3 -W ignore ablation.py sens > /home/claude/results/sens.log 2>&1
python3 -W ignore exposure_test.py > /home/claude/results/exposure.log 2>&1
echo PIPELINE_DONE
