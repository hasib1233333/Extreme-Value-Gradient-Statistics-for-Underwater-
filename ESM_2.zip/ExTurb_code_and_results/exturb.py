"""ExTurb: extremal-statistics turbidity estimator.

Core idea
---------
Turbid water acts on an image in three ways: it attenuates edge contrast
(exp(-c d)), adds a smooth veiling light B(1-exp(-c d)), and widens edges by
small-angle forward scattering. All three lower the *largest* local gradients
relative to the local brightness.  We summarise those largest gradients with
block maxima, fit a generalised extreme value (GEV) law by probability-weighted
moments (closed form, no iterations), and read two numbers off the fit:

  * contrast index  T_c = -ln mu_W(s1)        (Weber-normalised maxima)
  * blur probe      rho  = mu(s1) / mu(s2)     -> sigma_b (closed form)

The probe ratio is invariant to any multiplicative change of edge amplitude
(attenuation, exposure, scene contrast), so sigma_b isolates forward scatter.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np
from scipy import ndimage as ndi
from scipy.special import gamma as G

EULER = 0.5772156649015329


# ----------------------------------------------------------------- utilities
def luminance(img: np.ndarray, mode: str = "lum") -> np.ndarray:
    """img: float RGB in [0,1] (H,W,3) or gray (H,W)."""
    if img.ndim == 2:
        return img.astype(np.float64)
    img = img.astype(np.float64)
    if mode == "lum":
        return 0.2126 * img[..., 0] + 0.7152 * img[..., 1] + 0.0722 * img[..., 2]
    if mode == "green":
        return img[..., 1]
    if mode == "max":
        return img.max(axis=2)
    raise ValueError(mode)


def grad_mag(L: np.ndarray, s: float) -> np.ndarray:
    gx = ndi.gaussian_filter(L, s, order=(0, 1), mode="reflect")
    gy = ndi.gaussian_filter(L, s, order=(1, 0), mode="reflect")
    return np.hypot(gx, gy)


def block_maxima(M: np.ndarray, b: int) -> np.ndarray:
    H, W = M.shape
    h, w = H // b, W // b
    M = M[: h * b, : w * b].reshape(h, b, w, b)
    return M.max(axis=(1, 3)).ravel()


# ------------------------------------------------------------ GEV via PWM
@dataclass
class GEV:
    loc: float
    scale: float
    xi: float  # shape (xi>0 heavy tail), Hosking k = -xi


def gev_pwm(x: np.ndarray) -> GEV:
    """Hosking, Wallis & Wood (1985) probability-weighted-moment GEV fit."""
    x = np.sort(np.asarray(x, dtype=np.float64))
    n = x.size
    if n < 8:
        raise ValueError("too few maxima")
    i = np.arange(1, n + 1)
    b0 = x.mean()
    b1 = np.sum((i - 1) / (n - 1) * x) / n
    b2 = np.sum((i - 1) * (i - 2) / ((n - 1) * (n - 2)) * x) / n
    den = 3 * b2 - b0
    if abs(den) < 1e-300:
        return GEV(b0, 0.0, 0.0)
    c = (2 * b1 - b0) / den - math.log(2) / math.log(3)
    k = 7.8590 * c + 2.9554 * c * c
    if abs(k) < 1e-6:  # Gumbel limit
        a = (2 * b1 - b0) / math.log(2)
        return GEV(b0 - EULER * a, a, 0.0)
    k = float(np.clip(k, -0.9, 5.0))
    a = (2 * b1 - b0) * k / (G(1 + k) * (1 - 2.0 ** (-k)))
    loc = b0 + a * (G(1 + k) - 1) / k
    return GEV(loc, a, -k)


def gumbel_mom(x: np.ndarray) -> GEV:
    a = np.std(x) * math.sqrt(6) / math.pi
    return GEV(np.mean(x) - EULER * a, a, 0.0)


# ----------------------------------------------------------------- estimator
@dataclass
class ExTurbParams:
    s1: float = 1.0          # fine probe scale (px)
    s2: float = 2.0          # coarse probe scale (px)
    block: int = 16          # block size for maxima (px)
    sw: float = 8.0          # local-mean scale for Weber normalisation (px)
    eps: float = 1e-3        # Weber regulariser
    channel: str = "lum"
    fit: str = "pwm"         # pwm | gumbel | mean | median
    weber: bool = True
    work_size: int = 512     # long side after resizing (None = native)


def _summary(x, fit):
    if fit == "pwm":
        return gev_pwm(x).loc
    if fit == "gumbel":
        return gumbel_mom(x).loc
    if fit == "mean":
        return float(np.mean(x))
    if fit == "median":
        return float(np.median(x))
    raise ValueError(fit)


def resize_long(img: np.ndarray, long_side: int | None) -> np.ndarray:
    if long_side is None:
        return img
    H, W = img.shape[:2]
    f = long_side / max(H, W)
    if abs(f - 1) < 1e-6:
        return img
    zoom = (f, f) + ((1,) if img.ndim == 3 else ())
    if f < 1:  # anti-alias before decimation
        sig = (0.5 / f, 0.5 / f) + ((0,) if img.ndim == 3 else ())
        img = ndi.gaussian_filter(img, sig)
    return ndi.zoom(img, zoom, order=1)


def exturb(img: np.ndarray, p: ExTurbParams = ExTurbParams()) -> dict:
    img = resize_long(np.clip(img, 0, 1), p.work_size)
    L = luminance(img, p.channel)
    if p.weber:
        den = ndi.gaussian_filter(L, p.sw) + p.eps
    else:
        den = 1.0
    g1 = grad_mag(L, p.s1) / den
    g2 = grad_mag(L, p.s2) / den
    m1 = block_maxima(g1, p.block)
    m2 = block_maxima(g2, p.block)
    mu1 = max(_summary(m1, p.fit), 1e-9)
    mu2 = max(_summary(m2, p.fit), 1e-9)
    rho = mu1 / mu2
    r2 = rho * rho
    if r2 > 1 + 1e-9:
        sb2 = (p.s2 ** 2 - r2 * p.s1 ** 2) / (r2 - 1)
    else:
        sb2 = 1e6
    # The inversion of Proposition 3 has a solution only for 1 < rho < s2/s1.
    # Outside that range the width is NOT zero: the model cannot recover it.
    valid = (r2 > 1 + 1e-9) and (rho < p.s2 / p.s1)
    sb = math.sqrt(max(sb2, 0.0))
    gev1 = gev_pwm(m1)
    return {
        "T_c": -math.log(mu1),     # contrast index (higher = more turbid)
        "rho": rho,
        "sigma_valid": bool(valid),                      # inversion inside its domain
        "sigma_b_est": sb if valid else float("nan"),    # total edge width, NaN = not recoverable
        "sigma_b": sb if valid else 0.0,  # value used by the frozen index: an invalid inversion
                                          # contributes nothing (fallback T_c + lam*ln(sigma_star))
        "xi": gev1.xi,
        "gev_scale": gev1.scale,
        "mu1": mu1,
        "mu2": mu2,
    }


def exturb_index(img, p: ExTurbParams = ExTurbParams()) -> float:
    """Primary scalar output (larger = more turbid)."""
    return exturb(img, p)["T_c"]
