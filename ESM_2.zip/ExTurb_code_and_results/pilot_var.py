import numpy as np, glob, sys
from skimage import io
from scipy.stats import spearmanr
from exturb import exturb, ExTurbParams
root='/home/claude/gitdata/Realworld-Underwater-Image-Enhancement-RUIE-Benchmark/UIQS'
rng=np.random.default_rng(1)
V={'base':ExTurbParams(work_size=None),
 'noweber':ExTurbParams(work_size=None,weber=False),
 'mean':ExTurbParams(work_size=None,fit='mean'),
 'b8':ExTurbParams(work_size=None,block=8),
 'b32':ExTurbParams(work_size=None,block=32),
 's07':ExTurbParams(work_size=None,s1=0.7,s2=1.4),
 's15':ExTurbParams(work_size=None,s1=1.5,s2=3),
 'sw4':ExTurbParams(work_size=None,sw=4),
 'sw16':ExTurbParams(work_size=None,sw=16),
 'green':ExTurbParams(work_size=None,channel='green'),
 'max':ExTurbParams(work_size=None,channel='max'),
}
ys=[];out={k:[] for k in V}; extra={'sb':[],'xi':[],'sc':[]}
for gi,g in enumerate('ABCDE'):
    fs=sorted(glob.glob(f'{root}/{g}/*')); fs=[fs[i] for i in rng.choice(len(fs),50,replace=False)]
    for f in fs:
        im=io.imread(f)[...,:3]/255.0; ys.append(gi)
        for k,p in V.items():
            r=exturb(im,p); out[k].append(r['T_c'])
            if k=='base': extra['sb'].append(r['sigma_b']);extra['xi'].append(r['xi']);extra['sc'].append(np.log(r['gev_scale']+1e-12))
for k in out: print(k, round(spearmanr(ys,out[k])[0],3))
for k in extra: print(k, round(spearmanr(ys,extra[k])[0],3))
