import numpy as np, itertools, json, pickle
from joblib import Parallel, delayed
from scipy.stats import spearmanr
from datasets import syndl_scene, render_sample, B_LEVELS
from exturb import exturb, ExTurbParams
WT=['oceanic','coastal','harbor']
def make(i):
    rng=np.random.default_rng(i); J=syndl_scene(i)
    out=[]
    w=WT[i%3]
    for b in B_LEVELS:
        I,d=render_sample(J,rng,b,w,layers=6); out.append((I,b,w,float(d.mean())))  # SynDL was rendered with 6 depth layers
    return out
data=sum(Parallel(n_jobs=2)(delayed(make)(i) for i in range(60)),[])
pickle.dump(data,open('/home/claude/results/syndl.pkl','wb'))
ys=np.array([x[1] for x in data])
grid=list(itertools.product([0.7,1.0,1.5],[2.0,3.0],[8,16,32],[4,8,16]))
def ev(g):
    s1,k,bl,sw=g; p=ExTurbParams(s1=s1,s2=s1*k,block=bl,sw=sw)
    R=[exturb(x[0],p) for x in data]
    Tc=np.array([r['T_c'] for r in R]); sb=np.array([r['sigma_b'] for r in R])
    res={}
    for lam in [0,0.25,0.5,1.0,2.0]:
        T=Tc+lam*np.log(sb+0.25)
        res[lam]=spearmanr(ys,T)[0]
    return g,res,spearmanr(ys,sb)[0]
out=Parallel(n_jobs=2)(delayed(ev)(g) for g in grid)
best=max(((r[l],g,l) for g,r,_ in out for l in r))
print('best',best)
for g,r,s in sorted(out,key=lambda z:-max(z[1].values()))[:12]: print(g,{k:round(v,3) for k,v in r.items()},'sb',round(s,3))
json.dump([[list(g),{str(k):v for k,v in r.items()},s] for g,r,s in out],open('/home/claude/results/tune_syndl.json','w'))
