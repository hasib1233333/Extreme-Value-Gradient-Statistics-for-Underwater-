"""Revision 3, comment 6: what drives the probe ratio rho?

Factorial renders of 20 BSDS500 test scenes with independent factors:
  turbidity  b550 in {0.05, 0.2, 0.5, 1.0, 1.5} m^-1
  noise      sigma_n in {0.002, 0.01, 0.03} (linear units, before 8-bit encoding)
  exposure   gain in {0.5, 1.0}
  texture    original scene, or scene low-passed (Gaussian 1.5 px) to remove thin structures
Water type coastal, fixed mean range 2.5 m, no JPEG. For every render we record rho,
validity (1 < rho < s2/s1), T_c and the Weber-normalised noise level.
"""
import itertools
import json
import os
import sys

import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from scipy import ndimage as ndi
from scipy.stats import spearmanr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from compute import frozen_params  # noqa: E402
from datasets import bsds_paths, load_rgb, render_sample  # noqa: E402
from exturb import exturb  # noqa: E402

OUT = "/home/claude/results/revision"
B = [0.05, 0.2, 0.5, 1.0, 1.5]
NOISE = [0.002, 0.01, 0.03]
GAIN = [0.5, 1.0]
TEX = ["original", "low-pass"]


def one(path, scene, b, nz, g, tex):
    J = load_rgb(path, 384)
    if tex == "low-pass":
        J = ndi.gaussian_filter(J, (1.5, 1.5, 0))
    rng = np.random.default_rng(1000 * scene + 7)  # same depth map for every factor level
    depth = None
    img, _ = render_sample(J, rng, b, "coastal", dmean=2.5, gain=g, noise=nz, jpeg_q=None, depth=depth)
    p, lam = frozen_params()
    r = exturb(img, p)
    return dict(scene=scene, b550=b, noise=nz, gain=g, texture=tex, rho=r["rho"], Tc=r["T_c"],
                valid=bool(1 < r["rho"] < p.s2 / p.s1))


def main():
    paths = bsds_paths("test")[:20]
    jobs = [(p, i, b, nz, g, t) for i, p in enumerate(paths) for b, nz, g, t in itertools.product(B, NOISE, GAIN, TEX)]
    res = Parallel(n_jobs=2, batch_size=8)(delayed(one)(*j) for j in jobs)
    D = pd.DataFrame(res)
    D.to_csv(f"{OUT}/sim_rho.csv", index=False)
    summ = D.groupby(["texture", "noise", "b550"]).agg(valid=("valid", "mean"), rho=("rho", "median")).reset_index()
    summ.to_csv(f"{OUT}/sim_rho_summary.csv", index=False)
    pd.set_option("display.width", 200)
    print(summ.pivot_table(index=["texture", "noise"], columns="b550", values="valid").round(2))
    print(summ.pivot_table(index=["texture", "noise"], columns="b550", values="rho").round(2))
    # within-scene direction of rho with turbidity, per factor cell
    trend = {}
    for (tex, nz, g), d in D.groupby(["texture", "noise", "gain"]):
        taus = [spearmanr(x.b550, x.rho)[0] for _, x in d.groupby("scene")]
        trend[f"{tex}|{nz}|{g}"] = float(np.nanmedian(taus))
    print(json.dumps(trend, indent=1))
    # variance decomposition of rho (main effects, sums of squares)
    tot = ((D.rho - D.rho.mean()) ** 2).sum()
    ss = {f: float(D.groupby(f).rho.apply(lambda v: len(v) * (v.mean() - D.rho.mean()) ** 2).sum() / tot)
          for f in ["b550", "noise", "gain", "texture", "scene"]}
    print("share of rho variance by main effect:", json.dumps(ss, indent=1))
    json.dump({"trend": trend, "ss": ss}, open(f"{OUT}/sim_rho.json", "w"), indent=1)


if __name__ == "__main__":
    main()
