"""Rewrite decimal macros (|x|<1) in scientific notation, per author preference."""
import re
P = "/home/claude/paper/results_macros.tex"
SKIP = {"FriedmanChi"}


def conv(v):
    def one(m):
        s = m.group(0)
        x = float(s)
        if x == 0 or abs(x) >= 1:
            return s
        e = 0
        mant = x
        while abs(mant) < 1:
            mant *= 10
            e -= 1
        sign = "+" if s.startswith("+") else ""
        return f"\\ensuremath{{{sign}{mant:.2f}\\times10^{{{e}}}}}"
    if "\\times" in v:
        return v
    return re.sub(r"[+-]?\d+\.\d+", one, v)


src = open(P).read()
out = []
for line in src.splitlines():
    m = re.match(r"(\\expandafter\\def\\csname R@)([A-Za-z0-9]+)(\\endcsname\{)(.*)(\})$", line)
    if m and m.group(2) not in SKIP:
        line = m.group(1) + m.group(2) + m.group(3) + conv(m.group(4)) + m.group(5)
    out.append(line)
NAMES = {"LapVar": "Laplacian variance", "DynRange": "dynamic range", "RMSC": "RMS contrast"}
out = [re.sub(r"\{(LapVar|DynRange|RMSC)\}$", lambda m: "{" + NAMES[m.group(1)] + "}", ln) for ln in out]
open(P, "w").write("\n".join(out) + "\n")
print("ok")
