"""Per-image gradient statistics for the calibrated-feature comparison (revision 2).

For every image we compute, at the two probe scales s1=1.5 and s2=3 px of the
frozen ExTurb configuration, a family of summaries of the Weber-normalised
gradient map W_s and of its 32x32 block maxima:
  gmean   mean of W_s                        (no extremes)
  gq90    90th percentile of W_s             (upper quantile of all pixels)
  gq99    99th percentile of W_s
  bmean   mean of block maxima
  bmed    median of block maxima
  mu      GEV location (PWM)  -> ExTurb's T_c = -ln mu(s1)
  sg, xi  GEV scale and shape (PWM)
plus the noise-floor estimate sigma_n (MAD of the finest Laplacian residual,
Immerkaer-style) and its Weber-normalised version, for a noise-referenced cue.

Usage (same folders as run_real_ntu.py):
  python extract_features.py --mft_dir "...\\data\\mft" --tub_dir "...\\data\\tub"
Writes results_real/features_MFT.csv and results_real/features_TUB.csv.
"""
import argparse
import csv
import glob
import math
import os

import numpy as np
from joblib import Parallel, delayed
from scipy import ndimage as ndi

from datasets import load_rgb
from exturb import block_maxima, gev_pwm, grad_mag, luminance, resize_long
from run_real_ntu import IMG_EXT, TUB_RE, _mft_xlsx_labels, _tub_ntu_table

S = (1.5, 3.0)
OUT = "results_real"


def noise_sigma(L):
    """Immerkaer (1996) fast noise variance estimate on the luminance image."""
    k = np.array([[1, -2, 1], [-2, 4, -2], [1, -2, 1]], float)
    r = ndi.convolve(L, k, mode="reflect")
    H, W = L.shape
    return float(math.sqrt(math.pi / 2) * np.abs(r[1:-1, 1:-1]).sum() / (6 * (W - 2) * (H - 2)))


def feats(path):
    img = resize_long(load_rgb(path, 512), 512)
    L = luminance(img)
    m = ndi.gaussian_filter(L, 8.0) + 1e-3
    out = {}
    for s in S:
        W = grad_mag(L, s) / m
        bm = block_maxima(W, 32)
        g = gev_pwm(bm)
        t = f"{s:g}"
        out[f"gmean_{t}"] = float(W.mean())
        out[f"gq90_{t}"] = float(np.percentile(W, 90))
        out[f"gq99_{t}"] = float(np.percentile(W, 99))
        out[f"bmean_{t}"] = float(bm.mean())
        out[f"bmed_{t}"] = float(np.median(bm))
        out[f"mu_{t}"] = float(g.loc)
        out[f"sg_{t}"] = float(g.scale)
        out[f"xi_{t}"] = float(g.xi)
    sn = noise_sigma(L)
    out["noise"] = sn
    out["noise_weber"] = sn / float(np.median(m))
    out["lum_mean"] = float(L.mean())
    out["clip_frac"] = float(np.mean(img.max(axis=2) >= 254.5 / 255))
    return out


def run(items, name):
    os.makedirs(OUT, exist_ok=True)
    res = Parallel(n_jobs=-1, batch_size=8, verbose=5)(delayed(feats)(p) for p, _ in items)
    keys = list(items[0][1].keys()) + list(res[0].keys())
    with open(f"{OUT}/features_{name}.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for (_, meta), r in zip(items, res):
            w.writerow({**meta, **r})
    print("wrote", f"{OUT}/features_{name}.csv", len(res))


def mft_items(mft_dir):
    meta = _mft_xlsx_labels(os.path.join(mft_dir, "Multimodal Metadata.xlsx"))
    items = []
    for lvl_dir in sorted(glob.glob(os.path.join(mft_dir, "Turbidity *"))):
        k = int(os.path.basename(lvl_dir).split()[-1])
        for sp_dir in sorted(glob.glob(os.path.join(lvl_dir, "*", "*"))):
            split = os.path.basename(os.path.dirname(sp_dir))
            for p in sorted(glob.glob(os.path.join(sp_dir, "*"))):
                if p.lower().endswith(IMG_EXT):
                    stem = os.path.splitext(os.path.basename(p))[0]
                    rel = os.path.relpath(p, mft_dir).replace("\\", "/")
                    items.append((p, {"file": rel, "split": split, "level": k,
                                      "group": os.path.basename(sp_dir), "ntu": meta.get(stem, float("nan"))}))
    return items


def tub_items(tub_dir):
    table = _tub_ntu_table(os.path.join(tub_dir, "av_turbidity.csv"))
    items = []
    for p in sorted(glob.glob(os.path.join(tub_dir, "images", "*"))):
        m = TUB_RE.search(os.path.basename(p))
        if m and p.lower().endswith(IMG_EXT):
            e, cam, st = int(m.group(1)), int(m.group(2)), int(m.group(3))
            items.append((p, {"file": "images/" + os.path.basename(p), "group": f"Exp{e}", "cam": cam,
                              "stage": st, "ntu": table.get((e, st), float("nan"))}))
    return items


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mft_dir")
    ap.add_argument("--tub_dir")
    a = ap.parse_args()
    if a.tub_dir:
        run(tub_items(a.tub_dir), "TUB")
    if a.mft_dir:
        run(mft_items(a.mft_dir), "MFT")
