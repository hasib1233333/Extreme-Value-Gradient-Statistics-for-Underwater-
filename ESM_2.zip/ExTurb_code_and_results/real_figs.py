"""Figures for the revision: real-data NTU validation and PSF-approximation study."""
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from scipy.stats import spearmanr  # noqa: E402

R = "/home/claude/real"
C = f"{R}/calib"
REV = "/home/claude/results/revision"
PAP = "/home/claude/paper/figs"
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"], "mathtext.fontset": "stix",
    "font.size": 9, "axes.labelsize": 9, "axes.titlesize": 8.5, "legend.fontsize": 7,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "axes.linewidth": 0.6, "lines.linewidth": 1.0,
    "axes.grid": True, "grid.color": "0.88", "grid.linewidth": 0.4, "axes.edgecolor": "0.15",
    "savefig.dpi": 600, "savefig.bbox": "tight", "savefig.pad_inches": 0.02, "legend.frameon": False})
EC = "ExTurb-C (T_c + ln rho)"


def pv_panel(ax, ntu, pred, q, title, group=None):
    lo, hi = 1, 80
    xs = np.geomspace(lo, hi, 50)
    ax.fill_between(xs, xs * np.exp(-q), xs * np.exp(q), color="0.88", lw=0, label="90% conformal band")
    ax.plot(xs, xs, color="0.0", lw=0.8, label="identity")
    ax.scatter(ntu, pred, s=2.5, color="0.35", alpha=0.45, lw=0, rasterized=True)
    # medians in NTU bins
    bins = np.geomspace(max(ntu.min(), 1), ntu.max(), 9)
    idx = np.digitize(ntu, bins)
    mx = [np.median(ntu[idx == k]) for k in range(1, len(bins)) if (idx == k).sum() > 5]
    my = [np.median(pred[idx == k]) for k in range(1, len(bins)) if (idx == k).sum() > 5]
    ax.plot(mx, my, "o-", color="0.0", ms=3, mfc="white", mew=0.8, lw=0.8, label="bin median")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    ax.set_xlabel("measured turbidity (NTU)"); ax.set_ylabel("predicted turbidity (NTU)")
    ax.set_title(title)
    for v in (1, 3, 10, 30):
        pass
    ax.set_xticks([1, 3, 10, 30]); ax.set_xticklabels(["1", "3", "10", "30"])
    ax.set_yticks([1, 3, 10, 30]); ax.set_yticklabels(["1", "3", "10", "30"])


def fig_real():
    conf = json.load(open(f"{C}/conformal.json"))
    p1 = pd.read_csv(f"{C}/P1_pred.csv")
    p2 = pd.read_csv(f"{C}/P2_pred.csv")
    info = json.load(open(f"{C}/real_info.json"))
    mtr = pd.read_csv(f"{R}/MFT_train_scores.csv")
    tub = pd.read_csv(f"{R}/TUB_scores.csv")
    fig, axs = plt.subplots(1, 4, figsize=(7.16, 2.6), gridspec_kw={"width_ratios": [1, 1, 1.25, 1.05]})
    pv_panel(axs[0], p1.ntu.values, p1[EC].values, conf["ExTurb-C"]["MFT"]["q"],
             "(a) MFT, Train $\\rightarrow$ Test")
    pv_panel(axs[1], p2.ntu.values, p2[EC].values, conf["ExTurb-C"]["TUB"]["q"],
             "(b) TUB, leave-one-scene-out")
    axs[1].set_ylabel("")
    # (c) cue SROCC on the two datasets
    cues = ["Tc", "lnrho", "UCIQE", "DynRange", "Tenengrad", "DCP", "Entropy", "PCD", "LapVar"]
    lab = {"Tc": "$T_c$", "lnrho": r"$\ln\rho$", "DynRange": "Dyn. range", "LapVar": "Lap. var."}
    a, b = info["cue_srocc"]["MFT Train"], info["cue_srocc"]["TUB"]
    y = np.arange(len(cues))
    ax = axs[2]
    ax.barh(y - 0.19, [a[c] for c in cues], 0.36, color="0.25", label="MFT (Train)")
    ax.barh(y + 0.19, [b[c] for c in cues], 0.36, color="0.7", label="TUB")
    ax.set_yticks(y); ax.set_yticklabels([lab.get(c, c) for c in cues])
    ax.invert_yaxis(); ax.axvline(0, color="0.0", lw=0.6)
    ax.set_xlim(-0.2, 1.0); ax.set_xticks([0, 0.5, 1.0]); ax.set_xlabel("SROCC with ln NTU (raw cue)")
    ax.set_title("(c) cue strength differs by water")
    ax.grid(axis="y", visible=False)
    # (d) rho versus NTU
    ax = axs[3]
    ax.scatter(mtr.ntu, mtr.ExTurb_rho, s=1.5, color="0.3", alpha=0.25, lw=0, rasterized=True, label="MFT (Train)")
    ax.scatter(tub.ntu, tub.ExTurb_rho, s=1.5, color="0.65", alpha=0.5, lw=0, rasterized=True, label="TUB")
    ax.axhline(2.0, color="0.0", ls="--", lw=0.7)
    ax.axhline(4.0, color="0.0", ls=":", lw=0.7)
    ax.text(1.15, 2.05, "$s_2/s_1$ (sharp step)", fontsize=6.2, va="bottom")
    ax.text(1.15, 3.85, "$(s_2/s_1)^2$ (white noise)", fontsize=6.2, va="top")
    ax.set_xscale("log"); ax.set_xlim(1, 80); ax.set_ylim(1.0, 4.2)
    ax.set_xticks([1, 3, 10, 30]); ax.set_xticklabels(["1", "3", "10", "30"])
    ax.set_xlabel("measured turbidity (NTU)"); ax.set_ylabel(r"probe ratio $\rho$")
    ax.set_title(r"(d) $\rho$ leaves the step-edge range")
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    handles = [Patch(facecolor="0.88", edgecolor="none", label="90% conformal band"),
               Line2D([], [], color="0.0", lw=0.8, label="identity"),
               Line2D([], [], color="0.0", marker="o", mfc="white", ms=3.5, lw=0.8, label="bin median"),
               Line2D([], [], color="0.35", marker="o", ls="none", ms=3, alpha=0.6, label="image (a, b)"),
               Patch(facecolor="0.25", label="MFT (Train) (c, d)"), Patch(facecolor="0.7", label="TUB (c, d)")]
    fig.tight_layout(w_pad=0.6, rect=(0, 0.1, 1, 1))
    fig.legend(handles=handles, loc="lower center", ncol=6, bbox_to_anchor=(0.5, 0.0), frameon=False, fontsize=7)
    fig.savefig(f"{PAP}/real_ntu.pdf")
    print("real_ntu.pdf")


def fig_psf():
    d = pd.read_csv(f"{REV}/psf_study.csv")
    e = json.load(open(f"{REV}/edge_study.json"))
    fig, axs = plt.subplots(1, 3, figsize=(7.16, 2.2))
    sty = {"gauss": ("0.0", "-", "Gaussian"), "moffat": ("0.4", "--", r"Moffat ($\beta=2.5$)"),
           "poisson": ("0.6", "-.", "Poisson OTF (renderer)")}
    for k, (c, ls, lab) in sty.items():
        s = d[(d.kind == k) & (d.sigma0 == 0.5) & (d.w > 0)]
        axs[0].plot(s.sigma_tot, s.sigma_hat, color=c, ls=ls, label=lab)
        for s0, mk in [(0.0, "o"), (1.5, "s")]:
            s = d[(d.kind == k) & (d.sigma0 == s0) & (d.w > 0)]
            axs[1].plot(s.sigma_f, 100 * s.rel_err_tot, color=c, ls=ls, marker=mk, ms=2.2, mfc="white", mew=0.6)
    axs[0].plot([0, 6], [0, 6], color="0.8", lw=0.6)
    axs[0].set_xlabel(r"true total width $\sigma$ (px, matched HWHM)")
    axs[0].set_ylabel(r"recovered $\hat\sigma_b$ (px)")
    axs[0].set_title(r"(a) inversion, $\sigma_0=0.5$ px"); axs[0].legend(loc="upper left")
    axs[0].set_xlim(0, 6); axs[0].set_ylim(0, 6.5)
    axs[1].axhline(0, color="0.0", lw=0.5)
    axs[1].set_xlabel(r"forward-scatter width $\sigma_f$ (px)")
    axs[1].set_ylabel(r"relative error of $\hat\sigma_b$ (%)")
    axs[1].set_title(r"(b) error ($\circ$: $\sigma_0=0$; $\blacksquare$: $\sigma_0=1.5$)")
    axs[1].set_ylim(-20, 80)
    names = {"step": "step edge", "bar_1px": "1-px line", "bar_4px": "4-px bar"}
    s0 = [0.0, 0.5, 1.0, 2.0]
    for k, (c, ls) in zip(names, [("0.0", "-"), ("0.4", "--"), ("0.6", "-.")]):
        axs[2].plot(s0, e["edges"][k], color=c, ls=ls, marker="o", ms=2.5, mfc="white", label=names[k])
    
    axs[2].axhline(2.0, color="0.0", ls="--", lw=0.6); axs[2].axhline(4.0, color="0.0", ls=":", lw=0.6)
    axs[2].text(0.75, 2.05, "$s_2/s_1$: limit of Prop. 3", fontsize=6.2, va="bottom")
    axs[2].text(0.02, 3.95, "white noise", fontsize=6.2, va="top")
    axs[2].set_xlabel(r"intrinsic width $\sigma_0$ (px)"); axs[2].set_ylabel(r"probe ratio $\rho$")
    axs[2].set_title("(c) non-step structures"); axs[2].set_ylim(1.2, 4.2); axs[2].legend(loc="upper right", fontsize=6)
    fig.tight_layout(w_pad=0.8)
    fig.savefig(f"{PAP}/psf_error.pdf")
    print("psf_error.pdf")


if __name__ == "__main__":
    fig_real()
    fig_psf()


def fig_simrho():
    d = pd.read_csv(f"{REV}/sim_rho_summary.csv")
    fig, axs = plt.subplots(1, 2, figsize=(7.16, 2.5))
    sty = {0.002: ("0.0", "-", "o"), 0.01: ("0.4", "--", "s"), 0.03: ("0.65", "-.", "^")}
    for tex, mfc in (("original", "white"), ("low-pass", None)):
        for nz, (c, ls, mk) in sty.items():
            s = d[(d.texture == tex) & (d.noise == nz)].sort_values("b550")
            kw = dict(color=c, ls=ls if tex == "original" else ":", marker=mk, ms=3.5,
                      mfc=("white" if tex == "original" else c), mew=0.8)
            axs[0].plot(s.b550, 100 * s.valid, **kw)
            axs[1].plot(s.b550, s.rho, **kw)
    axs[0].set_xlabel(r"scattering $b_{550}$ (m$^{-1}$)"); axs[0].set_ylabel("valid inversions (%)")
    axs[0].set_title("(a) validity of the blur inversion")
    axs[1].axhline(2.0, color="0.0", lw=0.6, ls="--")
    axs[1].set_xlabel(r"scattering $b_{550}$ (m$^{-1}$)"); axs[1].set_ylabel(r"median probe ratio $\rho$")
    axs[1].set_title(r"(b) median $\rho$ ($s_2/s_1=2$ dashed)")
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=c, ls=ls, marker=mk, ms=3.5, mfc="white", label=fr"$\sigma_n={nz:g}$") for nz, (c, ls, mk) in sty.items()]
    h += [Line2D([], [], color="0.3", ls="-", marker="o", mfc="white", ms=3.5, label="textured scene (open)"),
          Line2D([], [], color="0.3", ls=":", marker="o", ms=3.5, label="low-pass scene (filled)")]
    fig.tight_layout(w_pad=1.0, rect=(0, 0.12, 1, 1))
    fig.legend(handles=h, loc="lower center", ncol=5, frameon=False, fontsize=7, bbox_to_anchor=(0.5, 0.0))
    fig.savefig(f"{PAP}/sim_rho.pdf")
    print("sim_rho.pdf")


def fig_lc():
    d = pd.read_csv(f"{REV}/learning_curves_summary.csv")
    fig, axs = plt.subplots(1, 2, figsize=(7.16, 2.45))
    sty = {"ExTurb-C": ("0.0", "-", "o"), "q99": ("0.45", "--", "s"),
           "full GEV (OLS)": ("0.65", "-.", "^"), "full GEV (ridge)": ("0.25", ":", "D")}
    lab = {"ExTurb-C": "ExTurb-C (3 coef.)", "q99": "99th percentile (3 coef.)",
           "full GEV (OLS)": "full GEV, least squares (7 coef.)", "full GEV (ridge)": "full GEV, ridge (7 coef.)"}
    for m, (c, ls, mk) in sty.items():
        s = d[d.model == m].sort_values("n")
        axs[0].errorbar(s.n, s.eva, yerr=s.eva_sd.fillna(0), color=c, ls=ls, marker=mk, ms=3.5, mfc="white",
                        capsize=1.5, lw=0.9, label=lab[m])
        axs[1].plot(s.n, s.tub, color=c, ls=ls, marker=mk, ms=3.5, mfc="white", lw=0.9)
    for ax in axs:
        ax.set_xscale("log"); ax.set_xticks([25, 100, 400, 1600, 4320]); ax.set_xticklabels(["25", "100", "400", "1600", "4320"])
        ax.set_xlabel("MFT training images")
    axs[0].set_ylabel("SROCC on MFT Eva"); axs[0].set_title("(a) in domain (untouched hold-out)")
    axs[1].set_ylabel("SROCC on TUB"); axs[1].set_title("(b) transfer to TUB")
    h, l = axs[0].get_legend_handles_labels()
    fig.tight_layout(w_pad=1.0, rect=(0, 0.12, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=4, frameon=False, fontsize=7, bbox_to_anchor=(0.5, 0.0))
    fig.savefig(f"{PAP}/learning_curves.pdf")
    print("learning_curves.pdf")
