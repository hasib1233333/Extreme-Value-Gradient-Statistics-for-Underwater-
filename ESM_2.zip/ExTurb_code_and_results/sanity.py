import numpy as np, time
from deadleaves import dead_leaves
from render import render, WATERS, RenderCfg
from exturb import exturb, ExTurbParams
rng=np.random.default_rng(0)
J=dead_leaves(384,384,rng)
d=np.full((384,384),2.5)
for w in ['oceanic','coastal','harbor']:
  for b in [0.05,0.2,0.5,1.0,2.0,3.0]:
    I=render(J,d,WATERS[w],b,RenderCfg(res_scale=384/512))
    t=time.time();r=exturb(I);dt=time.time()-t
    print(w,b,round(r['T_c'],3),round(r['rho'],3),round(r['sigma_b'],2),round(r['xi'],3),round(I.mean(),3),f'{dt*1e3:.0f}ms')
