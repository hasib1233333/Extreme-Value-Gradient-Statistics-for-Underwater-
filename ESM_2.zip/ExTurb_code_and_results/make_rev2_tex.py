"""Macros and table rows for the second revision."""
import json
import os
import re

import numpy as np
import pandas as pd

REV = "/home/claude/results/revision"
R = "/home/claude/real"
PAP = "/home/claude/paper"
MAC = {}


def sci(x, nd=2):
    if x == 0 or not np.isfinite(x):
        return f"{x:.{nd}f}"
    if abs(x) >= 1:
        return f"{x:.{nd}f}"
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    if round(abs(m), nd) >= 10:
        m /= 10; e += 1
    if e == 0:
        return f"{x:.{nd}f}"
    return f"\\ensuremath{{{m:.{nd}f}\\times10^{{{e}}}}}"


def p100(x):
    return f"{100 * x:.1f}"


def mac(k, v):
    assert re.fullmatch(r"[A-Za-z0-9]+", k), k
    MAC[k] = v


def validity():
    V = pd.read_csv(f"{REV}/validity_variants.csv")
    fr = json.load(open(f"{REV}/validity_fraction.json"))
    order = ["SynDL", "BSDS-UW test", "KM-UW", "Range-UW", "UIQS (real)", "TUB (real)", "MFT Test (real)"]
    syn = pd.read_csv("/home/claude/results/scores_syndl.csv")
    sv = float(((syn.ExTurb_rho > 1) & (syn.ExTurb_rho < 2)).mean())
    mac("ValidSynDL", f"{100 * sv:.0f}")
    lines = []
    for s in order[1:]:
        f = fr[s]
        lv = list(f["by_level"].values())
        v = V[V.set == s].set_index("variant")
        row = [s.replace(" (real)", r"$^{\ast}$"), p100(f["overall"]), p100(lv[0]), p100(lv[-1]),
               p100(v.loc["T_c only"].SROCC), p100(v.loc["all-image (published)"].SROCC),
               p100(v.loc["reliability-weighted"].SROCC)]
        if "valid-only: T_c only" in v.index:
            row += [str(int(v.loc["valid-only: T_c only"].n)), p100(v.loc["valid-only: T_c only"].SROCC),
                    p100(v.loc["valid-only: all-image (published)"].SROCC)]
        else:
            row += ["--", "--", "--"]
        lines.append(row)
    open(f"{PAP}/tab_validity_rows.tex", "w").write("\n".join(" & ".join(r) + r" \\" for r in lines) + "\n")
    b = fr["BSDS-UW test"]["by_level"]
    mac("ValBSDSlo", f"{100 * b['0.05']:.0f}"); mac("ValBSDShi", f"{100 * b['1.5']:.0f}")
    mac("ValBSDS", f"{100 * fr['BSDS-UW test']['overall']:.0f}")
    m = fr["MFT Test (real)"]["by_level"]
    mac("ValMFTlo", f"{100 * m['0']:.0f}"); mac("ValMFThi", f"{100 * m['3']:.0f}")
    mac("ValTUB", f"{100 * fr['TUB (real)']['overall']:.1f}")
    t = fr["BSDS-UW test"]["by_type"]
    mac("ValTypeMin", f"{100 * min(t.values()):.0f}"); mac("ValTypeMax", f"{100 * max(t.values()):.0f}")
    q = fr["BSDS-UW test"]["per_scene_valid_quartiles"]
    mac("ValSceneQa", f"{100 * q[0]:.0f}"); mac("ValSceneQc", f"{100 * q[2]:.0f}")
    sp = fr["MFT Test (real)"]["by_type"]
    mac("ValSpMin", f"{100 * min(sp.values()):.0f}"); mac("ValSpMax", f"{100 * max(sp.values()):.0f}")
    vb = V[V.set == "BSDS-UW test"].set_index("variant")
    mac("ValOnlyTcB", sci(vb.loc["valid-only: T_c only"].SROCC)); mac("ValOnlyExB", sci(vb.loc["valid-only: all-image (published)"].SROCC))
    mac("ValOnlyTcBw", sci(vb.loc["valid-only: T_c only"].within)); mac("ValOnlyExBw", sci(vb.loc["valid-only: all-image (published)"].within))
    vu = V[V.set == "UIQS (real)"].set_index("variant")
    mac("WeightUIQS", sci(vu.loc["reliability-weighted"].SROCC)); mac("AllUIQS", sci(vu.loc["all-image (published)"].SROCC))
    mac("TcUIQS", sci(vu.loc["T_c only"].SROCC))
    vm = V[V.set == "MFT Test (real)"].set_index("variant")
    mac("WeightMFT", sci(vm.loc["reliability-weighted"].SROCC))
    vt = V[V.set == "TUB (real)"].set_index("variant")
    mac("WeightTUB", sci(vt.loc["reliability-weighted"].SROCC))


def transfer():
    T = pd.read_csv(f"{REV}/transfer_summary.csv")
    splits = ["MFT -> TUB", "TUB -> MFT Test", "TUB leave-one-camera-out", "MFT leave-one-species-out",
              "TUB range: stages 1-5 -> 6-10", "TUB range: stages 6-10 -> 1-5", "MFT range: NTU<20 -> NTU>=20"]
    lab = {"MFT -> TUB": "MFT $\\to$ TUB", "TUB -> MFT Test": "TUB $\\to$ MFT",
           "TUB leave-one-camera-out": "Camera (TUB, LOO)",
           "MFT leave-one-species-out": "Species (MFT, LOO)",
           "TUB range: stages 1-5 -> 6-10": "TUB stages 1--5 $\\to$ 6--10",
           "TUB range: stages 6-10 -> 1-5": "TUB stages 6--10 $\\to$ 1--5",
           "MFT range: NTU<20 -> NTU>=20": "MFT $<$20 $\\to$ $\\ge$20 NTU"}
    models = ["ExTurb-C", "Dynamic range", "UCIQE", "UCIQE+DynRange"]
    lines = []
    for s in splits:
        d = T[T.split == s].set_index("model")
        row = [lab[s]]
        for m in models:
            r = d.loc[m]
            row += [p100(r.SROCC), p100(r.medRE) if r.medRE < 10 else f"{100 * r.medRE:.0f}", p100(r.coverage)]
        lines.append(row)
    open(f"{PAP}/tab_transfer_rows.tex", "w").write("\n".join(" & ".join(r) + r" \\" for r in lines) + "\n")
    g = T.set_index(["split", "model"])
    for s, k in [("MFT -> TUB", "MT"), ("TUB -> MFT Test", "TM"), ("TUB leave-one-camera-out", "Cam"),
                 ("MFT leave-one-species-out", "Sp"), ("TUB range: stages 6-10 -> 1-5", "RgHL"),
                 ("TUB range: stages 1-5 -> 6-10", "RgLH"), ("MFT range: NTU<20 -> NTU>=20", "RgM"),
                 ("in-domain MFT (Train/Test half A -> half B)", "In")]:
        for m, t in [("ExTurb-C", "Ex"), ("Dynamic range", "Dyn"), ("UCIQE", "UC"), ("UCIQE+DynRange", "Pair")]:
            r = g.loc[(s, m)]
            mac(f"Tr{k}{t}S", sci(r.SROCC)); mac(f"Tr{k}{t}Cov", p100(r.coverage)); mac(f"Tr{k}{t}W", f"{r.width:.2f}")
            mac(f"Tr{k}{t}Med", p100(r.medRE))
    c = json.load(open(f"{REV}/transfer_coverage_by_category.json"))
    e = c["ExTurb-C"]["TUB->MFT by level"]; dy = c["Dynamic range"]["TUB->MFT by level"]
    mac("CovTMExLzero", p100(e["0"])); mac("CovTMExLthree", p100(e["3"]))
    mac("CovTMDynLzero", p100(dy["0"])); mac("CovTMDynLthree", p100(dy["3"]))
    mac("CovTMUCLthree", p100(c["UCIQE"]["TUB->MFT by level"]["3"]))


def write():
    with open(f"{PAP}/results_rev2_macros.tex", "w") as f:
        f.write("% auto-generated by make_rev2_tex.py -- second revision\n")
        for k, v in MAC.items():
            f.write(f"\\expandafter\\def\\csname R@{k}\\endcsname{{{v}}}\n")
    print(len(MAC), "macros")


if __name__ == "__main__":
    validity()
    transfer()
    if os.path.exists(f"{REV}/eva_frozen.csv"):
        exec(open("/home/claude/code/make_rev2_eva.py").read())
    write()
