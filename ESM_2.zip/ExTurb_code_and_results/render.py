"""Physically based underwater image formation (Jaffe-McGlamery style).

I_c = J_c e^{-c_c d}                               (direct)
    + J_c * psf_d  * [e^{-G_c d} - e^{-c_c d}]      (small-angle forward scatter)
    + Binf_c (1 - e^{-c_c d})                       (backscatter / veiling light)
    + sensor noise

Absorption a_c = pure water (Pope & Fry 1997, at 600/540/460 nm)
               + coloured dissolved organic matter (CDOM, exponential spectrum)
Scattering    b_c = b_550 (550/lambda)^n  (particles; b_550 is the turbidity knob)
Forward-scatter PSF: radially symmetric Poisson kernel = inverse FT of
exp(-B d |f|) (Jaffe 1990), width proportional to b_550 * d.

Spatially varying range d(x) is handled by layering: the depth map is split
into K slabs, each slab is rendered with its mean range, and slabs are blended
with smooth weights.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy import ndimage as ndi

LAMBDA = np.array([600.0, 540.0, 460.0])           # nm, effective R,G,B
A_WATER = np.array([0.2224, 0.0448, 0.0098])        # 1/m, Pope & Fry 1997


@dataclass
class Water:
    name: str
    a_cdom440: float      # CDOM absorption at 440 nm (1/m)
    s_cdom: float = 0.014  # CDOM spectral slope (1/nm)
    n_scat: float = 0.6    # particle scattering spectral exponent
    a_part550: float = 0.02  # particle absorption per unit b_550 (dimensionless ratio)


WATERS = {
    "oceanic": Water("oceanic", 0.01),
    "coastal": Water("coastal", 0.15),
    "harbor": Water("harbor", 0.60),
}


@dataclass
class RenderCfg:
    psf_k: float = 0.55        # px per (1/m * m): PSF scale = psf_k * b550 * d * res
    fwd_frac: float = 0.85     # fraction of scattering that is small-angle forward
    binf_gain: float = 0.9     # veiling light brightness relative to illumination
    z_water: float = 5.0       # water depth of the light path from surface (m)
    layers: int = 4
    res_scale: float = 1.0     # pixels-per-reference-pixel (image width / 512)


def coefficients(w: Water, b550: float):
    a_cdom = w.a_cdom440 * np.exp(-w.s_cdom * (LAMBDA - 440.0))
    b = b550 * (550.0 / LAMBDA) ** w.n_scat
    a = A_WATER + a_cdom + w.a_part550 * b550
    c = a + b
    return a, b, c


def poisson_otf(shape, width_px):
    """OTF exp(-width * 2*pi*|f|) on an FFT grid; width in pixels."""
    H, W = shape
    fy = np.fft.fftfreq(H)[:, None]
    fx = np.fft.rfftfreq(W)[None, :]
    fr = np.sqrt(fx ** 2 + fy ** 2)
    return np.exp(-2 * np.pi * max(width_px, 0.0) * fr)


def render(J: np.ndarray, d: np.ndarray, water: Water, b550: float,
           cfg: RenderCfg = RenderCfg(), illum=None, rng=None,
           noise_sigma: float = 0.0, gain: float = 1.0) -> np.ndarray:
    """J: linear RGB in [0,1], d: range map in metres (same H,W)."""
    J = J.astype(np.float64)
    H, W = d.shape
    a, b, c = coefficients(water, b550)
    G_ = a + (1 - cfg.fwd_frac) * b
    # downwelling illumination colour at depth z (diffuse attenuation ~ c*0.6)
    if illum is None:
        illum = np.exp(-0.6 * c * cfg.z_water)
        illum = illum / illum.max()
    binf = cfg.binf_gain * illum * (b / c)
    binf = binf / max(binf.max(), 1e-9) * cfg.binf_gain * illum.max()

    # depth layering
    K = cfg.layers
    dmin, dmax = np.nanmin(d), np.nanmax(d)
    edges = np.linspace(dmin, dmax + 1e-6, K + 1)
    centres = 0.5 * (edges[:-1] + edges[1:])
    # soft weights (hat functions over centres)
    if K == 1 or dmax - dmin < 1e-6:
        weights = [np.ones_like(d)]
        centres = np.array([np.nanmean(d)])
    else:
        step = centres[1] - centres[0]
        weights = [np.clip(1 - np.abs(d - cz) / step, 0, 1) for cz in centres]
        weights[0][d <= centres[0]] = 1
        weights[-1][d >= centres[-1]] = 1
        s = np.sum(weights, axis=0)
        weights = [w / s for w in weights]

    out_fs = np.zeros_like(J)
    Jf = np.fft.rfft2(J, axes=(0, 1))
    for wgt, dz in zip(weights, centres):
        width = cfg.psf_k * b550 * dz * cfg.res_scale
        otf = poisson_otf((H, W), width)
        Jb = np.fft.irfft2(Jf * otf[..., None], s=(H, W), axes=(0, 1))
        out_fs += wgt[..., None] * Jb * (np.exp(-G_[None, None, :] * dz) - np.exp(-c[None, None, :] * dz))
    t = np.exp(-c[None, None, :] * d[..., None])
    I = J * t + out_fs + binf[None, None, :] * (1 - t)
    I = I * gain
    if rng is not None and noise_sigma > 0:
        # Poisson-Gaussian: shot noise ~ sqrt(I)
        I = I + rng.normal(size=I.shape) * noise_sigma * np.sqrt(np.clip(I, 1e-4, None) + 0.01)
    return np.clip(I, 0, 1)


def ground_truth(water: Water, b550: float):
    a, b, c = coefficients(water, b550)
    return {"b550": b550, "c550": float(np.interp(550, LAMBDA[::-1], c[::-1]))}


# ----------------------------------------------------------- depth helpers
def synthetic_range(H, W, rng, dmin=1.0, dmax=4.0, kind="tilt"):
    """Plausible range maps for scenes without measured depth."""
    yy, xx = np.mgrid[0:H, 0:W] / max(H, W)
    if kind == "tilt":  # forward-looking camera over seabed: far at top
        th = rng.uniform(-0.3, 0.3)
        base = (1 - yy) * np.cos(th) + xx * np.sin(th)
    else:
        base = np.zeros((H, W))
    smooth = ndi.gaussian_filter(rng.normal(size=(H, W)), max(H, W) / 8)
    smooth = smooth / (np.abs(smooth).max() + 1e-9)
    r = base + 0.15 * smooth
    r = (r - r.min()) / (r.max() - r.min() + 1e-9)
    lo = rng.uniform(dmin, dmin + 0.5)
    hi = rng.uniform(dmax - 1.0, dmax)
    return lo + r * (hi - lo)


def to_linear(srgb):
    srgb = np.clip(srgb, 0, 1)
    return np.where(srgb <= 0.04045, srgb / 12.92, ((srgb + 0.055) / 1.055) ** 2.4)


def to_srgb(lin):
    lin = np.clip(lin, 0, 1)
    return np.where(lin <= 0.0031308, 12.92 * lin, 1.055 * lin ** (1 / 2.4) - 0.055)
