"""Revision 2: (a) frozen ExTurb-C on the untouched MFT Eva split; (b) identically calibrated
gradient-statistic families (comment 4); (c) noise-referenced cue.

All models were specified in frozen_calibration.json before Eva was processed.
"""
import json
import sys

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

R = sys.argv[1] if len(sys.argv) > 1 else "/home/claude/real"
OUT = "/home/claude/results/revision"
RNG = np.random.default_rng(2027)
NB = 2000
BASE = ["UCIQE", "UIQM", "DCP", "UDCP", "DynRange", "RMSC", "Tenengrad", "LapVar", "Entropy", "PCD"]


def F(df):
    f = pd.DataFrame({"Tc": df.ExTurb_Tc.values, "lnrho": np.log(df.ExTurb_rho.values), "ExTurb": df.ExTurb.values})
    for b in BASE:
        f[b] = df[b].values
    return f


def pred(c, X):
    return np.c_[X, np.ones(len(X))] @ np.asarray(c)


def lsq(X, y):
    return np.linalg.lstsq(np.c_[X, np.ones(len(X))], y, rcond=None)[0]


def qconf(r, a=0.1):
    n = len(r)
    return float(np.quantile(r, min(1, np.ceil((n + 1) * (1 - a)) / n)))


def metr(p, y, q):
    ntu, pn = np.exp(y), np.exp(p)
    return dict(SROCC=spearmanr(p, y)[0], medRE=float(np.median(np.abs(pn - ntu) / ntu)),
                coverage=float(np.mean(np.abs(y - p) <= q)), width=float(np.exp(q)))


def boot(pa, pb, y):
    n = len(y)
    d = []
    for _ in range(NB):
        i = RNG.integers(0, n, n)
        d.append(spearmanr(pa[i], y[i])[0] - spearmanr(pb[i], y[i])[0])
    d = np.array(d)
    obs = spearmanr(pa, y)[0] - spearmanr(pb, y)[0]
    return obs, np.percentile(d, 2.5), np.percentile(d, 97.5), max(2 * min((d <= 0).mean(), (d >= 0).mean()), 1 / NB)


def holm(ps):
    o = np.argsort(ps); adj = np.empty(len(ps)); run = 0
    for r, i in enumerate(o):
        run = max(run, min(1, (len(ps) - r) * ps[i])); adj[i] = run
    return adj


def frozen_eva(fz):
    ev = pd.read_csv(f"{R}/MFT_eva_scores.csv")
    Fe, y = F(ev), np.log(ev.ntu.values)
    rows, preds = [], {}
    for src in ("mft", "tub"):
        for k, m in fz[src].items():
            p = pred(m["coef"], Fe[m["cols"]].values)
            preds[(src, k)] = p
            r = metr(p, y, m["q"])
            r.update(source="MFT Train" if src == "mft" else "TUB (transfer)", model=k)
            if src == "mft":
                r["cov_by_level"] = {int(L): float(np.mean((np.abs(y - p) <= m["q"])[ev.level.values == L]))
                                     for L in sorted(ev.level.unique())}
            rows.append(r)
    T = pd.DataFrame(rows)
    ref = preds[("mft", "ExTurb-C")]
    comp = [k for k in fz["mft"] if k != "ExTurb-C"]
    tests = [boot(ref, preds[("mft", k)], y) for k in comp]
    adj = holm(np.array([t[3] for t in tests]))
    S = pd.DataFrame({"vs": comp, "d": [t[0] for t in tests], "lo": [t[1] for t in tests],
                      "hi": [t[2] for t in tests], "p": [t[3] for t in tests], "p_holm": adj})
    reft = preds[("tub", "ExTurb-C")]
    compt = [k for k in fz["tub"] if k != "ExTurb-C"]
    tt = [boot(reft, preds[("tub", k)], y) for k in compt]
    adjt = holm(np.array([t[3] for t in tt]))
    St = pd.DataFrame({"vs": compt, "d": [t[0] for t in tt], "p_holm": adjt})
    T.to_csv(f"{OUT}/eva_frozen.csv", index=False)
    S.to_csv(f"{OUT}/eva_sig.csv", index=False)
    St.to_csv(f"{OUT}/eva_sig_transfer.csv", index=False)
    pd.set_option("display.width", 200)
    print(T.drop(columns=["cov_by_level"]).round(3).to_string())
    print(S.round(4).to_string())
    print(St.round(4).to_string())
    return ev


FAM = ["gmean", "gq90", "gq99", "bmean", "bmed", "mu"]
FAMNAME = {"gmean": "mean Weber gradient", "gq90": "90th percentile of $W$", "gq99": "99th percentile of $W$",
           "bmean": "mean of block maxima", "bmed": "median of block maxima", "mu": "GEV location (ExTurb-C)"}


def famX(d, f):
    a, b = d[f"{f}_1.5"].values, d[f"{f}_3"].values
    return np.c_[-np.log(a), np.log(a / b)]


def extX(d, kind):
    if kind == "full GEV (7 coef.)":
        return np.c_[-np.log(d["mu_1.5"]), np.log(d["mu_1.5"] / d["mu_3"]), np.log(d["sg_1.5"]), np.log(d["sg_3"]),
                     d["xi_1.5"], d["xi_3"]]
    if kind == "noise-referenced (4 coef.)":
        return np.c_[-np.log(d["mu_1.5"]), np.log(d["mu_1.5"] / d["mu_3"]), np.log(d["mu_1.5"] / d["noise_weber"])]
    if kind == "noise level only (2 coef.)":
        return np.c_[np.log(d["noise_weber"])]
    raise KeyError(kind)


def feature_study():
    fm = pd.read_csv(f"{R}/features_MFT.csv")
    ft = pd.read_csv(f"{R}/features_TUB.csv")
    fm = fm[np.isfinite(fm.ntu)]
    tr, te, ev = (fm[fm.split.str.lower() == s].reset_index(drop=True) for s in ("train", "test", "eva"))
    ytr, yte, yev, yt = (np.log(d.ntu.values) for d in (tr, te, ev, ft))
    g = ft.group.values
    specs = [(FAMNAME[f], (lambda d, f=f: famX(d, f))) for f in FAM] + \
            [(k, (lambda d, k=k: extX(d, k))) for k in ("full GEV (7 coef.)", "noise-referenced (4 coef.)",
                                                      "noise level only (2 coef.)")]
    rows, evp = [], {}
    for name, fx in specs:
        c = lsq(fx(tr), ytr)
        q = qconf(np.abs(yte - pred(c, fx(te))))
        pe = pred(c, fx(ev)); evp[name] = pe
        r_ev = metr(pe, yev, q)
        r_te = metr(pred(c, fx(te)), yte, q)
        r_tub = metr(pred(c, fx(ft)), yt, q)
        # TUB leave-one-scene-out
        p = np.zeros(len(yt))
        res = []
        for s in np.unique(g):
            m = g == s
            cs = lsq(fx(ft[~m]), yt[~m]); p[m] = pred(cs, fx(ft[m]))
        r_loso = metr(p, yt, qconf(np.abs(yt - p)))
        ct = lsq(fx(ft), yt)
        r_t2e = metr(pred(ct, fx(ev)), yev, qconf(np.abs(yt - p)))
        rows.append(dict(features=name, n_coef=fx(tr).shape[1] + 1,
                         MFT_test=r_te["SROCC"], MFT_eva=r_ev["SROCC"], MFT_eva_medRE=r_ev["medRE"],
                         MFT_eva_cov=r_ev["coverage"], MFT_eva_width=r_ev["width"],
                         TUB_loso=r_loso["SROCC"], TUB_loso_medRE=r_loso["medRE"],
                         MFT_to_TUB=r_tub["SROCC"], MFT_to_TUB_medRE=r_tub["medRE"], MFT_to_TUB_cov=r_tub["coverage"],
                         TUB_to_Eva=r_t2e["SROCC"], TUB_to_Eva_medRE=r_t2e["medRE"], TUB_to_Eva_cov=r_t2e["coverage"]))
    T = pd.DataFrame(rows)
    ref = evp[FAMNAME["mu"]]
    comp = [k for k in evp if k != FAMNAME["mu"]]
    tests = [boot(ref, evp[k], yev) for k in comp]
    adj = holm(np.array([t[3] for t in tests]))
    S = pd.DataFrame({"vs": comp, "d": [t[0] for t in tests], "lo": [t[1] for t in tests],
                      "hi": [t[2] for t in tests], "p_holm": adj})
    T.to_csv(f"{OUT}/feature_families.csv", index=False)
    S.to_csv(f"{OUT}/feature_families_sig.csv", index=False)
    pd.set_option("display.width", 250)
    print(T.round(3).to_string())
    print(S.round(4).to_string())
    # sanity: GEV family on real features must equal ExTurb T_c from the scores files
    chk = pd.read_csv(f"{R}/MFT_test_scores.csv")
    print("sanity T_c range scores:", round(chk.ExTurb_Tc.mean(), 4), " features:", round((-np.log(te["mu_1.5"])).mean(), 4))


if __name__ == "__main__":
    fz = json.load(open(f"{R}/frozen_calibration.json"))
    part = sys.argv[2] if len(sys.argv) > 2 else "all"
    if part in ("all", "eva"):
        frozen_eva(fz)
    if part in ("all", "features"):
        feature_study()
