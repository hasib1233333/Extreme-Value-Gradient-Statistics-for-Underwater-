"""Regenerate figures/tables that changed without recomputing bootstraps."""
import re
import analysis as A
from analysis import MAC, PAP
old = open(f"{PAP}/results_macros.tex").read()
for k, v in re.findall(r"R@([A-Za-z0-9]+)\\endcsname\{(.*)\}\n", old):
    MAC[k] = v
rf = A.fit_rf()
A.fig_robust(rf)
A.fig_sens()
txt, _ = A.tex_ablation()
names = {"full": r"Full ExTurb ($\lambda=0.5$)", "Tc only (lambda=0)": r"$T_c$ only ($\lambda=0$)",
         "sigma_b only": r"$\hat\sigma_b$ only", "no Weber normalisation": "No Weber normalisation",
         "sample mean of maxima": "Sample mean of block maxima (no GEV)",
         "sample median of maxima": "Sample median of block maxima",
         "Gumbel (moments)": r"Gumbel fit ($\xi=0$, moments)", "green channel": "Green channel instead of luminance",
         "native resolution": r"Native resolution (no resize to $N_w$)",
         "mean Weber gradient (no EVT)": "Mean Weber gradient (no extremes)"}
lines = []
for ln in txt.split("\n"):
    key = ln.split(" & ")[0]
    lines.append(ln.replace(key, names.get(key, key), 1))
open(f"{PAP}/tab_ablation_rows.tex", "w").write("\n".join(lines))
A.write_macros()
print("ok")
