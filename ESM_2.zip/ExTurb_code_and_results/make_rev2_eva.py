# executed inside make_rev2_tex.py (uses mac, sci, p100, REV, PAP, pd, np, json)
E = pd.read_csv(f"{REV}/eva_frozen.csv")
Sg = pd.read_csv(f"{REV}/eva_sig.csv").set_index("vs")
St = pd.read_csv(f"{REV}/eva_sig_transfer.csv").set_index("vs")
em = E[E.source == "MFT Train"].set_index("model")
et = E[E.source != "MFT Train"].set_index("model")
NAMES = {"ExTurb-C": r"\textbf{ExTurb-C}", "ExTurb frozen": "ExTurb (frozen) + affine map", "T_c": "$T_c$ + affine map",
         "UCIQE+DynRange": "UCIQE + dynamic range", "DynRange": "Dynamic range", "RMSC": "RMS contrast",
         "LapVar": "Laplacian variance"}
order = ["ExTurb-C", "ExTurb frozen", "T_c", "UCIQE+DynRange", "UCIQE", "UIQM", "DCP", "UDCP", "DynRange",
         "RMSC", "Tenengrad", "LapVar", "Entropy", "PCD"]
lines = []
for k in order:
    a, b = em.loc[k], et.loc[k]
    mk = ""
    if k != "ExTurb-C" and Sg.loc[k].p_holm < 0.05:
        mk = r"$^{+}$" if Sg.loc[k].d > 0 else r"$^{-}$"
    mt = ""
    if k != "ExTurb-C" and St.loc[k].p_holm < 0.05:
        mt = r"$^{+}$" if St.loc[k].d > 0 else r"$^{-}$"
    lines.append([NAMES.get(k, k), p100(a.SROCC) + mk, p100(a.medRE), p100(a.coverage), f"{a.width:.2f}",
                  p100(b.SROCC) + mt, p100(b.medRE), p100(b.coverage)])
open(f"{PAP}/tab_eva_rows.tex", "w").write("\n".join(" & ".join(r) + r" \\" for r in lines) + "\n")
x = em.loc["ExTurb-C"]
mac("EvaExC", sci(x.SROCC)); mac("EvaExCmed", p100(x.medRE)); mac("EvaExCcov", p100(x.coverage)); mac("EvaExCw", f"{x.width:.2f}")
for k, t in [("UCIQE+DynRange", "Pair"), ("DynRange", "Dyn"), ("UCIQE", "UC"), ("T_c", "Tc"), ("ExTurb frozen", "Fr"),
             ("Tenengrad", "Ten"), ("PCD", "PCD")]:
    mac(f"Eva{t}", sci(em.loc[k].SROCC)); mac(f"Eva{t}med", p100(em.loc[k].medRE)); mac(f"Eva{t}cov", p100(em.loc[k].coverage))
    mac(f"Eva{t}p", sci(Sg.loc[k].p_holm)); mac(f"Eva{t}d", sci(Sg.loc[k].d))
y = et.loc["ExTurb-C"]
mac("EvaTrExC", sci(y.SROCC)); mac("EvaTrExCmed", p100(y.medRE)); mac("EvaTrExCcov", p100(y.coverage))
for k, t in [("DynRange", "Dyn"), ("UCIQE", "UC"), ("UCIQE+DynRange", "Pair")]:
    mac(f"EvaTr{t}", sci(et.loc[k].SROCC)); mac(f"EvaTr{t}med", p100(et.loc[k].medRE)); mac(f"EvaTr{t}cov", p100(et.loc[k].coverage))
cbl = eval(str(em.loc["ExTurb-C"].cov_by_level)) if isinstance(em.loc["ExTurb-C"].cov_by_level, str) else em.loc["ExTurb-C"].cov_by_level
mac("EvaCovLzero", p100(cbl[0])); mac("EvaCovLthree", p100(cbl[3]))
nsig_better = int(((Sg.p_holm < 0.05) & (Sg.d > 0)).sum()); nsig_worse = int(((Sg.p_holm < 0.05) & (Sg.d < 0)).sum())
mac("EvaNbetter", str(nsig_better)); mac("EvaNworse", str(nsig_worse))
fs = f"{REV}/feature_families.csv"
if os.path.exists(fs):
    Fm = pd.read_csv(fs)
    Fs = pd.read_csv(f"{REV}/feature_families_sig.csv").set_index("vs")
    fl = []
    for _, r in Fm.iterrows():
        mk = ""
        if r.features in Fs.index and Fs.loc[r.features].p_holm < 0.05:
            mk = r"$^{+}$" if Fs.loc[r.features].d > 0 else r"$^{-}$"
        nm = r.features[0].upper() + r.features[1:]
        if r.features.startswith("GEV location"):
            nm = r"\textbf{GEV location} (= ExTurb-C)"
        fl.append([nm, str(int(r.n_coef)), p100(r.MFT_test), p100(r.MFT_eva) + mk, p100(r.MFT_eva_medRE),
                   p100(r.MFT_eva_cov), p100(r.TUB_loso), p100(r.MFT_to_TUB), p100(r.MFT_to_TUB_medRE),
                   p100(r.TUB_to_Eva), p100(r.TUB_to_Eva_medRE)])
    open(f"{PAP}/tab_families_rows.tex", "w").write("\n".join(" & ".join(x) + r" \\" for x in fl) + "\n")
    Fi = Fm.set_index("features")
    for nm, t in [("GEV location (ExTurb-C)", "Gev"), ("mean Weber gradient", "Gm"), ("mean of block maxima", "Bm"),
                  ("median of block maxima", "Bmed"), ("90th percentile of $W$", "Qn"), ("99th percentile of $W$", "Qnn"),
                  ("full GEV (7 coef.)", "Full"), ("noise-referenced (4 coef.)", "Noise"), ("noise level only (2 coef.)", "NoiseOnly")]:
        r = Fi.loc[nm]
        mac(f"Fam{t}Eva", sci(r.MFT_eva)); mac(f"Fam{t}Loso", sci(r.TUB_loso)); mac(f"Fam{t}MT", sci(r.MFT_to_TUB))
        mac(f"Fam{t}MTmed", p100(r.MFT_to_TUB_medRE)); mac(f"Fam{t}TE", sci(r.TUB_to_Eva)); mac(f"Fam{t}TEmed", p100(r.TUB_to_Eva_medRE))
        mac(f"Fam{t}Evamed", p100(r.MFT_eva_medRE)); mac(f"Fam{t}Evacov", p100(r.MFT_eva_cov))
        if nm in Fs.index:
            mac(f"Fam{t}p", sci(Fs.loc[nm].p_holm)); mac(f"Fam{t}d", sci(Fs.loc[nm].d))
    mac("FamNsigBetter", str(int(((Fs.p_holm < 0.05) & (Fs.d > 0)).sum())))
    mac("FamNsigWorse", str(int(((Fs.p_holm < 0.05) & (Fs.d < 0)).sum())))
