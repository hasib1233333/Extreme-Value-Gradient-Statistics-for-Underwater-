"""Ablation and sensitivity of ExTurb (all on frozen evaluation sets).

python ablation.py ablate | sens
"""
import csv
import json
import sys

import numpy as np
from joblib import Parallel, delayed

from datasets import load_rgb, uiqs_items
from exturb import ExTurbParams, exturb

RES = "results"
BASE = {k: v for k, v in json.load(open(f"{RES}/exturb_params.json")).items() if k != "lam"}
LAM = 0.5


def rows(path):
    with open(path) as f:
        return list(csv.DictReader(f))


def sets():
    rng = np.random.default_rng(0)
    bs = rows("bench/bsds_test.csv")
    km = rows("bench/km.csv")
    ui = uiqs_items()
    ui = [ui[i] for i in sorted(rng.choice(len(ui), 1000, replace=False))]
    return {
        "BSDS-UW": [(r["file"], float(r["b550"]), r["scene"]) for r in bs],
        "KM-UW": [(r["file"], float(r["b550"]), r["scene"]) for r in km],
        "UIQS": [(f, g, i) for i, (f, g) in enumerate(ui)],
    }


VARIANTS = {
    "full": (dict(), LAM, "T"),
    "Tc only (lambda=0)": (dict(), 0.0, "T"),
    "sigma_b only": (dict(), None, "sigma"),
    "no Weber normalisation": (dict(weber=False), LAM, "T"),
    "sample mean of maxima": (dict(fit="mean"), LAM, "T"),
    "sample median of maxima": (dict(fit="median"), LAM, "T"),
    "Gumbel (moments)": (dict(fit="gumbel"), LAM, "T"),
    "green channel": (dict(channel="green"), LAM, "T"),
    "native resolution": (dict(work_size=None), LAM, "T"),
}


def run_variant(path, kw):
    img = load_rgb(path, 512)
    r = exturb(img, ExTurbParams(**{**BASE, **kw}))
    return r["T_c"], r["sigma_b"]


def mean_grad_variant(path):
    """Replace block maxima by the mean Weber gradient (non-extremal statistic)."""
    from scipy import ndimage as ndi
    from exturb import grad_mag, luminance, resize_long
    img = resize_long(load_rgb(path, 512), 512)
    L = luminance(img)
    den = ndi.gaussian_filter(L, BASE["sw"]) + BASE["eps"]
    return -np.log(np.mean(grad_mag(L, BASE["s1"]) / den))


def ablate():
    S = sets()
    out = {}
    for sname, items in S.items():
        out[sname] = {"y": [it[1] for it in items], "g": [it[2] for it in items]}
        for vname, (kw, lam, kind) in VARIANTS.items():
            if vname in ("Tc only (lambda=0)", "sigma_b only") and "full_raw" in out[sname]:
                raw = out[sname]["full_raw"]
            else:
                raw = Parallel(n_jobs=2, batch_size=8)(delayed(run_variant)(it[0], kw) for it in items)
                if vname == "full":
                    out[sname]["full_raw"] = raw
            Tc = np.array([r[0] for r in raw])
            sb = np.array([r[1] for r in raw])
            if kind == "sigma":
                x = sb
            else:
                x = Tc + lam * np.log(sb + 0.25)
            out[sname][vname] = x.tolist()
            print(sname, vname, flush=True)
        mg = Parallel(n_jobs=2, batch_size=8)(delayed(mean_grad_variant)(it[0]) for it in items)
        out[sname]["mean Weber gradient (no EVT)"] = list(map(float, mg))
        out[sname].pop("full_raw")
    json.dump(out, open(f"{RES}/ablation.json", "w"))


SENS = {
    "s1": [0.7, 1.0, 1.5, 2.0, 2.5],
    "ratio": [1.5, 2.0, 3.0, 4.0],
    "block": [8, 16, 32, 48, 64],
    "sw": [2.0, 4.0, 8.0, 16.0, 32.0],
    "work_size": [256, 384, 512, 768],
    "eps": [1e-4, 1e-3, 1e-2, 5e-2],
    "lam": [0.0, 0.25, 0.5, 1.0, 2.0],
}


def sens():
    S = sets()
    rng = np.random.default_rng(1)
    items = S["BSDS-UW"]
    items = [items[i] for i in sorted(rng.choice(len(items), 400, replace=False))]
    ui_all = S["UIQS"]
    ui = [ui_all[i] for i in sorted(rng.choice(len(ui_all), 400, replace=False))]
    import os
    only = os.environ.get("SENS_ONLY")
    out = json.load(open(f"{RES}/sensitivity.json")) if only else {}
    todo = (("BSDS-UW", items), ("UIQS", ui))
    if only:
        todo = tuple(t for t in todo if t[0] == only)
    for sname, its in todo:
        out[sname] = {"y": [it[1] for it in its]}
        for par, vals in SENS.items():
            for v in vals:
                kw = dict(BASE)
                lam = LAM
                if par == "ratio":
                    kw["s2"] = BASE["s1"] * v
                elif par == "s1":
                    kw["s1"] = v
                    kw["s2"] = 2 * v
                elif par == "lam":
                    lam = v
                else:
                    kw[par] = v
                raw = Parallel(n_jobs=2, batch_size=8)(
                    delayed(run_variant)(it[0], {k: kw[k] for k in kw}) for it in its)
                x = [r[0] + lam * np.log(r[1] + 0.25) for r in raw]
                out[sname][f"{par}={v}"] = list(map(float, x))
            print(sname, par, flush=True)
    json.dump(out, open(f"{RES}/sensitivity.json", "w"))


if __name__ == "__main__":
    {"ablate": ablate, "sens": sens}[sys.argv[1]]()
