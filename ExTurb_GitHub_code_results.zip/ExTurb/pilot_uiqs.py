import numpy as np, glob, time, os
from skimage import io
from scipy.stats import spearmanr
from exturb import exturb, ExTurbParams
from baselines import metric_suite
root='data/gitdata/Realworld-Underwater-Image-Enhancement-RUIE-Benchmark/UIQS'
rng=np.random.default_rng(0)
rows=[]
ms=metric_suite()
print(io.imread(glob.glob(root+'/A/*')[0]).shape)
for gi,g in enumerate('ABCDE'):
    fs=sorted(glob.glob(f'{root}/{g}/*')); fs=[fs[i] for i in rng.choice(len(fs),30,replace=False)]
    for f in fs:
        im=io.imread(f)[...,:3]/255.0
        r=exturb(im,ExTurbParams(work_size=None))
        rows.append([gi,r['T_c'],r['sigma_b']]+[ms[k](im) for k in ms])
R=np.array(rows)
names=['T_c','sigma_b']+list(ms)
for j,n in enumerate(names): print(n, round(spearmanr(R[:,0],R[:,j+1])[0],3))
