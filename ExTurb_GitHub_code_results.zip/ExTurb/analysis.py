"""Turn cached scores into the paper's tables, figures and number macros.

Every number quoted in the manuscript is written by this script into
paper/results_macros.tex; nothing is typed by hand.
"""
import csv
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
from scipy.stats import friedmanchisquare, kendalltau, spearmanr
from sklearn.ensemble import RandomForestRegressor

from stats_eval import (auc, cluster_bootstrap, corr_suite, holm,
                        paired_bootstrap_diff, within_scene_kendall)

RES = "results"
PAP = "paper"
FIG = f"{PAP}/figs"
os.makedirs(FIG, exist_ok=True)

METHODS = ["ExTurb", "UCIQE", "UIQM", "DCP", "UDCP", "DynRange", "RMSC", "Tenengrad",
           "LapVar", "Entropy", "PCD"]
LEARNED = ["CNN-R", "RF-F"]
LABEL = {"ExTurb": r"\textbf{ExTurb (ours)}", "DynRange": "Dyn. range", "RMSC": "RMS contrast",
         "LapVar": "Lap. variance", "CNN-R": "CNN-R$^\\ddagger$", "RF-F": "RF-F$^\\ddagger$"}
FEATS = ["ExTurb_Tc", "ExTurb_sigma", "ExTurb_xi"] + METHODS[1:]

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"], "mathtext.fontset": "stix",
    "font.size": 8, "axes.labelsize": 8, "axes.titlesize": 8, "legend.fontsize": 7,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.linewidth": 0.6, "lines.linewidth": 1.0,
    "lines.markersize": 3.5, "axes.grid": True, "grid.color": "0.88", "grid.linewidth": 0.4,
    "axes.edgecolor": "0.15", "savefig.dpi": 600, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
    "legend.frameon": False, "axes.prop_cycle": matplotlib.cycler(color=["0.0", "0.35", "0.6", "0.0", "0.35", "0.6"])})
STY = {  # IEEE-like grayscale styles: (color, linestyle, marker)
    "ExTurb": ("0.0", "-", "o"), "PCD": ("0.45", "--", "s"), "UCIQE": ("0.3", ":", "^"),
    "UIQM": ("0.55", "-.", "v"), "UDCP": ("0.35", "--", "D"), "Tenengrad": ("0.6", ":", "x"),
    "DynRange": ("0.5", "-.", "+"), "CNN-R": ("0.25", (0, (5, 1.5, 1, 1.5)), "*"),
    "DCP": ("0.4", "--", "<"), "LapVar": ("0.65", ":", ">"), "Entropy": ("0.7", "-.", "p"),
    "RMSC": ("0.5", ":", "h"), "RF-F": ("0.2", "--", "P")}
ACCENT = "#1f4e79"  # single subtle accent (IEEE-blue) for highlighting ExTurb where needed
MAC = {}


def mac(k, v):
    MAC[k] = v


def fmt_sci(x, d=2):
    """Scientific notation string for LaTeX, e.g. 8.61\\times10^{-1}."""
    if x == 0 or not np.isfinite(x):
        return "0"
    e = int(np.floor(np.log10(abs(x))))
    m = x / 10 ** e
    if round(abs(m), d) >= 10:
        m /= 10
        e += 1
    return f"{m:.{d}f}\\times10^{{{e}}}"


def load(name):
    p = f"{RES}/scores_{name}.csv"
    with open(p) as f:
        rows = list(csv.DictReader(f))
    cp = f"{RES}/cnn_{name}.csv"
    if os.path.exists(cp):
        with open(cp) as f:
            c = {r["file"]: float(r["CNN-R"]) for r in csv.DictReader(f)}
        for r in rows:
            r["CNN-R"] = c.get(r["file"], np.nan)
    return rows


def col(rows, k):
    return np.array([float(r[k]) if r.get(k, "") not in ("", None) else np.nan for r in rows])


# ---------------------------------------------------------------- RF-F
def fit_rf():
    tr = load("bsds_train")
    X = np.column_stack([col(tr, k) for k in FEATS])
    y = np.log(col(tr, "b550"))
    ok = np.all(np.isfinite(X), 1)
    rf = RandomForestRegressor(300, min_samples_leaf=3, random_state=0, n_jobs=2).fit(X[ok], y[ok])
    return rf


def add_rf(rows, rf):
    X = np.column_stack([col(rows, k) for k in FEATS])
    X = np.nan_to_num(X)
    p = rf.predict(X)
    for r, v in zip(rows, p):
        r["RF-F"] = v


# ------------------------------------------------- range-aware constants
def g550(water, b):
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from render import WATERS, coefficients
    a, bb, c = coefficients(WATERS[water], b)
    G = a + (1 - 0.85) * bb
    return float(np.interp(550, [460, 540, 600], G[::-1])), float(np.interp(550, [460, 540, 600], c[::-1]))


def fit_range_constants():
    import rangemodel
    tr = load("bsds_train")
    Tc = col(tr, "ExTurb_Tc")
    d = col(tr, "dmean")
    c = np.array([g550(r["water"], float(r["b550"]))[1] for r in tr])
    return rangemodel.fit(Tc, c * d)


# ------------------------------------------------------------ tables
def physics_table(sets, rf):
    out = {}
    for name in sets:
        rows = load(name)
        add_rf(rows, rf)
        y = col(rows, "b550")
        g = col(rows, "scene")
        out[name] = {}
        for m in METHODS + LEARNED:
            x = col(rows, m)
            s = corr_suite(x, y)
            s["within"] = within_scene_kendall(x, y, g)
            s["ci"] = cluster_bootstrap(x, y, g, B=1000)
            out[name][m] = s
    return out


def tex_physics(T):
    sets = list(T)
    best = {s: {k: max(T[s][m][k] for m in METHODS) for k in ("SROCC", "KROCC", "PLCC", "within")}
            for s in sets}
    bestr = {s: min(T[s][m]["RMSE"] for m in METHODS) for s in sets}
    L = []
    for m in METHODS + LEARNED:
        cells = []
        for s in sets:
            for k in ("SROCC", "KROCC", "PLCC", "RMSE", "within"):
                v = T[s][m][k]
                txt = f"{100 * v:.1f}" if k != "RMSE" else f"{100 * v:.1f}"
                if m in METHODS and ((k == "RMSE" and v == bestr[s]) or (k != "RMSE" and v == best[s][k])):
                    txt = r"\textbf{" + txt + "}"
                cells.append(txt)
        if m == "CNN-R":
            L.append(r"\midrule")
        L.append(f"{LABEL.get(m, m)} & " + " & ".join(cells) + r" \\")
    return "\n".join(L)


def real_eval(rf):
    R = {}
    ui = load("uiqs")
    add_rf(ui, rf)
    uc = load("uccs")
    add_rf(uc, rf)
    u45 = load("u45")
    add_rf(u45, rf)
    eu = load("euvp")
    add_rf(eu, rf)
    yg = col(ui, "grade")
    yc = col(uc, "cast")
    for m in METHODS + LEARNED:
        r = {}
        x = col(ui, m)
        r["UIQS"] = spearmanr(x, yg)[0]
        r["UIQS_ci"] = cluster_bootstrap(x, yg, np.arange(len(x)), B=1000)
        r["UIQS_k"] = kendalltau(x, yg)[0]
        x = col(uc, m)
        r["UCCS"] = abs(spearmanr(x, yc)[0])
        x = col(u45, m)
        cat = np.array([q["cat"] for q in u45])
        r["U45"] = auc(x[cat == "haze"], x[cat != "haze"])
        pairs = {}
        for q in eu:
            pairs.setdefault(q["pair"], {})[q["role"]] = float(q[m])
        acc = [1.0 if p["distorted"] > p["reference"] else (0.5 if p["distorted"] == p["reference"] else 0.0)
               for p in pairs.values()]
        r["EUVP"] = float(np.mean(acc))
        R[m] = r
    return R


def tex_real(R):
    b_ui = max(R[m]["UIQS"] for m in METHODS)
    b_uc = min(R[m]["UCCS"] for m in METHODS)
    b_u4 = max(R[m]["U45"] for m in METHODS)
    b_eu = max(R[m]["EUVP"] for m in METHODS)
    L = []
    for m in METHODS + LEARNED:
        r = R[m]

        def bf(v, b, s):
            return r"\textbf{" + s + "}" if (m in METHODS and abs(v - b) < 1e-12) else s
        cells = [bf(r["UIQS"], b_ui, f"{100 * r['UIQS']:.1f}"),
                 f"[{100 * r['UIQS_ci'][0]:.1f}, {100 * r['UIQS_ci'][1]:.1f}]",
                 bf(r["UCCS"], b_uc, f"{100 * r['UCCS']:.1f}"),
                 bf(r["U45"], b_u4, f"{100 * r['U45']:.1f}"),
                 bf(r["EUVP"], b_eu, f"{100 * r['EUVP']:.1f}")]
        if m == "CNN-R":
            L.append(r"\midrule")
        L.append(f"{LABEL.get(m, m)} & " + " & ".join(cells) + r" \\")
    return "\n".join(L)


def significance(sets, rf):
    L = []
    allp = []
    recs = []
    for name in sets:
        rows = load(name)
        add_rf(rows, rf)
        y = col(rows, "b550")
        g = col(rows, "scene")
        xa = col(rows, "ExTurb")
        for m in METHODS[1:] + LEARNED:
            d, p, ci = paired_bootstrap_diff(xa, col(rows, m), y, g, B=2000)
            recs.append((name, m, d, p, ci))
            allp.append(p)
    # UIQS (no scene clusters: images are units)
    ui = load("uiqs")
    add_rf(ui, rf)
    y = col(ui, "grade")
    g = np.arange(len(ui))
    xa = col(ui, "ExTurb")
    for m in METHODS[1:] + LEARNED:
        d, p, ci = paired_bootstrap_diff(xa, col(ui, m), y, g, B=2000)
        recs.append(("UIQS", m, d, p, ci))
        allp.append(p)
    adj = holm(allp)
    return [(n, m, d, p, ci, a) for (n, m, d, p, ci), a in zip(recs, adj)]


def tex_sig(S):
    by = {}
    for n, m, d, p, ci, a in S:
        by.setdefault(m, {})[n] = (d, ci, a)
    sets = []
    for n, *_ in S:
        if n not in sets:
            sets.append(n)
    L = []
    for m in METHODS[1:] + LEARNED:
        cells = []
        for n in sets:
            d, ci, a = by[m][n]
            star = "$^{*}$" if a < 0.05 else ""
            cells.append(f"{100 * d:+.1f}{star} & [{100 * ci[0]:+.1f}, {100 * ci[1]:+.1f}]")
        L.append(f"{LABEL.get(m, m)} & " + " & ".join(cells) + r" \\")
    return "\n".join(L), sets


# ------------------------------------------------------------- figures
def fig_robust(rf):
    rows = load("robust")
    add_rf(rows, rf)
    factors = {}
    for r in rows:
        f, v = r["set"].split("=")
        factors.setdefault(f, {}).setdefault(v, []).append(r)
    order = ["noise", "jpeg", "gain", "range", "water"]
    xl = {"noise": r"noise $\sigma_n$", "jpeg": "JPEG quality", "gain": "camera gain $g$",
          "range": "mean range $\\bar d$ (m)", "water": "water type"}
    show = ["ExTurb", "PCD", "UCIQE", "UDCP", "Tenengrad", "RMSC", "CNN-R"]
    fig, axs = plt.subplots(1, 5, figsize=(7.16, 1.75), sharey=True)
    res = {}
    for ax, f in zip(axs, order):
        vals = list(factors[f].keys())
        if f != "water":
            vals = sorted(vals, key=float)
        xs = np.arange(len(vals))
        for m in show:
            ys = []
            for v in vals:
                rr = factors[f][v]
                ys.append(spearmanr(col(rr, m), col(rr, "b550"))[0])
            c, ls, mk = STY[m]
            lw = 1.4 if m == "ExTurb" else 0.9
            ax.plot(xs, ys, color=c, ls=ls, marker=mk, lw=lw, label=m if f == "noise" else None,
                    mfc="white" if m != "ExTurb" else c)
            res[(f, m)] = ys
        ax.set_xticks(xs)
        lab = [v if f == "water" else (f"{float(v):g}") for v in vals]
        if f == "water":
            lab = ["ocean.", "coast.", "harb."]
        ax.set_xticklabels(lab)
        ax.set_xlabel(xl[f])
        ax.set_ylim(0, 1.0)
    axs[0].set_ylabel("SROCC")
    fig.legend(loc="upper center", ncol=7, bbox_to_anchor=(0.5, 1.13))
    fig.savefig(f"{FIG}/robust.pdf")
    plt.close(fig)
    # pooled: the factor varies *within* the evaluation set
    pooled = {}
    for f in order:
        rr = sum(factors[f].values(), [])
        y = col(rr, "b550")
        pooled[f] = {m: spearmanr(col(rr, m), y)[0] for m in METHODS + LEARNED}
    L = []
    for m in METHODS + LEARNED:
        best = {f: max(pooled[f][q] for q in METHODS) for f in order}
        cells = []
        for f in order:
            v = pooled[f][m]
            t = f"{100 * v:.1f}"
            if m in METHODS and v == best[f]:
                t = r"\textbf{" + t + "}"
            cells.append(t)
        if m == "CNN-R":
            L.append(r"\midrule")
        L.append(f"{LABEL.get(m, m)} & " + " & ".join(cells) + r" \\")
    with open(f"{PAP}/tab_pooled_rows.tex", "w") as fh:
        fh.write("\n".join(L))
    for f in order:
        mac(f"Pool{f}Ex", f"{pooled[f]['ExTurb']:.3f}")
        mac(f"Pool{f}Ten", f"{pooled[f]['Tenengrad']:.3f}")
        mac(f"Pool{f}Lap", f"{pooled[f]['LapVar']:.3f}")
        mac(f"Pool{f}UCIQE", f"{pooled[f]['UCIQE']:.3f}")
    json.dump(pooled, open(f"{RES}/pooled_summary.json", "w"))
    return res


def fig_theory():
    t1 = json.load(open(f"{RES}/theory_t1.json"))
    t2 = json.load(open(f"{RES}/theory_t2.json"))
    t3 = json.load(open(f"{RES}/theory_t3.json"))
    fig, axs = plt.subplots(1, 3, figsize=(7.16, 2.0))
    ax = axs[0]
    for amp, mk, c in ((0.1, "o", "0.6"), (0.3, "s", "0.35"), (1.0, "^", "0.0")):
        s = np.array([o["sigma"] for o in t1 if o["amp"] == amp])
        h = np.array([o["sigma_hat"] for o in t1 if o["amp"] == amp])
        us = np.unique(s)
        mu = [np.median(h[s == u]) for u in us]
        q1 = [np.percentile(h[s == u], 25) for u in us]
        q3 = [np.percentile(h[s == u], 75) for u in us]
        ax.errorbar(us + (amp - 0.4) * 0.15, mu, yerr=[np.array(mu) - q1, np.array(q3) - mu], fmt=mk,
                    color=c, mfc="white", capsize=1.5, lw=0.7, label=f"$A={amp:g}$")
    sig = np.linspace(0.3, 5.2, 50)
    ax.plot(sig, np.sqrt(sig ** 2 + 0.0), "k--", lw=0.6, label="ideal")
    ax.set_xlabel(r"true edge width $\sigma$ (px)")
    ax.set_ylabel(r"$\hat\sigma_b$ (px)")
    ax.legend(loc="upper left")
    ax.set_title("(a) probe-ratio inversion")
    ax = axs[1]
    G = []
    for o in t2:
        Gv, cv = g550("coastal", o["b"])
        G.append(cv * o["d"])
    G = np.array(G)
    Tc = np.array([o["Tc"] for o in t2])
    gain = np.array([o["gain"] for o in t2])
    sc = np.array([o["scene"] for o in t2])
    # subtract per-scene clear-water offset at gain 1 for display
    for gv, mk, c in ((0.5, "v", "0.6"), (1.0, "o", "0.0"), (1.5, "^", "0.35")):
        m = gain == gv
        ub = np.unique(np.round(G[m], 4))
        med = [np.median(Tc[m][np.round(G[m], 4) == u]) for u in ub]
        ax.plot(ub, med, marker=mk, color=c, ls="-" if gv == 1 else ":", mfc="white", label=f"$g={gv:g}$")
    import rangemodel
    C = json.load(open(f"{RES}/range_constants.json"))
    xx = np.linspace(0.02, G.max(), 100)
    ax.plot(xx, rangemodel.model(xx, C["Ts"], C["beta"], C["kappa"]), "k--", lw=0.7, label="population model")
    m = (gain == 1.0)
    p = [0.0]
    ax.set_xlabel(r"beam optical depth $c_{550}d$")
    ax.set_ylabel(r"$T_c$ (median over scenes)")
    ax.legend(loc="lower right")
    ax.set_title("(b) $T_c$ vs. optical depth")
    ax = axs[2]
    A2 = np.array([r["A2"] for r in t3["rows"]])
    ax.hist(A2, bins=30, color="0.6", edgecolor="0.2", lw=0.4)
    ax.axvline(2.492, color="k", ls="--", lw=0.7)
    ax.text(2.6, ax.get_ylim()[1] * 0.85, "5% crit.", fontsize=6)
    ax.set_xlabel(r"Anderson--Darling $A^2$ (GEV fit)")
    ax.set_ylabel("images")
    ax.set_title("(c) GEV adequacy on UIQS")
    fig.tight_layout(w_pad=1.0)
    fig.savefig(f"{FIG}/theory.pdf")
    plt.close(fig)
    s_all = np.array([o["sigma"] for o in t1])
    h_all = np.array([o["sigma_hat"] for o in t1])
    mac("TaSpearman", f"{spearmanr(s_all, h_all)[0]:.3f}")
    rel = np.abs(h_all - s_all) / s_all
    mac("TaMedRelErr", f"{100 * np.median(rel[s_all >= 1]):.1f}")
    # amplitude invariance: spread of sigma_hat across amplitudes for same (trial, sigma)
    d = {}
    for o in t1:
        d.setdefault((o["trial"], o["sigma"]), []).append(o["sigma_hat"])
    spread = np.median([np.ptp(v) / np.mean(v) for v in d.values()])
    mac("TaAmpSpread", f"{100 * spread:.2f}")
    # gain invariance: |Tc(g)-Tc(1)| per scene/level
    key = {}
    for o in t2:
        key.setdefault((o["scene"], o["b"], o["d"]), {})[o["gain"]] = o["Tc"]
    dev = [max(abs(v[0.5] - v[1.0]), abs(v[1.5] - v[1.0])) for v in key.values()]
    mac("TbGainDev", fmt_sci(float(np.median(dev))))
    mac("TbGainDevMax", fmt_sci(float(np.percentile(dev, 95))))
    rho_s = []
    for s in np.unique(sc):
        mm = (sc == s) & (gain == 1.0)
        rho_s.append(spearmanr(G[mm], Tc[mm])[0])
    mac("TbWithinRho", f"{np.median(rho_s):.3f}")
    mac("TcADpass", f"{100 * np.mean(A2 < 2.492):.1f}")
    lp = np.array([r["loc_pwm"] for r in t3["rows"]])
    lm = np.array([r["loc_mle"] for r in t3["rows"]])
    mac("TcLocCorr", f"{np.corrcoef(lp, lm)[0, 1]:.4f}")
    mac("TcTpwm", fmt_sci(t3["t_pwm"] * 1e3))
    mac("TcTmle", fmt_sci(t3["t_mle"] * 1e3))
    mac("TcSpeedup", f"{t3['t_mle'] / t3['t_pwm']:.0f}")


def fig_scatter(rf):
    rows = load("bsds_test")
    add_rf(rows, rf)
    y = col(rows, "b550")
    show = ["ExTurb", "PCD", "UCIQE", "UDCP"]
    fig, axs = plt.subplots(1, 4, figsize=(7.16, 1.7))
    for ax, m in zip(axs, show):
        x = col(rows, m)
        lv = np.unique(y)
        pos = np.arange(len(lv))
        data = [x[y == u] for u in lv]
        bp = ax.boxplot(data, positions=pos, widths=0.6, patch_artist=True, showfliers=False,
                        medianprops=dict(color="k", lw=0.9), whiskerprops=dict(lw=0.6),
                        capprops=dict(lw=0.6), boxprops=dict(lw=0.6))
        for b in bp["boxes"]:
            b.set_facecolor("0.85" if m != "ExTurb" else "0.6")
        ax.set_xticks(pos)
        ax.set_xticklabels([f"{u:g}" for u in lv], rotation=60)
        ax.set_title(f"{m}  (SROCC {spearmanr(x, y)[0]:.2f})")
        ax.set_xlabel(r"$b_{550}$ (m$^{-1}$)")
    axs[0].set_ylabel("score (larger = more turbid)")
    fig.tight_layout(w_pad=0.6)
    fig.savefig(f"{FIG}/scatter_bsds.pdf")
    plt.close(fig)


def fig_sens():
    S = json.load(open(f"{RES}/sensitivity.json"))
    pars = [("s1", r"$s_1$ (px), $s_2=2s_1$"), ("ratio", r"$s_2/s_1$"), ("block", r"block $B$ (px)"),
            ("sw", r"$s_w$ (px)"), ("work_size", r"$N_w$ (px)"), ("eps", r"$\epsilon$"), ("lam", r"$\lambda$")]
    fig, axs = plt.subplots(1, 7, figsize=(7.16, 1.55), sharey=True)
    for ax, (p, lab) in zip(axs, pars):
        for sname, mk, c, ls in (("BSDS-UW", "o", "0.0", "-"), ("UIQS", "s", "0.45", "--")):
            ks = [k for k in S[sname] if k.startswith(p + "=")]
            vs = [float(k.split("=")[1]) for k in ks]
            o = np.argsort(vs)
            y = np.array(S[sname]["y"], float)
            ys = [spearmanr(S[sname][ks[i]], y)[0] for i in o]
            ax.plot(range(len(o)), ys, marker=mk, color=c, ls=ls, mfc="white", label=sname)
            ax.set_xticks(range(len(o)))
            ax.set_xticklabels([f"{vs[i]:g}" for i in o], rotation=60)
        ax.set_xlabel(lab)
        ax.set_ylim(0.3, 1.0)
    axs[0].set_ylabel("SROCC")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.1))
    fig.tight_layout(w_pad=0.3)
    fig.savefig(f"{FIG}/sensitivity.pdf")
    plt.close(fig)
    rng = {}
    for sname in S:
        y = np.array(S[sname]["y"], float)
        vals = [spearmanr(S[sname][k], y)[0] for k in S[sname] if k != "y" and not k.startswith("lam=")]
        rng[sname] = (min(vals), max(vals))
    mac("SensBSDSmin", f"{rng['BSDS-UW'][0]:.3f}")
    mac("SensBSDSmax", f"{rng['BSDS-UW'][1]:.3f}")
    mac("SensUIQSmin", f"{rng['UIQS'][0]:.3f}")
    mac("SensUIQSmax", f"{rng['UIQS'][1]:.3f}")


def tex_ablation():
    A = json.load(open(f"{RES}/ablation.json"))
    names = [k for k in A["BSDS-UW"] if k not in ("y", "g")]
    L = []
    full = {s: spearmanr(A[s]["full"], A[s]["y"])[0] for s in A}
    for n in names:
        cells = []
        for s in ("BSDS-UW", "KM-UW", "UIQS"):
            v = spearmanr(A[s][n], A[s]["y"])[0]
            if n == "full":
                cells.append(f"{100 * v:.1f}")
            else:
                cells.append(f"{100 * v:.1f} ({100 * (v - full[s]):+.1f})")
        if s == "UIQS":
            pass
        L.append(f"{n} & " + " & ".join(cells) + r" \\")
    return "\n".join(L), A


def runtime_table():
    rows = load("bsds_test")
    L = []
    for m in METHODS:
        t = np.median(col(rows, "t_" + m)) * 1e3
        L.append((m, t))
    return L


def write_macros():
    with open(f"{PAP}/results_macros.tex", "w") as f:
        f.write("% auto-generated by analysis.py -- do not edit\n")
        for k, v in MAC.items():
            f.write(f"\\expandafter\\def\\csname R@{k}\\endcsname{{{v}}}\n")


if __name__ == "__main__":
    import sys
    rf = fit_rf()
    sets = ["bsds_test", "km", "syndl"]
    # counts
    for k, n in (("nSynDL", "syndl"), ("nKM", "km"), ("nRobust", "robust"), ("nRange", "range")):
        mac(k, str(len(load(n))))
    mac("nBSDS", str(sum(len(load(n)) for n in ("bsds_train", "bsds_test")) +
                     len(list(csv.DictReader(open('bench/bsds_val.csv'))))))
    T = physics_table(sets, rf)
    with open(f"{PAP}/tab_physics_rows.tex", "w") as f:
        f.write(tex_physics({s: T[s] for s in ("bsds_test", "km")}))
    with open(f"{PAP}/tab_syndl_rows.tex", "w") as f:
        f.write(tex_physics({"syndl": T["syndl"]}))
    json.dump({s: {m: {k: (v if k != "ci" else list(v)) for k, v in T[s][m].items()} for m in T[s]} for s in T},
              open(f"{RES}/physics_summary.json", "w"), default=float)
    for s, tag in (("bsds_test", "BSDS"), ("km", "KM"), ("syndl", "SynDL")):
        e = T[s]["ExTurb"]
        mac(f"{tag}ExS", f"{e['SROCC']:.3f}")
        mac(f"{tag}ExSci", f"[{e['ci'][0]:.3f}, {e['ci'][1]:.3f}]")
        mac(f"{tag}ExP", f"{e['PLCC']:.3f}")
        mac(f"{tag}ExW", f"{e['within']:.3f}")
        others = sorted(((T[s][m]["SROCC"], m) for m in METHODS[1:]), reverse=True)
        mac(f"{tag}BestOther", others[0][1])
        mac(f"{tag}BestOtherS", f"{others[0][0]:.3f}")
        mac(f"{tag}CNN", f"{T[s]['CNN-R']['SROCC']:.3f}")
        mac(f"{tag}RF", f"{T[s]['RF-F']['SROCC']:.3f}")
        mac(f"{tag}PCD", f"{T[s]['PCD']['SROCC']:.3f}")
        mac(f"{tag}UCIQE", f"{T[s]['UCIQE']['SROCC']:.3f}")
    R = real_eval(rf)
    json.dump({m: {k: (list(v) if isinstance(v, np.ndarray) else v) for k, v in R[m].items()} for m in R},
              open(f"{RES}/real_summary.json", "w"), default=float)
    with open(f"{PAP}/tab_real_rows.tex", "w") as f:
        f.write(tex_real(R))
    for m in ("ExTurb", "PCD", "UCIQE", "UIQM", "Tenengrad", "CNN-R", "RF-F", "UDCP"):
        t = m.replace("-", "")
        for k in ("UIQS", "UCCS", "U45", "EUVP"):
            mac(f"{t}{k}", f"{R[m][k]:.3f}")
    # Friedman over all evaluation sets (training-free methods only)
    perf = []
    for m in METHODS:
        perf.append([T["bsds_test"][m]["SROCC"], T["km"][m]["SROCC"], R[m]["UIQS"],
                     1 - R[m]["UCCS"], R[m]["U45"], R[m]["EUVP"]])
    perf = np.array(perf)
    ranks = np.array([len(METHODS) + 1 - np.argsort(np.argsort(c)) - 1 for c in perf.T]).T
    ranks = np.mean(np.array([(-perf[:, j]).argsort().argsort() + 1 for j in range(perf.shape[1])]).T, axis=1)
    st, pv = friedmanchisquare(*perf.T.tolist()) if False else friedmanchisquare(*[perf[i] for i in range(len(METHODS))])
    mac("FriedmanChi", f"{st:.2f}")
    mac("FriedmanP", fmt_sci(pv))
    order = np.argsort(ranks)
    with open(f"{PAP}/tab_rank_rows.tex", "w") as f:
        for i in order:
            f.write(f"{LABEL.get(METHODS[i], METHODS[i])} & {ranks[i]:.2f} \\\\\n")
    mac("ExRank", f"{ranks[0]:.2f}")
    S = significance(["bsds_test", "km"], rf)
    txt, ssets = tex_sig(S)
    with open(f"{PAP}/tab_sig_rows.tex", "w") as f:
        f.write(txt)
    nsig = sum(1 for n, m, d, p, ci, a in S if a < 0.05 and d > 0)
    mac("SigWins", str(nsig))
    mac("SigTotal", str(len(S)))
    mac("SigLoss", str(sum(1 for n, m, d, p, ci, a in S if a < 0.05 and d < 0)))
    json.dump([[n, m, d, p, list(ci), a] for n, m, d, p, ci, a in S], open(f"{RES}/significance.json", "w"))
    rob = fig_robust(rf)
    json.dump({f"{k[0]}|{k[1]}": v for k, v in rob.items()}, open(f"{RES}/robust_summary.json", "w"))
    fig_scatter(rf)
    fig_sens()
    abl_txt, A = tex_ablation()
    with open(f"{PAP}/tab_ablation_rows.tex", "w") as f:
        f.write(abl_txt)
    rt = runtime_table()
    with open(f"{PAP}/tab_runtime_rows.tex", "w") as f:
        for m, t in rt:
            f.write(f"{LABEL.get(m, m)} & {fmt_sci(t)} \\\\\n".replace(fmt_sci(t), "$" + fmt_sci(t) + "$"))
    mac("RtEx", fmt_sci(dict(rt)["ExTurb"]))
    mac("RtPCD", fmt_sci(dict(rt)["PCD"]))
    Ts, beta, kappa = fit_range_constants()
    import rangemodel
    target = float(rangemodel.model(1.0, Ts, beta, kappa))
    mac("Ts", f"{Ts:.3f}")
    mac("beta", f"{beta:.3f}")
    mac("kappa", f"{kappa:.3f}")
    mac("PlTarget", f"{target:.2f}")
    json.dump({"Ts": Ts, "beta": beta, "kappa": kappa, "target": target}, open(f"{RES}/range_constants.json", "w"))
    fig_theory()
    write_macros()
    print(json.dumps(MAC, indent=1))
