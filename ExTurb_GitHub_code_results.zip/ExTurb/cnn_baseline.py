"""Supervised learned baselines trained on BSDS-UW train renders.

* CNN-R : compact 6-layer CNN regressing log b550 from a 160x160 resized image
          (stands in for supervised image-to-turbidity regressors such as
          Turbidivision, which need paired turbidimeter labels).
* RF-F  : random forest on the ten training-free baseline scores + ExTurb.
Both are evaluated on every set; the gap between in-distribution and
out-of-distribution performance is the point of the comparison.
"""
import csv
import glob
import json
import sys

import numpy as np
import torch
import torch.nn as nn
from PIL import Image

from compute import items_for

RES = "results"
torch.manual_seed(0)
np.random.seed(0)
SZ = 160


def load(path):
    im = Image.open(path).convert("RGB").resize((SZ, SZ), Image.BILINEAR)
    return np.asarray(im, dtype=np.float32).transpose(2, 0, 1) / 255.0


class Net(nn.Module):
    def __init__(self):
        super().__init__()
        ch = [3, 24, 32, 48, 64, 96]
        layers = []
        for a, b in zip(ch[:-1], ch[1:]):
            layers += [nn.Conv2d(a, b, 3, padding=1), nn.BatchNorm2d(b), nn.ReLU(), nn.MaxPool2d(2)]
        self.f = nn.Sequential(*layers, nn.Conv2d(96, 96, 3, padding=1), nn.ReLU(),
                               nn.AdaptiveAvgPool2d(1))
        self.h = nn.Linear(96, 1)

    def forward(self, x):
        return self.h(self.f(x).flatten(1)).squeeze(1)


def rows(csvf):
    with open(csvf) as f:
        return list(csv.DictReader(f))


def train():
    tr = rows("bench/bsds_train.csv")
    va = rows("bench/bsds_val.csv")
    Xtr = torch.tensor(np.stack([load(r["file"]) for r in tr]))
    ytr = torch.tensor(np.log([float(r["b550"]) for r in tr]), dtype=torch.float32)
    Xva = torch.tensor(np.stack([load(r["file"]) for r in va]))
    yva = np.log([float(r["b550"]) for r in va])
    net = Net()
    opt = torch.optim.AdamW(net.parameters(), 2e-3, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, 40)
    best, best_state = -1, None
    from scipy.stats import spearmanr
    for ep in range(40):
        net.train()
        perm = torch.randperm(len(Xtr))
        for i in range(0, len(perm), 32):
            idx = perm[i:i + 32]
            x = Xtr[idx]
            if np.random.rand() < 0.5:
                x = torch.flip(x, [3])
            loss = nn.functional.smooth_l1_loss(net(x), ytr[idx])
            opt.zero_grad()
            loss.backward()
            opt.step()
        sched.step()
        net.eval()
        with torch.no_grad():
            p = torch.cat([net(Xva[i:i + 64]) for i in range(0, len(Xva), 64)]).numpy()
        s = spearmanr(yva, p)[0]
        print(ep, round(float(loss), 4), round(s, 4), flush=True)
        if s > best:
            best, best_state = s, {k: v.clone() for k, v in net.state_dict().items()}
    net.load_state_dict(best_state)
    torch.save(best_state, f"{RES}/cnn_r.pt")
    json.dump({"val_srocc": best}, open(f"{RES}/cnn_r_val.json", "w"))
    return net


def predict(net, spec, name):
    items = items_for(spec)
    net.eval()
    out = []
    with torch.no_grad():
        for i in range(0, len(items), 64):
            x = torch.tensor(np.stack([load(p) for p, _ in items[i:i + 64]]))
            out += net(x).numpy().tolist()
    with open(f"{RES}/cnn_{name}.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["file", "CNN-R"])
        for (p, _), v in zip(items, out):
            w.writerow([p, v])


if __name__ == "__main__":
    if sys.argv[1] == "train":
        net = train()
    else:
        net = Net()
        net.load_state_dict(torch.load(f"{RES}/cnn_r.pt"))
    specs = {"syndl": "bench/syndl.csv", "bsds_test": "bench/bsds_test.csv", "km": "bench/km.csv",
             "robust": "bench/robust.csv", "range": "bench/range.csv",
             "uiqs": "uiqs", "uccs": "uccs", "u45": "u45", "euvp": "euvp"}
    for name, spec in specs.items():
        try:
            predict(net, spec, name)
            print("pred", name, flush=True)
        except FileNotFoundError as e:
            print("skip", name, e)
