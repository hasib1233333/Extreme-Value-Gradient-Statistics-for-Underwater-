import csv,numpy as np,sys,json
from scipy.stats import spearmanr
from joblib import Parallel,delayed
from datasets import load_rgb
from exturb import exturb,ExTurbParams,resize_long
from analysis import g550
base={k:v for k,v in json.load(open('results/exturb_params.json')).items() if k!='lam'}
def feats(path):
    img=resize_long(load_rgb(path,512),512); out={}
    for i,c in enumerate('RGB'):
        r=exturb(img[...,i],ExTurbParams(**{**base,'work_size':None})); out['Tc'+c]=r['T_c']; out['sb'+c]=r['sigma_b']
    r=exturb(img,ExTurbParams(**{**base,'work_size':None})); out['TcL']=r['T_c']; out['sbL']=r['sigma_b']
    return out
for name in sys.argv[1:]:
    R=list(csv.DictReader(open(f'bench/{name}.csv')))
    F=Parallel(n_jobs=2)(delayed(feats)(r['file']) for r in R)
    y=np.array([float(r['b550']) for r in R]); d=np.array([float(r['dmean']) for r in R])
    G=np.array([g550(r['water'],float(r['b550']))[0] for r in R])
    A=lambda k: np.array([f[k] for f in F])
    T=np.stack([A('TcR'),A('TcG'),A('TcB')],1); S=np.stack([A('sbR'),A('sbG'),A('sbB')],1)
    cand={'L':A('TcL'),'R':T[:,0],'G':T[:,1],'B':T[:,2],'min':T.min(1),'median':np.median(T,1),'mean':T.mean(1),
          'min+0.5ln(sbL)':T.min(1)+0.5*np.log(A('sbL')+0.25),'L+0.5ln(sbL)':A('TcL')+0.5*np.log(A('sbL')+0.25),
          'min+0.5ln(sbmin)':T.min(1)+0.5*np.log(S[np.arange(len(S)),T.argmin(1)]+0.25)}
    for k,x in cand.items(): print(name,k,round(spearmanr(x,y)[0],3),round(spearmanr(x,G*d)[0],3))
