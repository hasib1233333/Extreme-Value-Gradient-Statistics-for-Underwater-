"""Revision 3, comment 1: a regularised full-GEV extension, learning curves and transfer.

Models (all map features to ln NTU):
  ExTurb-C        -ln mu(s1), ln(mu(s1)/mu(s2))                       3 coef
  q99             same structure with the 99th percentile of W         3 coef
  full GEV (OLS)  -ln mu, ln rho, ln sg(s1), ln sg(s2), xi(s1), xi(s2)  7 coef
  full GEV (ridge) the same features, standardised on the training set, ridge penalty
                  chosen by 5-fold cross-validation inside the training set
Learning curves: training subsets of MFT Train of size n (20 random draws each),
evaluated on MFT Eva (in domain) and on TUB (transfer). Transfer TUB -> Eva uses all TUB.
"""
import json

import numpy as np
import pandas as pd
from scipy.stats import spearmanr

R = "real_data"
OUT = "real_data/revision"
SIZES = [25, 50, 100, 200, 400, 800, 1600, 3200, 4320]
REPS = 20
LAMS = np.logspace(-3, 3, 25)
rng = np.random.default_rng(31)


def X_of(d, kind):
    lmu1, lmu2 = np.log(d["mu_1.5"].values), np.log(d["mu_3"].values)
    if kind == "ExTurb-C":
        return np.c_[-lmu1, lmu1 - lmu2]
    if kind == "q99":
        a, b = np.log(d["gq99_1.5"].values), np.log(d["gq99_3"].values)
        return np.c_[-a, a - b]
    return np.c_[-lmu1, lmu1 - lmu2, np.log(d["sg_1.5"].values), np.log(d["sg_3"].values),
                 d["xi_1.5"].values, d["xi_3"].values]


def fit(X, y, lam=0.0):
    mu, sd = X.mean(0), X.std(0) + 1e-12
    Z = (X - mu) / sd
    A = np.c_[Z, np.ones(len(Z))]
    P = lam * np.eye(A.shape[1]); P[-1, -1] = 0
    w = np.linalg.solve(A.T @ A + P, A.T @ y)
    return mu, sd, w


def pred(m, X):
    mu, sd, w = m
    return np.c_[(X - mu) / sd, np.ones(len(X))] @ w


def cv_lam(X, y, k=5):
    idx = rng.permutation(len(y)); folds = np.array_split(idx, k)
    best, bl = np.inf, LAMS[0]
    for lam in LAMS:
        e = 0
        for f in folds:
            tr = np.setdiff1d(idx, f)
            e += np.sum((y[f] - pred(fit(X[tr], y[tr], lam), X[f])) ** 2)
        if e < best:
            best, bl = e, lam
    return bl


def model(kind, X, y):
    if kind == "full GEV (ridge)":
        return fit(X, y, cv_lam(X, y) if len(y) >= 25 else 10.0)
    return fit(X, y, 0.0)


def ev(p, y):
    return spearmanr(p, y)[0], float(np.median(np.abs(np.exp(p) - np.exp(y)) / np.exp(y)))


def main():
    fm = pd.read_csv(f"{R}/features_MFT.csv")
    ft = pd.read_csv(f"{R}/features_TUB.csv")
    tr, evd = fm[fm.split == "Train"].reset_index(drop=True), fm[fm.split == "Eva"].reset_index(drop=True)
    ytr, yev, yt = np.log(tr.ntu.values), np.log(evd.ntu.values), np.log(ft.ntu.values)
    kinds = ["ExTurb-C", "q99", "full GEV (OLS)", "full GEV (ridge)"]
    feat = lambda d, k: X_of(d, "full" if k.startswith("full") else k)
    rows = []
    for n in SIZES:
        for r in range(REPS if n < len(tr) else 1):
            i = rng.choice(len(tr), n, replace=False) if n < len(tr) else np.arange(len(tr))
            for k in kinds:
                m = model(k, feat(tr.iloc[i], k), ytr[i])
                s_e, m_e = ev(pred(m, feat(evd, k)), yev)
                s_t, m_t = ev(pred(m, feat(ft, k)), yt)
                rows.append(dict(n=n, rep=r, model=k, eva_srocc=s_e, eva_medre=m_e, tub_srocc=s_t, tub_medre=m_t))
    L = pd.DataFrame(rows)
    L.to_csv(f"{OUT}/learning_curves.csv", index=False)
    S = L.groupby(["model", "n"]).agg(eva=("eva_srocc", "mean"), eva_sd=("eva_srocc", "std"),
                                      tub=("tub_srocc", "mean"), tub_medre=("tub_medre", "median")).reset_index()
    S.to_csv(f"{OUT}/learning_curves_summary.csv", index=False)
    pd.set_option("display.width", 200)
    print(S.round(3).to_string())
    # TUB -> Eva transfer with all TUB
    tt = {}
    for k in kinds:
        m = model(k, feat(ft, k), yt)
        tt[k] = dict(zip(["srocc", "medre"], ev(pred(m, feat(evd, k)), yev)))
    lam_full = cv_lam(feat(tr, "full"), ytr)
    print(json.dumps(tt, indent=1), "ridge lambda (full Train):", lam_full)
    json.dump({"tub_to_eva": tt, "ridge_lambda_train": float(lam_full)}, open(f"{OUT}/ext_gev.json", "w"), indent=1)


if __name__ == "__main__":
    main()
