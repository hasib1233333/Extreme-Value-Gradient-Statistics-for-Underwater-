"""Run every training-free method on a list of images and cache the scores.

python compute.py <name> <csv-or-list-spec>
Writes results/scores_<name>.csv
"""
import csv
import json
import os
import sys
import time

import numpy as np
from joblib import Parallel, delayed

from baselines import metric_suite
from datasets import (euvp_pairs, load_rgb, u45_items, uccs_items, uiqs_items,
                      utts_paths)
from exturb import ExTurbParams, exturb

HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.environ.get("EXTURB_RES", "results")
PARAMS_FILE = os.path.join(HERE, "exturb_params.json")
if not os.path.exists(PARAMS_FILE):
    PARAMS_FILE = f"{RES}/exturb_params.json"


def frozen_params():
    with open(PARAMS_FILE) as f:
        d = json.load(f)
    lam = d.pop("lam")
    return ExTurbParams(**d), lam


def score_one(path, long_side=512):
    img = load_rgb(path, long_side)
    p, lam = frozen_params()
    out = {}
    t = time.perf_counter()
    r = exturb(img, p)
    out["t_ExTurb"] = time.perf_counter() - t
    out["ExTurb"] = r["T_c"] + lam * np.log(r["sigma_b"] + 0.25)
    out["ExTurb_Tc"] = r["T_c"]
    out["ExTurb_sigma"] = r["sigma_b"]
    out["ExTurb_rho"] = r["rho"]
    out["ExTurb_xi"] = r["xi"]
    for k, fn in metric_suite().items():
        t = time.perf_counter()
        try:
            out[k] = float(fn(img))
        except Exception:
            out[k] = float("nan")
        out["t_" + k] = time.perf_counter() - t
    return out


def items_for(spec):
    if spec.endswith(".csv"):
        with open(spec) as f:
            rows = list(csv.DictReader(f))
        return [(r["file"], r) for r in rows]
    if spec == "uiqs":
        return [(f, {"file": f, "grade": g}) for f, g in uiqs_items()]
    if spec == "uccs":
        return [(f, {"file": f, "cast": c}) for f, c in uccs_items()]
    if spec == "u45":
        return [(f, {"file": f, "cat": c}) for f, c in u45_items()]
    if spec == "euvp":
        out = []
        for i, (a, b) in enumerate(euvp_pairs()):
            out.append((a, {"file": a, "pair": i, "role": "distorted"}))
            out.append((b, {"file": b, "pair": i, "role": "reference"}))
        return out
    if spec == "utts":
        return [(f, {"file": f}) for f in utts_paths()]
    raise ValueError(spec)


if __name__ == "__main__":
    name, spec = sys.argv[1], sys.argv[2]
    items = items_for(spec)
    res = Parallel(n_jobs=-1, batch_size=4)(delayed(score_one)(p) for p, _ in items)
    keys = list(items[0][1].keys()) + list(res[0].keys())
    with open(f"{RES}/scores_{name}.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for (_, meta), r in zip(items, res):
            w.writerow({**meta, **r})
    print("wrote", len(res))
