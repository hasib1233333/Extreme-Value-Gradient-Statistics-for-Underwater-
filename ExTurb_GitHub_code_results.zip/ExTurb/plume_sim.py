"""Dynamic AUV survey through a time-varying sediment plume.

* 2-D advection-diffusion of suspended sediment concentration C(x,y,t)
  (dredging point source, tidal current rotating with a 12.42 h period,
  first-order upwind advection + explicit diffusion, CFL-limited step).
* Turbidity field: b550(x,y,t) = b_bg + k_b C.
* Seabed albedo: a 2048x2048 mosaic of Kodak/McMaster scenes (in-air natural
  textures standing in for seabed texture), gently tilted relief.
* AUV: lawn-mower survey, downward camera, altitude h (m); each frame renders
  the seabed footprint with the local turbidity and range = altitude + relief.
* Controllers: (i) fixed altitude, (ii) ExTurb-adaptive altitude that lowers
  the vehicle when the image turbidity index exceeds a target.

Outputs per frame: truth b550/c550, ExTurb index, range-aware c estimate,
ORB keypoint repeatability against the clear-water render of the same
footprint (a proxy for downstream visual-navigation quality).
"""
from __future__ import annotations

import json
import math
import sys

import numpy as np
from scipy import ndimage as ndi
from skimage.feature import ORB, match_descriptors

from datasets import camera_out, km_paths, load_rgb
from exturb import exturb
from render import WATERS, RenderCfg, coefficients, render, to_linear

RES = "results"


# ------------------------------------------------------------- plume model
class Plume:
    def __init__(self, n=160, dx=1.0, D=0.08, src=(40, 80), q=2.0, seed=0):
        self.n, self.dx, self.D = n, dx, D
        self.C = np.zeros((n, n))
        self.src = src
        self.q = q
        self.rng = np.random.default_rng(seed)

    def current(self, t):
        w = 2 * math.pi / (12.42 * 3600)
        return 0.06 * math.cos(w * t) + 0.04, 0.06 * math.sin(w * t)

    def step(self, t, dt):
        u, v = self.current(t)
        C = self.C
        dx = self.dx
        # upwind advection
        if u > 0:
            ax = (C - np.roll(C, 1, 1)) / dx
        else:
            ax = (np.roll(C, -1, 1) - C) / dx
        if v > 0:
            ay = (C - np.roll(C, 1, 0)) / dx
        else:
            ay = (np.roll(C, -1, 0) - C) / dx
        lap = (np.roll(C, 1, 0) + np.roll(C, -1, 0) + np.roll(C, 1, 1) + np.roll(C, -1, 1) - 4 * C) / dx ** 2
        C = C + dt * (-u * ax - v * ay + self.D * lap)
        # intermittent source (dredge cycles) + slow settling
        on = 1.0 if (t // 1800) % 2 == 0 else 0.25
        sy, sx = self.src
        C[sy - 1:sy + 2, sx - 1:sx + 2] += dt * self.q * on / 9
        C *= math.exp(-dt / (6 * 3600))
        C[:, 0] = C[:, -1] = C[0, :] = C[-1, :] = 0
        self.C = np.clip(C, 0, None)

    def run_until(self, t0, t1):
        u_max = 0.11
        dt = min(0.25 * self.dx / u_max, 0.1 * self.dx ** 2 / self.D)
        t = t0
        while t < t1:
            h = min(dt, t1 - t)
            self.step(t, h)
            t += h
        return t1


# ------------------------------------------------------------- seabed map
def seabed(size=2048, seed=0):
    rng = np.random.default_rng(seed)
    ps = km_paths()
    tiles = [load_rgb(p, long_side=512) for p in ps]
    mos = np.zeros((size, size, 3))
    for y in range(0, size, 512):
        for x in range(0, size, 512):
            t = tiles[rng.integers(len(tiles))]
            t = ndi.zoom(t, (512 / t.shape[0], 512 / t.shape[1], 1), order=1)
            # sandy-seabed tone: desaturate and warm slightly
            g = t.mean(axis=2, keepdims=True)
            t = 0.55 * t + 0.45 * g * np.array([1.05, 1.0, 0.85])
            mos[y:y + 512, x:x + 512] = t[:512, :512]
    mos = ndi.gaussian_filter(mos, (1.5, 1.5, 0), mode='wrap')  # remove tile seams' aliasing
    relief = ndi.gaussian_filter(rng.normal(size=(size, size)), 120, mode='wrap')
    relief = 0.4 * relief / np.abs(relief).max()
    return np.clip(mos, 0, 1), relief


# ------------------------------------------------------------ simulation
def orb_repeat(img, ref):
    """Fraction of ORB matches between degraded and clear render (same view)."""
    def feats(x):
        o = ORB(n_keypoints=300, fast_threshold=0.05)
        try:
            o.detect_and_extract(x.mean(axis=2))
            return o.keypoints, o.descriptors
        except RuntimeError:
            return np.zeros((0, 2)), np.zeros((0, 256), bool)
    kr, dr = feats(ref)
    ki, di = feats(img)
    if len(kr) == 0 or len(ki) == 0:
        return 0.0
    m = match_descriptors(dr, di, cross_check=True, max_ratio=0.8)
    if len(m) == 0:
        return 0.0
    d = np.linalg.norm(kr[m[:, 0]] - ki[m[:, 1]], axis=1)
    return float(np.sum(d < 3.0)) / len(kr)


def survey(controller="fixed", h0=2.5, target_delta=0.5, seed=0, n_lines=8, frames_per_line=24,
           out_frames=None):
    rng = np.random.default_rng(seed)
    bed, relief = seabed(seed=seed)
    S = bed.shape[0]
    plume = Plume(seed=seed)
    plume.run_until(0, 3 * 3600)  # spin-up 3 h
    t = 3 * 3600
    # scale concentration once so that the 99th percentile maps to b550 = 1.8 m^-1
    kb = 1.7 / max(np.percentile(plume.C, 99), 1e-9)
    water = WATERS["coastal"]
    px_per_m = 160  # seabed texture resolution (px per metre); texture tiles periodically
    fov = 0.9  # rad, square footprint side = 2 h tan(fov/2)
    h = h0
    rows = []
    L = plume.n * plume.dx  # survey domain side (m)
    for li in range(n_lines):
        ys = 0.15 * L + (li + 0.5) / n_lines * 0.7 * L
        xs_all = np.linspace(0.15 * L, 0.85 * L, frames_per_line)
        if li % 2:
            xs_all = xs_all[::-1]
        for xs in xs_all:
            t = plume.run_until(t, t + 25.0)  # 25 s between frames
            cy = int(np.clip(ys / plume.dx, 0, plume.n - 1))
            cx = int(np.clip(xs / plume.dx, 0, plume.n - 1))
            b = float(min(0.08 + kb * plume.C[cy, cx], 3.0))
            side_m = 2 * h * math.tan(fov / 2)
            side_px = int(side_m * px_per_m)
            y0 = int(ys * px_per_m - side_px / 2)
            x0 = int(xs * px_per_m - side_px / 2)
            iy = np.arange(y0, y0 + side_px) % S
            ix = np.arange(x0, x0 + side_px) % S
            J = bed[np.ix_(iy, ix)]
            rel = relief[np.ix_(iy, ix)]
            zoom = 256 / side_px
            J = np.clip(ndi.zoom(J, (zoom, zoom, 1), order=1), 0, 1)
            rel = ndi.zoom(rel, zoom, order=1)
            d = np.clip(h - rel, 0.3, None)
            Jl = to_linear(J)
            cfg = RenderCfg(res_scale=0.5)
            I = camera_out(render(Jl, d, water, b, cfg, rng=rng, noise_sigma=0.006))
            Iref = camera_out(render(Jl, d, water, 0.02, cfg, rng=rng, noise_sigma=0.006))
            r = exturb(I)
            _, _, c = coefficients(water, b)
            c550 = float(np.interp(550, [460, 540, 600], c[::-1]))
            rep = orb_repeat(I, Iref)
            rows.append(dict(t=t, line=li, x=float(xs), y=float(ys), h=h, b550=b, c550=c550,
                             Tc=r["T_c"], sigma=r["sigma_b"], rep=rep, swath=side_m))
            if out_frames is not None and len(rows) in out_frames:
                np.save(f"{RES}/frame_{controller}_{len(rows)}.npy", I)
            if controller == "adaptive":
                # self-referenced set-point: median T_c of the first 8 frames
                # (taken at h0) plus a tolerated increase of delta log-units
                if len(rows) <= 8:
                    continue
                if len(rows) == 9:
                    target = float(np.median([q["Tc"] for q in rows[:8]])) + target_delta
                # proportional altitude law on the turbidity index
                err = r["T_c"] - target
                h = float(np.clip(h - 0.6 * err, 0.8, h0))
    return rows, 0.08 + kb * plume.C


if __name__ == "__main__":
    which = sys.argv[1]
    if which == "fixed":
        rows, C = survey("fixed", out_frames={20, 60, 100, 140})
        np.save(f"{RES}/plume_final.npy", C)
    else:
        rows, C = survey("adaptive", target_delta=float(sys.argv[2]), out_frames={20, 60, 100, 140})
    with open(f"{RES}/plume_{which}.json", "w") as f:
        json.dump(rows, f)
    print(len(rows))
