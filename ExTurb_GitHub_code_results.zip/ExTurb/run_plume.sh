#!/bin/sh
cd "$(dirname "$0")"
python3 -W ignore exposure_test.py > results/exposure.log 2>&1
python3 -W ignore analysis.py > results/analysis.log 2>&1
python3 -W ignore plume_sim.py fixed > results/plume_fixed.log 2>&1
T=$(python3 -c "import json;print(json.load(open('results/range_constants.json'))['target'])")
echo "target $T" > results/plume_target.txt
python3 -W ignore plume_sim.py adaptive $T > results/plume_adaptive.log 2>&1
python3 -W ignore analysis2.py > results/analysis2.log 2>&1
echo ALL_DONE >> results/plume_target.txt
