"""Freeze every calibrated model BEFORE the untouched MFT Eva split is processed.

Coefficients are fitted on MFT Train; the split-conformal quantile q (alpha=0.1)
is computed on MFT Test residuals. A transfer model is fitted on all of TUB with
q from leave-one-scene-out residuals. The output JSON records the SHA-256 of
every input file and the UTC time, so the Eva evaluation can be audited.
"""
import datetime
import hashlib
import json
import sys

import numpy as np
import pandas as pd

D = sys.argv[1] if len(sys.argv) > 1 else "real_data"
ALPHA = 0.1
BASE = ["UCIQE", "UIQM", "DCP", "UDCP", "DynRange", "RMSC", "Tenengrad", "LapVar", "Entropy", "PCD"]


def F(df):
    f = pd.DataFrame({"Tc": df.ExTurb_Tc, "lnrho": np.log(df.ExTurb_rho), "ExTurb": df.ExTurb})
    for b in BASE:
        f[b] = df[b]
    return f


MODELS = {"ExTurb-C": ["Tc", "lnrho"], "ExTurb frozen": ["ExTurb"], "T_c": ["Tc"],
          "UCIQE+DynRange": ["UCIQE", "DynRange"]}
MODELS.update({b: [b] for b in BASE})


def lsq(X, y):
    return np.linalg.lstsq(np.c_[X, np.ones(len(X))], y, rcond=None)[0]


def pred(c, X):
    return np.c_[X, np.ones(len(X))] @ c


def qconf(r):
    n = len(r)
    return float(np.quantile(r, min(1, np.ceil((n + 1) * (1 - ALPHA)) / n)))


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def main():
    files = {k: f"{D}/{k}_scores.csv" for k in ("MFT_train", "MFT_test", "TUB")}
    tr, te, tub = (pd.read_csv(files[k]) for k in ("MFT_train", "MFT_test", "TUB"))
    Ftr, Fte, Ft = F(tr), F(te), F(tub)
    ytr, yte, yt = np.log(tr.ntu), np.log(te.ntu), np.log(tub.ntu)
    g = tub.group.values
    out = {"created_utc": datetime.datetime.utcnow().isoformat(timespec="seconds") + "Z",
           "alpha": ALPHA, "inputs_sha256": {k: sha(v) for k, v in files.items()},
           "note": "Frozen before MFT Eva was processed. Do not refit.", "mft": {}, "tub": {}}
    for k, cols in MODELS.items():
        c = lsq(Ftr[cols].values, ytr.values)
        q = qconf(np.abs(yte.values - pred(c, Fte[cols].values)))
        out["mft"][k] = {"cols": cols, "coef": c.tolist(), "q": q}
        c2 = lsq(Ft[cols].values, yt.values)
        res = []
        for s in np.unique(g):
            m = g == s
            cs = lsq(Ft[cols].values[~m], yt.values[~m])
            res.append(np.abs(yt.values[m] - pred(cs, Ft[cols].values[m])))
        out["tub"][k] = {"cols": cols, "coef": c2.tolist(), "q": qconf(np.concatenate(res))}
    json.dump(out, open(f"{D}/frozen_calibration.json", "w"), indent=1)
    print(json.dumps({k: out["mft"][k] for k in ("ExTurb-C", "UCIQE+DynRange")}, indent=1))
    print(out["created_utc"])


if __name__ == "__main__":
    main()
