#!/bin/sh
set -x
cd "$(dirname "$0")"
python3 -W ignore export_syndl.py
for s in bsds_test km syndl bsds_train range; do python3 -W ignore compute.py $s bench/$s.csv; done
for s in uiqs uccs u45 euvp; do python3 -W ignore compute.py $s $s; done
python3 -W ignore compute.py robust bench/robust.csv
python3 -W ignore cnn_baseline.py train > results/cnn.log 2>&1
python3 -W ignore theory_exp.py t1 t2 t3 > results/theory.log 2>&1
python3 -W ignore ablation.py ablate > results/ablation.log 2>&1
python3 -W ignore ablation.py sens > results/sens.log 2>&1
python3 -W ignore exposure_test.py > results/exposure.log 2>&1
echo PIPELINE_DONE
