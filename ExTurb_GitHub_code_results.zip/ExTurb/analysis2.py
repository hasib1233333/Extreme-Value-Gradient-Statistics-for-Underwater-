import os
"""Range-aware inversion, dynamic plume survey and qualitative figures."""
import csv
import json
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import spearmanr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analysis import FIG, MAC, PAP, RES, col, fmt_sci, g550, load, mac  # noqa: E402
import analysis  # noqa: E402

import rangemodel  # noqa: E402

C = json.load(open(f"{RES}/range_constants.json"))


def c_hat(Tc, d):
    return rangemodel.invert(Tc, d, C["Ts"], C["beta"], C["kappa"])


def range_eval():
    rows = load("range")
    Tc = col(rows, "ExTurb_Tc")
    d = col(rows, "dmean")
    G = np.array([g550(r["water"], float(r["b550"]))[1] for r in rows])
    Gh = c_hat(Tc, d)
    # baseline: UDCP transmission inverted with the same range (t = e^{-G d})
    tu = -col(rows, "UDCP")  # stored negated
    Gu = -np.log(np.clip(tu, 1e-3, 1)) / d
    td = -col(rows, "DCP")
    Gd = -np.log(np.clip(td, 1e-3, 1)) / d
    out = {}
    for name, est in (("ExTurb", Gh), ("UDCP", Gu), ("DCP", Gd)):
        rel = np.abs(est - G) / G
        out[name] = dict(srocc=spearmanr(est, G)[0], medrel=float(np.median(rel)),
                         mae=float(np.mean(np.abs(est - G))))
    mac("RgExS", f"{out['ExTurb']['srocc']:.3f}")
    mac("RgExRel", f"{100 * out['ExTurb']['medrel']:.1f}")
    mac("RgExMAE", fmt_sci(out["ExTurb"]["mae"]))
    mac("RgUdS", f"{out['UDCP']['srocc']:.3f}")
    mac("RgUdRel", f"{100 * out['UDCP']['medrel']:.1f}")
    mac("RgDcS", f"{out['DCP']['srocc']:.3f}")
    mac("RgDcRel", f"{100 * out['DCP']['medrel']:.1f}")
    # by optical depth tercile
    q = np.quantile(G * d, [1 / 3, 2 / 3])
    for i, (lo, hi) in enumerate(((0, q[0]), (q[0], q[1]), (q[1], 1e9))):
        m = (G * d >= lo) & (G * d < hi)
        mac(f"RgRelT{i}", f"{100 * np.median(np.abs(Gh[m] - G[m]) / G[m]):.1f}")
    mac("RgQ1", f"{q[0]:.2f}")
    mac("RgQ2", f"{q[1]:.2f}")
    fig, axs = plt.subplots(1, 2, figsize=(4.6, 2.35))
    ax = axs[0]
    for w, mk, c in (("oceanic", "o", "0.65"), ("coastal", "s", "0.35"), ("harbor", "^", "0.0")):
        m = np.array([r["water"] == w for r in rows])
        ax.scatter(G[m], Gh[m], s=5, marker=mk, facecolors="none", edgecolors=c, lw=0.5, label=w)
    lim = [0, max(G.max(), np.nanpercentile(Gh, 99)) * 1.05]
    ax.plot(lim, lim, "k--", lw=0.6)
    ax.set_xlim(lim)
    ax.set_ylim(lim)
    ax.set_xlabel(r"true $c_{550}$ (m$^{-1}$)")
    ax.set_ylabel(r"$\hat c$ (m$^{-1}$)")
    ax.set_title(f"(a) ExTurb, SROCC {out['ExTurb']['srocc']:.2f}")
    ax = axs[1]
    ax.scatter(G, Gu, s=5, marker="o", facecolors="none", edgecolors="0.4", lw=0.5)
    ax.plot(lim, lim, "k--", lw=0.6)
    ax.set_xlim(lim)
    ax.set_ylim(0, max(lim[1], np.nanpercentile(Gu, 99)))
    ax.set_xlabel(r"true $c_{550}$ (m$^{-1}$)")
    ax.set_title(f"(b) UDCP inversion, SROCC {out['UDCP']['srocc']:.2f}")
    h, l = axs[0].get_legend_handles_labels()
    fig.tight_layout(w_pad=0.8, rect=(0, 0.07, 1, 1))
    fig.legend(h, l, loc="lower center", ncol=3, markerscale=1.8, bbox_to_anchor=(0.5, 0.0), frameon=False)
    fig.savefig(f"{FIG}/range.pdf")
    plt.close(fig)
    return out


def plume_eval():
    from stats_eval import auc
    fx = json.load(open(f"{RES}/plume_fixed.json"))
    ad = json.load(open(f"{RES}/plume_adaptive.json"))
    for tag, R in (("Fx", fx), ("Ad", ad)):
        b = np.array([r["b550"] for r in R])
        Tc = np.array([r["Tc"] for r in R])
        h = np.array([r["h"] for r in R])
        rep = np.array([r["rep"] for r in R])
        c = np.array([g550("coastal", v)[1] for v in b])
        ch = c_hat(Tc, h)
        mac(f"Pl{tag}S", f"{spearmanr(Tc, b)[0]:.3f}")
        mac(f"Pl{tag}GS", f"{spearmanr(ch, c)[0]:.3f}")
        mac(f"Pl{tag}Rel", f"{100 * np.median(np.abs(ch - c) / c):.1f}")
        # single-point calibration: shift T_s so that the first 8 frames (clear
        # background, reference transmissometer reading c0) are matched
        c0 = float(np.median(c[:8]))
        Tpred0 = float(np.median(rangemodel.model(c0 * h[:8], C["Ts"], C["beta"], C["kappa"])))
        dT = float(np.median(Tc[:8])) - Tpred0
        chc = rangemodel.invert(Tc - dT, h, C["Ts"], C["beta"], C["kappa"])
        mac(f"Pl{tag}RelCal", f"{100 * np.median(np.abs(chc - c) / c):.1f}")
        mac(f"Pl{tag}ShiftCal", f"{dT:.2f}")
        mac(f"Pl{tag}Rep", f"{np.mean(rep):.3f}")
        mac(f"Pl{tag}Swath", f"{np.mean([r['swath'] for r in R]):.2f}")
        mac(f"Pl{tag}N", str(len(R)))
        bad = rep < 0.1
        mac(f"Pl{tag}Bad", f"{100 * np.mean(bad):.1f}")
        mac(f"Pl{tag}GateAUC", f"{auc(Tc[bad], Tc[~bad]):.3f}")
        if tag == "Fx":
            fx_cal = chc
    bfx = np.array([r["b550"] for r in fx])
    thr = np.quantile(bfx, 0.75)
    for tag, R in (("Fx", fx), ("Ad", ad)):
        b = np.array([r["b550"] for r in R])
        rep = np.array([r["rep"] for r in R])
        hi = b > thr
        mac(f"Pl{tag}RepHi", f"{np.mean(rep[hi]):.3f}")
        mac(f"Pl{tag}RepLo", f"{np.mean(rep[~hi]):.3f}")
    mac("nPlume", str(len(fx) + len(ad)))
    Tfx = np.array([r["Tc"] for r in fx])
    mac("PlAUC", f"{auc(Tfx[bfx > thr], Tfx[bfx <= thr]):.3f}")
    mac("PlBthr", f"{thr:.2f}")
    # ---------------- figure
    Cf = np.load(f"{RES}/plume_final.npy")
    fig = plt.figure(figsize=(7.16, 2.55))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.0, 1.55, 1.2])
    ax = fig.add_subplot(gs[0])
    im = ax.imshow(np.minimum(Cf, 3.0), cmap="Greys", origin="lower", extent=[0, 160, 0, 160])
    xs = [r["x"] for r in fx]
    ys = [r["y"] for r in fx]
    ax.plot(xs, ys, color=analysis.ACCENT, lw=0.6)
    ax.plot(xs[0], ys[0], "o", color=analysis.ACCENT, ms=3)
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_title("(a) final plume and survey track")
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.02)
    cb.set_label(r"$b_{550}$ (m$^{-1}$)", fontsize=6)
    cb.ax.tick_params(labelsize=6)
    ax = fig.add_subplot(gs[1])
    t = np.arange(len(fx))
    c = np.array([g550("coastal", r["b550"])[1] for r in fx])
    ax.plot(t, c, "k-", lw=1.0, label=r"true $c_{550}$")
    ax.plot(t, fx_cal, color="0.5", ls="--", lw=0.8, marker=".", ms=2, label=r"ExTurb $\hat c$ (1-point cal.)")
    ax.set_xlabel("frame index (25 s apart)")
    ax.set_ylabel(r"$c_{550}$ (m$^{-1}$)")
    ax.set_title("(b) along-track beam attenuation")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2, fontsize=6.5, frameon=False)
    ax.set_ylim(0, 3.9)
    ax = fig.add_subplot(gs[2])
    for R, mk, col_, lab in ((fx, "o", "0.0", "fixed $h=2.5$ m"), (ad, "^", "0.55", "adaptive $h$")):
        ax.scatter([r["Tc"] for r in R], [r["rep"] for r in R], s=6, marker=mk, facecolors="none",
                   edgecolors=col_, lw=0.5, label=lab)
    ax.set_xlabel(r"ExTurb $T_c$")
    ax.set_ylabel("ORB repeatability")
    ax.set_title("(c) $T_c$ as a frame-quality gate")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2, fontsize=6.5, frameon=False, markerscale=1.5)
    fig.tight_layout(w_pad=0.6)
    fig.savefig(f"{FIG}/plume.pdf")
    plt.close(fig)


def qualitative():
    """Real UIQS examples (one per grade) and a BSDS render sweep, with ExTurb outputs."""
    from PIL import Image
    ui = load("uiqs")
    rng = np.random.default_rng(3)
    fig, axs = plt.subplots(2, 5, figsize=(7.16, 3.3))
    for gi, g in enumerate("ABCDE"):
        cand = [r for r in ui if int(float(r["grade"])) == gi]
        r = cand[rng.integers(len(cand))]
        ax = axs[0, gi]
        ax.imshow(Image.open(r["file"]).convert("RGB"))
        ax.set_title(f"UIQS grade {g}", fontsize=7)
        ax.set_xlabel(f"$T_c$={float(r['ExTurb_Tc']):.2f}, $\\hat\\sigma_b$={float(r['ExTurb_sigma']):.2f}",
                      fontsize=6.5)
        ax.set_xticks([])
        ax.set_yticks([])
    km = load("km")
    from scipy.stats import kendalltau as _kt
    taus = {}
    for sc in sorted(set(int(float(r["scene"])) for r in km)):
        rr = [r for r in km if int(float(r["scene"])) == sc]
        taus[sc] = _kt([float(r["ExTurb"]) for r in rr], [float(r["b550"]) for r in rr])[0]
    med_scene = sorted(taus, key=lambda k: taus[k])[len(taus) // 2]  # scene with median within-scene tau
    mac("QualScene", str(med_scene))
    mac("QualTau", f"{taus[med_scene]:.2f}")
    bs = [r for r in km if int(float(r["scene"])) == med_scene]
    bs = sorted(bs, key=lambda r: float(r["b550"]))
    for j, r in enumerate([bs[i] for i in (0, 2, 4, 6, 7)]):
        ax = axs[1, j]
        ax.imshow(Image.open(r["file"]).convert("RGB"))
        ax.set_title(f"$b_{{550}}$={float(r['b550']):g} m$^{{-1}}$", fontsize=7)
        ax.set_xlabel(f"$T_c$={float(r['ExTurb_Tc']):.2f}, $\\hat\\sigma_b$={float(r['ExTurb_sigma']):.2f}",
                      fontsize=6.5)
        ax.set_xticks([])
        ax.set_yticks([])
    for a in axs.ravel():
        a.grid(False)
    fig.subplots_adjust(left=0.01, right=0.99, top=0.93, bottom=0.08, wspace=0.05, hspace=0.42)
    fig.savefig(f"{FIG}/qualitative.pdf")
    plt.close(fig)


def theory_extra():
    t2 = json.load(open(f"{RES}/theory_t2.json"))
    key = {}
    for o in t2:
        key.setdefault((o["scene"], o["b"], o["d"]), {})[o["gain"]] = o["Tc"]
    lo = np.array([abs(v[0.5] - v[1.0]) for v in key.values()])
    hi = np.array([abs(v[1.5] - v[1.0]) for v in key.values()])
    bs = np.array([k[1] for k in key])
    mac("TbGainLo", fmt_sci(float(np.median(lo))))
    mac("TbGainLoP95", fmt_sci(float(np.percentile(lo, 95))))
    mac("TbGainHi", fmt_sci(float(np.median(hi))))
    mac("TbGainHiClear", fmt_sci(float(np.median(hi[bs <= 0.1]))))
    mac("TbGainHiTurbid", fmt_sci(float(np.median(hi[bs >= 1.0]))))
    t3 = json.load(open(f"{RES}/theory_t3.json"))
    xi = np.array([r["xi_pwm"] for r in t3["rows"]])
    mac("TcXiMed", f"{np.median(xi):.2f}")
    t1 = json.load(open(f"{RES}/theory_t1.json"))
    d = {}
    for o in t1:
        d.setdefault((o["trial"], o["sigma"]), {})[o["amp"]] = o["sigma_hat"]
    spread_hi = np.median([abs(v[1.0] - v[0.3]) / v[1.0] for v in d.values()])
    mac("TaAmpSpreadHi", f"{100 * spread_hi:.1f}")


def exposure_eval():
    import analysis as A
    with open(f"{RES}/exposure_uiqs.csv") as f:
        rows = list(csv.DictReader(f))
    y = np.array([float(r["grade"]) for r in rows])
    L = []
    out = {}
    for m in A.METHODS:
        o = np.array([float(r[m + "_orig"]) for r in rows])
        e = np.array([float(r[m + "_exp"]) for r in rows])
        out[m] = (spearmanr(o, y)[0], spearmanr(e, y)[0], spearmanr(o, e)[0])
    best_stab = max(v[2] for v in out.values())
    best_e = max(v[1] for v in out.values())
    for m in A.METHODS:
        a, b, c = out[m]
        tb = f"{100 * b:.1f}"
        tc = f"{100 * c:.1f}"
        if b == best_e:
            tb = r"\textbf{" + tb + "}"
        if c == best_stab:
            tc = r"\textbf{" + tc + "}"
        L.append(f"{A.LABEL.get(m, m)} & {100 * a:.1f} & {tb} & {100 * (b - a):+.1f} & {tc} \\\\")
    with open(f"{PAP}/tab_exposure_rows.tex", "w") as f:
        f.write("\n".join(L))
    for m in ("ExTurb", "Tenengrad", "LapVar", "UCIQE", "PCD", "DynRange", "RMSC"):
        mac(f"Exp{m}Stab", f"{out[m][2]:.3f}")
        mac(f"Exp{m}Drop", f"{out[m][1] - out[m][0]:+.3f}")
        mac(f"Exp{m}After", f"{out[m][1]:.3f}")
    json.dump(out, open(f"{RES}/exposure_summary.json", "w"))


if __name__ == "__main__":
    # keep macros produced by analysis.py and add ours
    import re
    old = open(f"{PAP}/results_macros.tex").read()
    for k, v in re.findall(r"R@([A-Za-z0-9]+)\\endcsname\{(.*)\}\n", old):
        MAC.setdefault(k, v)
    what = sys.argv[1:] or ["range", "plume", "qual", "exposure", "theory"]
    if "theory" in what:
        theory_extra()
    if "exposure" in what:
        exposure_eval()
    if "range" in what:
        print(range_eval())
    if "plume" in what:
        plume_eval()
    if "qual" in what:
        qualitative()
    analysis.write_macros()
    print({k: MAC[k] for k in MAC if k.startswith(("Rg", "Pl"))})
