import pickle,csv,os,numpy as np
from PIL import Image
os.makedirs('bench/syndl',exist_ok=True)
data=pickle.load(open('results/syndl.pkl','rb'))
rows=[]
for i,(I,b,w,dm) in enumerate(data):
    fn=f'bench/syndl/{i//8:03d}_{i%8}.png'
    Image.fromarray((np.clip(I,0,1)*255+0.5).astype(np.uint8)).save(fn)
    rows.append([fn,'syndl',i//8,b,w,dm,'deadleaves'])
with open('bench/syndl.csv','w',newline='') as f:
    wr=csv.writer(f);wr.writerow(['file','set','scene','b550','water','dmean','source']);wr.writerows(rows)
print(len(rows))
