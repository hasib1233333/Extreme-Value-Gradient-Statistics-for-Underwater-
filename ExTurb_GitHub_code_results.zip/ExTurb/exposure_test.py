"""Exposure-invariance test on real UIQS images.

Each of 1000 randomly chosen UIQS photographs is re-exposed with a random gain
g ~ LogUniform(0.4, 1.6) applied in linear light (then clipped and re-encoded
to 8-bit sRGB), mimicking auto-exposure changes between frames. For every
method we report (i) SROCC with the visibility grade before and after
re-exposure and (ii) the rank stability, SROCC between the scores of the
original and the re-exposed image set.
"""
import csv
import json

import numpy as np
from joblib import Parallel, delayed
from PIL import Image

from baselines import metric_suite
from compute import frozen_params
from datasets import load_rgb, uiqs_items
from exturb import exturb
from render import to_linear, to_srgb

RES = "results"


def one(path, g):
    img = load_rgb(path, 512)
    lin = np.clip(to_linear(img) * g, 0, 1)
    img2 = np.round(to_srgb(lin) * 255) / 255.0
    p, lam = frozen_params()
    out = {}
    for tag, im in (("orig", img), ("exp", img2)):
        r = exturb(im, p)
        out[f"ExTurb_{tag}"] = r["T_c"] + lam * np.log(r["sigma_b"] + 0.25)
        for k, fn in metric_suite().items():
            out[f"{k}_{tag}"] = float(fn(im))
    return out


if __name__ == "__main__":
    rng = np.random.default_rng(7)
    items = uiqs_items()
    sel = sorted(rng.choice(len(items), 1000, replace=False))
    gains = np.exp(rng.uniform(np.log(0.4), np.log(1.6), len(sel)))
    res = Parallel(n_jobs=2, batch_size=8)(delayed(one)(items[i][0], g) for i, g in zip(sel, gains))
    rows = [{"file": items[i][0], "grade": items[i][1], "gain": float(g), **r} for i, g, r in zip(sel, gains, res)]
    with open(f"{RES}/exposure_uiqs.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print("done", len(rows))
