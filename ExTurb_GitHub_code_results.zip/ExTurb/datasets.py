"""Benchmark construction. All renders are deterministic given the seed.

Physics-based semi-synthetic sets (exact ground truth b550):
  SynDL      dead-leaves scenes (used ONLY for hyper-parameter selection)
  BSDS-UW    BSDS500 natural scenes rendered underwater
  KM-UW      Kodak24 + McMaster18 high-resolution scenes rendered underwater
Real underwater sets (ordinal / categorical labels):
  UIQS       RUIE visibility grades A..E (3630 images)
  UCCS       RUIE colour-cast classes (300 images)
  U45        haze / green / blue categories (45 images)
  EUVP-p     paired distorted vs. reference samples (FUnIE-GAN release)
"""
from __future__ import annotations

import glob
import io as _io
import os

import numpy as np
from PIL import Image
from skimage import io

from deadleaves import dead_leaves
from render import WATERS, RenderCfg, render, synthetic_range, to_linear, to_srgb

GIT = "data/gitdata"
RUIE = f"{GIT}/Realworld-Underwater-Image-Enhancement-RUIE-Benchmark"
B_LEVELS = np.array([0.05, 0.10, 0.20, 0.35, 0.50, 0.75, 1.00, 1.50])


def load_rgb(path, long_side=None):
    im = Image.open(path).convert("RGB")
    if long_side is not None and max(im.size) > long_side:
        f = long_side / max(im.size)
        im = im.resize((round(im.width * f), round(im.height * f)), Image.LANCZOS)
    return np.asarray(im, dtype=np.float64) / 255.0


def camera_out(lin, jpeg_q=None):
    """Linear -> sRGB 8-bit (optionally JPEG), back to float."""
    s = (to_srgb(lin) * 255 + 0.5).astype(np.uint8)
    if jpeg_q is not None:
        buf = _io.BytesIO()
        Image.fromarray(s).save(buf, "JPEG", quality=int(jpeg_q))
        s = np.asarray(Image.open(buf).convert("RGB"))
    return s.astype(np.float64) / 255.0


def render_sample(J_srgb, rng, b550, water, dmean=None, gain=None, noise=None,
                  jpeg_q=None, depth=None, layers=4):
    H, W = J_srgb.shape[:2]
    J = to_linear(J_srgb)
    if depth is None:
        lo = 0.8 if dmean is None else max(0.3, dmean - 1.2)
        hi = 4.0 if dmean is None else dmean + 1.2
        depth = synthetic_range(H, W, rng, lo, hi)
    gain = rng.uniform(0.7, 1.3) if gain is None else gain
    noise = rng.uniform(0.003, 0.012) if noise is None else noise
    cfg = RenderCfg(res_scale=max(H, W) / 512, layers=layers)
    I = render(J, depth, WATERS[water], b550, cfg, rng=rng, noise_sigma=noise, gain=gain)
    return camera_out(I, jpeg_q), depth


# ------------------------------------------------------------- scene lists
def bsds_paths(split):
    return sorted(glob.glob(f"{GIT}/BSDS500/BSDS500/data/images/{split}/*.jpg"))


def km_paths():
    return sorted(glob.glob(f"{GIT}/FFDNet/testsets/Kodak24/*")) + \
        sorted(glob.glob(f"{GIT}/FFDNet/testsets/McMaster/*"))


def uiqs_items():
    out = []
    for gi, g in enumerate("ABCDE"):
        for f in sorted(glob.glob(f"{RUIE}/UIQS/{g}/*")):
            out.append((f, gi))
    return out


def uccs_items():
    out = []
    for ci, c in enumerate(["blue", "blue-green", "green"]):
        for f in sorted(glob.glob(f"{RUIE}/UCCS/{c}/*")):
            out.append((f, ci))
    return out


def u45_items():
    out = []
    for c in ["haze", "green", "blue"]:
        for f in sorted(glob.glob(f"{GIT}/underwater-test-dataset-U45-/upload/U45/{c}/*")):
            out.append((f, c))
    return out


def euvp_pairs():
    A = sorted(glob.glob(f"{GIT}/FUnIE-GAN/data/test/A/*"))
    B = {os.path.basename(p): p for p in glob.glob(f"{GIT}/FUnIE-GAN/data/test/GTr_A/*")}
    return [(a, B[os.path.basename(a)]) for a in A if os.path.basename(a) in B]


def utts_paths():
    return sorted(glob.glob(f"{RUIE}/UTTS/pic_*/JPEGImages/*"))


def syndl_scene(seed, size=384):
    rng = np.random.default_rng(10_000 + seed)
    img = dead_leaves(size, size, rng, edge_sigma=rng.uniform(0.4, 1.4),
                      alpha=rng.uniform(2.6, 3.4), color=bool(rng.random() < 0.8))
    # random scene contrast compression around mid-grey
    k = rng.uniform(0.35, 1.0)
    return np.clip(0.5 + k * (img - 0.5), 0, 1)
