import json,urllib.request,os
from huggingface_hub import hf_hub_download, HfApi
api=HfApi(); rid='bhowmikabhimanyu/seathru-dataset'
files=api.list_repo_files(rid,repo_type='dataset')
out=[]
for s in ['D1','D2','D3','D4','D5']:
    imgs=sorted(f for f in files if f.startswith(f'{s}/{s}/linearPNG/'))
    deps=sorted(f for f in files if f.startswith(f'{s}/{s}/depth'))
    print(s,len(imgs),len(deps),imgs[:2],deps[:2],flush=True)
    dmap={os.path.basename(d).split('_',1)[1].rsplit('.',1)[0]:d for d in deps}
    pairs=[(i,dmap.get(os.path.basename(i).rsplit('.',1)[0].split('_')[-1])) for i in imgs]
    pairs=[(i,d) for i,d in pairs if d]
    if not pairs:
        # fallback: match by suffix number
        pairs=[(i,dmap[k]) for i in imgs for k in dmap if k in os.path.basename(i)]
    print(' matched',len(pairs),flush=True)
    step=max(1,len(pairs)//12)
    for i,d in pairs[::step][:12]:
        for f in (i,d):
            hf_hub_download(rid,f,repo_type='dataset',local_dir='data/seathru')
    print('done',s,flush=True)
