"""Revision 2, comment 2: how often is the blur inversion valid, and does using it help?

Valid means 1 < rho < s2/s1 (= 2). For each set we report the valid fraction by
turbidity level and by scene type, and compare three variants of the frozen index:
  all-image   T_c + lam*ln(sigma_b + sigma*), invalid -> sigma term = ln(sigma*)  (published)
  valid-only  the same index evaluated only on images with a valid inversion
  weighted    T_c + lam*w*[ln(sigma_b + sigma*) - ln(sigma*)],
              w = clip((s2/s1 - rho)/(s2/s1 - 1), 0, 1)  (soft reliability weight)
and T_c alone. Writes results/revision/validity_*.csv/json.
"""
import json

import numpy as np
import pandas as pd
from scipy.stats import kendalltau, spearmanr

RES = "results"
REAL = "real_data"
OUT = f"{RES}/revision"
LAM, SST, RMAX = 0.5, 0.25, 2.0

SETS = {
    "BSDS-UW test": (f"{RES}/scores_bsds_test.csv", "b550", "scene", "b550", "water"),
    "KM-UW": (f"{RES}/scores_km.csv", "b550", "scene", "b550", "water"),
    "Range-UW": (f"{RES}/scores_range.csv", "c550", "scene", None, "water"),
    "UIQS (real)": (f"{RES}/scores_uiqs.csv", "grade", None, "grade", None),
    "TUB (real)": (f"{REAL}/TUB_scores.csv", "ntu", "group", "stage", None),
    "MFT Test (real)": (f"{REAL}/MFT_test_scores.csv", "ntu", None, "level", "group"),
    "MFT Train (real)": (f"{REAL}/MFT_train_scores.csv", "ntu", None, "level", "group"),
}


def variants(d):
    tc, rho, sb = d.ExTurb_Tc.values, d.ExTurb_rho.values, d.ExTurb_sigma.values
    valid = (rho > 1) & (rho < RMAX)
    w = np.clip((RMAX - rho) / (RMAX - 1), 0, 1)
    blur = np.where(valid, np.log(sb + SST) - np.log(SST), 0.0)
    return valid, {"T_c only": tc, "all-image (published)": tc + LAM * blur,
                   "reliability-weighted": tc + LAM * w * blur}


def within(x, y, g):
    v = [kendalltau(x[g == k], y[g == k])[0] for k in np.unique(g) if (g == k).sum() > 2]
    return float(np.nanmean(v)) if v else np.nan


def main():
    rows, frac = [], {}
    for name, (f, ycol, gcol, lvcol, typecol) in SETS.items():
        d = pd.read_csv(f)
        if name.startswith("UIQS"):
            pass
        y = d[ycol].values.astype(float)
        valid, V = variants(d)
        g = d[gcol].values if gcol else None
        for k, x in V.items():
            rows.append(dict(set=name, variant=k, n=len(y), SROCC=spearmanr(x, y)[0],
                             within=within(x, y, g) if g is not None else np.nan))
        # valid-only
        m = valid
        if m.sum() > 10:
            for k in ("T_c only", "all-image (published)"):
                rows.append(dict(set=name, variant=f"valid-only: {k}", n=int(m.sum()),
                                 SROCC=spearmanr(V[k][m], y[m])[0],
                                 within=within(V[k][m], y[m], g[m]) if g is not None else np.nan))
        info = {"overall": float(valid.mean())}
        if lvcol:
            lv = d[lvcol]
            if lvcol in ("b550",):
                info["by_level"] = {f"{k:g}": float(valid[lv == k].mean()) for k in sorted(lv.unique())}
            else:
                info["by_level"] = {str(k): float(valid[lv == k].mean()) for k in sorted(lv.unique())}
        else:
            t = pd.qcut(d[ycol], 3, labels=["low", "mid", "high"])
            info["by_level"] = {str(k): float(valid[t == k].mean()) for k in ["low", "mid", "high"]}
        if typecol:
            info["by_type"] = {str(k): float(valid[d[typecol] == k].mean()) for k in sorted(d[typecol].unique())}
        if gcol:
            pf = pd.Series(valid).groupby(d[gcol].values).mean()
            info["per_scene_valid_quartiles"] = [float(q) for q in pf.quantile([0.25, 0.5, 0.75])]
        frac[name] = info
    T = pd.DataFrame(rows)
    T.to_csv(f"{OUT}/validity_variants.csv", index=False)
    json.dump(frac, open(f"{OUT}/validity_fraction.json", "w"), indent=1)
    pd.set_option("display.width", 200)
    print(T.round(3).to_string())
    print(json.dumps(frac, indent=1))


if __name__ == "__main__":
    main()
