# ExTurb: Extreme Value Gradient Statistics for Underwater Turbidity Estimation

Code, per-image results and data for the manuscript

> **Extreme Value Gradient Statistics for Underwater Turbidity Estimation and Their Validation in Real Water**
> Md Hasibuzzaman and Chan-Yun Yang
> Dept. of Electrical Engineering, College of Electrical Engineering and Computer Science, National Taipei University, New Taipei City, Taiwan
> Submitted to *IEEE Journal of Oceanic Engineering*, 2026 (under review).

## Abstract

Few underwater vehicles carry a turbidity meter, yet nearly every vehicle carries a camera. We study turbidity cues computed from the extreme values of locally normalised image gradients and summarised by a closed-form generalised extreme value fit. The resulting contrast index is exactly invariant to a common camera gain. Under stated assumptions it separates into scene, forward-scatter and veiling-light terms, and the ratio of the fitted locations at two scales gives the width of blurred edges. This inversion fails for about half of natural images, which are then flagged as invalid. On 1315 tank images and 1080 held-out fish images with turbidity measured in nephelometric turbidity units, the training-free index follows turbidity closely when only the water changes (Spearman rank correlation 8.10 × 10⁻¹) but not when the scene changes. With three calibrated coefficients the cues reach 8.36 × 10⁻¹ on the tank data and 5.38 × 10⁻¹ on an untouched hold-out split, among the leading methods but below a pair of simple contrast statistics, and they give the lowest median turbidity error when transferred from the tank to the fish images. A Type A uncertainty evaluation attributes 92% of the error variance to the scene and agrees with distribution-free prediction intervals. Upper percentiles of the same gradients outperform the fitted location, so the cues are best used on underwater vehicles as coarse indicators of water and image quality. Attenuation estimates are validated only in simulation.

**Keywords:** Underwater imaging; Turbidity; Extreme value theory; Autonomous underwater vehicles; Measurement uncertainty

## Quick start

```python
from skimage import io
from exturb import exturb            # see exturb.py for the full signature and outputs
img = io.imread("frame.png") / 255.0
out = exturb(img)                    # dict with T_c, rho, sigma_b (valid flag in sigma_valid), GEV scale and shape
print(out)
```
The frozen parameters (N_w = 512, s1 = 1.5, s2 = 3.0, B = 32, s_w = 8, epsilon = 10⁻³, lambda = 0.5) were chosen on synthetic dead-leaves images only.
For NTU estimates, apply the three ExTurb-C coefficients `coef = [a1, a2, a0]` in `frozen_calibration.json` (key `mft`, fitted on MFT Train): ln NTU = a1·T_c + a2·ln rho + a0. The key `q` is the 90% split-conformal half-width in ln NTU, so the interval is NTU·e^(±q).
Recalibrate them for a new camera, site or turbidity range.

## Paper figures

| Manuscript | File in `paper_figures/` |
|---|---|
| Fig. 1 Overview | `overview.pdf` |
| Fig. 2 Processing chain | `flow.pdf` |
| Fig. 3 Checks of the analytical claims | `theory.pdf` |
| Fig. 4 Factorial simulation of the probe ratio | `sim_rho.pdf` |
| Fig. 5 Tests of assumptions A1 and A2 | `psf_error.pdf` |
| Fig. 6 Scores on BSDS-UW | `scatter_bsds.pdf` |
| Fig. 7 Validation against measured turbidity | `real_ntu.pdf` |
| Fig. 8 Learning curves | `learning_curves.pdf` |
| Fig. 9 Robustness | `robust.pdf` |
| Fig. 10 Range-aware attenuation | `range.pdf` |
| Fig. 11 AUV plume survey | `plume.pdf` |
| Fig. S1 Sensitivity, Fig. S2 Qualitative examples | `sensitivity.pdf`, `qualitative.jpg` |

## Files

| File | Purpose |
|---|---|
| `exturb.py` | The estimator (Algorithm 1): Weber-normalised gradient maxima, PWM GEV fit, `T_c`, probe ratio, `sigma_b` |
| `render.py` | Physically based underwater renderer (Jaffe–McGlamery, spectral IOPs, Poisson forward-scatter PSF, depth layering) |
| `deadleaves.py` | Dead-leaves scene generator (SynDL) |
| `baselines.py` | UCIQE, UIQM, DCP, UDCP, dynamic range, RMS contrast, Tenengrad, Laplacian variance, entropy, PCD |
| `datasets.py`, `build_sets.py` | Benchmark construction (BSDS-UW, KM-UW, Robust-UW, Range-UW) |
| `tune_syndl.py` | Parameter selection on SynDL only |
| `compute.py` | Runs every method on a set and caches scores |
| `cnn_baseline.py` | Supervised CNN-R baseline |
| `theory_exp.py` | Numerical checks of Propositions 1–3 and GEV adequacy |
| `ablation.py` | Ablation and sensitivity |
| `exposure_test.py` | Exposure-invariance test on real UIQS images |
| `plume_sim.py` | Dynamic AUV survey through an advection–diffusion sediment plume |
| `analysis.py`, `analysis2.py`, `stats_eval.py` | Tables, figures, bootstrap/Holm/Friedman statistics, LaTeX macros |
| `run_real_ntu.py` | Scores every method on TUB, MFT (and TURBID); reads `av_turbidity.csv` and `Multimodal Metadata.xlsx` automatically |
| `real_calib.py` | Train-only calibration (ExTurb-C), protocols P1–P3, paired bootstrap + Holm |
| `real_ref.py` | Scene-referenced estimation on TUB; split-conformal NTU intervals |
| `syn_revision.py` | Revision experiments: PSF-approximation error map, edge types, camera pipeline, full GEV ablation, conformal ĉ |
| `real_figs.py`, `make_rev_tex.py` | Revision figures, tables and LaTeX macros |
| `real_data/` | Per-image scores of all methods on TUB (1315), MFT Train (4320), MFT Test (540) and MFT Eva (540), features, calibration and derived results |
| `real_data/revision/` | Results behind the validity, transfer, feature-family, learning-curve, identifiability, abstention and uncertainty analyses |
| `frozen_calibration.json` | Frozen ExTurb-C coefficients and conformal quantile, fixed before MFT Eva was processed |
| `paper_figures/` | Figures of the manuscript (PDF) and of the supplementary material |
| `paper_results/` | Every number reported in the manuscript, as LaTeX macros generated by the scripts |

## Data used

* Clear scenes: BSDS500 (`github.com/BIDS/BSDS500`), Kodak24 and McMaster (test sets bundled in `github.com/cszn/FFDNet`).
* Real underwater: RUIE (`github.com/dlut-dimt/Realworld-Underwater-Image-Enhancement-RUIE-Benchmark`), U45 (`github.com/IPNUISTlegal/underwater-test-dataset-U45-`), EUVP samples (`github.com/xahidbuffon/FUnIE-GAN`, `data/test`).
* Measured-turbidity sets: TUB (`huggingface.co/datasets/vapaau/TUB`), MFT (IEEE Dataport doi:10.21227/gd5d-ns10; mirror `huggingface.co/datasets/mieraehh/5_Malaysian_Fish_Species_in_Turbid_Water`). TURBID (`amandaduarte.com.br/turbid`) was not obtained.

## Reproduce

```bash
pip install numpy scipy scikit-image scikit-learn matplotlib joblib pillow phasepack torch openpyxl
python tune_syndl.py                    # parameter selection (writes exturb_params.json)
python build_sets.py bsds; python build_sets.py km; python build_sets.py robust; python build_sets.py range
./pipeline.sh                           # scores, CNN, theory checks, ablation, sensitivity
python exposure_test.py
python plume_sim.py fixed; python plume_sim.py adaptive <target>
python analysis.py; python analysis2.py # tables, figures and paper/results_macros.tex
```
Paths at the top of some scripts point to the folders used during development; change them to your local folders.

## Run on real turbidimeter data

```bash
python run_real_ntu.py --tub_dir data/tub                         # NTU from av_turbidity.csv
python run_real_ntu.py --mft_dir data/mft --mft_split Train       # NTU from Multimodal Metadata.xlsx
python run_real_ntu.py --mft_dir data/mft --mft_split Test
python real_calib.py real_data; python real_ref.py real_data      # calibration, significance, intervals
```
Rename the MFT outputs to `MFT_train_scores.csv` and `MFT_test_scores.csv` after each split, as in `real_data/`.


## Citation

If you use this code, please cite the paper (the reference will be updated after publication):

```bibtex
@article{hasibuzzaman2026exturb,
  author  = {Hasibuzzaman, Md and Yang, Chan-Yun},
  title   = {Extreme Value Gradient Statistics for Underwater Turbidity Estimation and Their Validation in Real Water},
  journal = {IEEE Journal of Oceanic Engineering},
  note    = {Submitted},
  year    = {2026}
}
```

## Contact

Md Hasibuzzaman (corresponding author), hsbuzzaman@gmail.com
Chan-Yun Yang, cyyang@mail.ntpu.edu.tw, cyyang.research@gmail.com
