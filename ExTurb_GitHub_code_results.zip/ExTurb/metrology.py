"""Metrological characterisation of ExTurb-C on TUB (leave-one-scene-out) and MFT.
Uncertainty components in ln NTU, sensitivity, resolution, linearity by range."""
import json, numpy as np, pandas as pd
from scipy.stats import spearmanr
R="/home/claude/real"
ft=pd.read_csv(f"{R}/features_TUB.csv"); fm=pd.read_csv(f"{R}/features_MFT.csv")
def X(d): a=np.log(d["mu_1.5"].values); b=np.log(d["mu_3"].values); return np.c_[-a, a-b]
def fit(Xm,y): return np.linalg.lstsq(np.c_[Xm,np.ones(len(Xm))],y,rcond=None)[0]
def pred(c,Xm): return np.c_[Xm,np.ones(len(Xm))]@c
out={}
# --- TUB LOSO predictions
ft=ft.copy(); ft["y"]=np.log(ft.ntu); ft["p"]=np.nan
for g in ft.group.unique():
    m=ft.group==g; c=fit(X(ft[~m]),ft.y[~m]); ft.loc[m,"p"]=pred(c,X(ft[m]))
ft["r"]=ft.p-ft.y
out["TUB_srocc"]=spearmanr(ft.p,ft.y)[0]
# components (ln NTU): camera = within (scene,stage) SD across cameras; scene = SD of (scene,stage) mean residual
grp=ft.groupby(["group","stage"])
u_cam=np.sqrt((grp.r.var(ddof=1)).mean())
mres=grp.r.mean()
u_scene=float(mres.std(ddof=1))
bias=float(ft.r.mean())
u_tot=float(ft.r.std(ddof=1))
out.update(u_cam=float(u_cam),u_scene=u_scene,bias=bias,u_tot=u_tot,u_comb=float(np.sqrt(u_cam**2+u_scene**2)))
# within-scene sensitivity of T_c and of ExTurb-C output to ln NTU, and within-scene residual
Tc=-np.log(ft["mu_1.5"].values); ft["Tc"]=Tc
key=ft.group+"_"+ft.cam.astype(str)
yc=ft.y-ft.y.groupby(key).transform("mean"); tc=ft.Tc-ft.Tc.groupby(key).transform("mean"); pc=ft.p-ft.p.groupby(key).transform("mean")
sTc=float((tc*yc).sum()/(yc*yc).sum()); sP=float((pc*yc).sum()/(yc*yc).sum())
resid_w=pc-sP*yc; u_w=float(np.sqrt((resid_w**2).sum()/(len(yc)-key.nunique()-1)))
out.update(sens_Tc=sTc,sens_C=sP,u_within=u_w)
# resolution: smallest change in ln NTU detectable at ~95% within a fixed scene and camera: 2*sqrt(2)*u_within/sens
dln=2*np.sqrt(2)*u_w/sP; out.update(res_ln=float(dln),res_ratio=float(np.exp(dln)))
# by NTU range (terciles of stage): bias and spread
ft["band"]=pd.cut(ft.ntu,[0,10,40,1e9],labels=["<10","10-40",">40"])
out["TUB_band"]={str(b):dict(n=int(len(d)),bias=float(d.r.mean()),sd=float(d.r.std(ddof=1))) for b,d in ft.groupby("band",observed=True)}
out["TUB_ntu_range"]=[float(ft.ntu.min()),float(ft.ntu.max())]
# --- MFT: Train fit, Eva per level
tr,ev=fm[fm.split=="Train"],fm[fm.split=="Eva"]
c=fit(X(tr),np.log(tr.ntu)); r=pred(c,X(ev))-np.log(ev.ntu.values)
out["MFT_bias"]=float(r.mean()); out["MFT_sd"]=float(r.std(ddof=1))
out["MFT_level"]={int(l):dict(n=int((ev.level==l).sum()),ntu_med=float(ev.ntu[ev.level==l].median()),bias=float(r[(ev.level==l).values].mean()),sd=float(r[(ev.level==l).values].std(ddof=1))) for l in sorted(ev.level.unique())}
json.dump(out,open("/home/claude/real/metrology.json","w"),indent=1)
print(json.dumps(out,indent=1))
