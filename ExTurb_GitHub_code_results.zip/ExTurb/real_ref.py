"""Two further real-data analyses.

(1) Scene-referenced estimation on TUB. Each (scene, camera) sequence has a
    clearest frame (stage 1). Subtracting that frame's value removes the scene
    offset T_scene (Innovation A of the review, with turbidity instead of range
    varying). We fit ln(NTU) - ln(NTU_ref) = a * dX by least squares,
    leave-one-scene-out, for ExTurb T_c and for each baseline.
(2) Split-conformal NTU intervals. Absolute residuals of ln NTU from the
    calibration set give a 90 % interval; we report empirical coverage and
    median interval width on held-out data, for MFT (calibrate on a scene-free
    random half of Train, test on Test) and TUB (leave-one-scene-out).
"""
import json
import os
import sys

import numpy as np
import pandas as pd
from scipy.stats import kendalltau, spearmanr

D = sys.argv[1] if len(sys.argv) > 1 else "real_data"
OUT = os.path.join(D, "calib")
BASE = ["UCIQE", "UIQM", "DCP", "UDCP", "DynRange", "RMSC", "Tenengrad", "LapVar", "Entropy", "PCD"]
ALPHA = 0.10
RNG = np.random.default_rng(7)


def feats(df):
    f = pd.DataFrame({"Tc": df.ExTurb_Tc, "lnrho": np.log(df.ExTurb_rho)})
    for b in BASE:
        f[b] = df[b]
    return f


def lsq(X, y):
    A = np.c_[X, np.ones(len(X))]
    return np.linalg.lstsq(A, y, rcond=None)[0]


def pred(c, X):
    return np.c_[X, np.ones(len(X))] @ c


def scene_referenced(tub):
    tub = tub.copy()
    tub["seq"] = tub.group + "_c" + tub.cam.astype(str)
    F = feats(tub)
    ref = tub.groupby("seq").stage.transform("min") == tub.stage
    rows = []
    out = {}
    y = np.log(tub.ntu.values)
    yref = tub.seq.map(dict(zip(tub.seq[ref], y[ref.values]))).values
    for k in ["Tc"] + BASE:
        x = F[k].values
        xref = tub.seq.map(dict(zip(tub.seq[ref], x[ref.values]))).values
        dx, dy = x - xref, y - yref
        p = np.zeros(len(y))
        g = tub.group.values
        for s in np.unique(g):
            tr, te = (g != s) & ~ref.values, g == s
            a = np.dot(dx[tr], dy[tr]) / np.dot(dx[tr], dx[tr])   # through the origin
            p[te] = yref[te] + a * dx[te]
        m = ~ref.values
        ntu, pn = np.exp(y[m]), np.exp(p[m])
        within = np.nanmean([kendalltau(p[m][g[m] == s], y[m][g[m] == s])[0] for s in np.unique(g)])
        rows.append(dict(model=k, SROCC=spearmanr(p[m], y[m])[0], within=within,
                         medrel=float(np.median(np.abs(pn - ntu) / ntu)),
                         MAE=float(np.mean(np.abs(pn - ntu)))))
        out[k] = p
    return pd.DataFrame(rows), out, tub, ref


def conformal_mft(mtr, mte, cols):
    idx = RNG.permutation(len(mtr))
    fit_i, cal_i = idx[: len(idx) // 2], idx[len(idx) // 2:]
    Ftr, Fte = feats(mtr), feats(mte)
    ytr, yte = np.log(mtr.ntu.values), np.log(mte.ntu.values)
    c = lsq(Ftr[cols].values[fit_i], ytr[fit_i])
    r = np.abs(ytr[cal_i] - pred(c, Ftr[cols].values[cal_i]))
    q = np.quantile(r, np.ceil((len(r) + 1) * (1 - ALPHA)) / len(r))
    p = pred(c, Fte[cols].values)
    lo, hi = np.exp(p - q), np.exp(p + q)
    ntu = mte.ntu.values
    return dict(coverage=float(np.mean((ntu >= lo) & (ntu <= hi))),
                width_factor=float(np.exp(2 * q)), q=float(q),
                cov_by_level={int(L): float(np.mean(((ntu >= lo) & (ntu <= hi))[mte.level == L]))
                              for L in sorted(mte.level.unique())})


def conformal_tub_loso(tub, cols):
    F = feats(tub)
    y = np.log(tub.ntu.values)
    g = tub.group.values
    cover = np.zeros(len(y), bool)
    qs = []
    for s in np.unique(g):
        tr, te = g != s, g == s
        # residuals on training scenes by an inner leave-one-scene-out (jackknife+ style)
        res = []
        for s2 in np.unique(g[tr]):
            tr2, te2 = tr & (g != s2), g == s2
            c2 = lsq(F[cols].values[tr2], y[tr2])
            res.append(np.abs(y[te2] - pred(c2, F[cols].values[te2])))
        r = np.concatenate(res)
        q = np.quantile(r, min(1, np.ceil((len(r) + 1) * (1 - ALPHA)) / len(r)))
        c = lsq(F[cols].values[tr], y[tr])
        p = pred(c, F[cols].values[te])
        cover[te] = np.abs(y[te] - p) <= q
        qs.append(q)
    return dict(coverage=float(cover.mean()), width_factor=float(np.exp(2 * np.median(qs))),
                q=float(np.median(qs)))


def main():
    mtr = pd.read_csv(f"{D}/MFT_train_scores.csv")
    mte = pd.read_csv(f"{D}/MFT_test_scores.csv")
    tub = pd.read_csv(f"{D}/TUB_scores.csv")
    tab, preds, tub2, ref = scene_referenced(tub)
    tab.to_csv(f"{OUT}/tub_scene_referenced.csv", index=False)
    print(tab.round(3).sort_values("SROCC", ascending=False).to_string())
    m = ~ref.values
    pd.DataFrame({"ntu": tub2.ntu[m], "group": tub2.group[m], "Tc_ref": np.exp(preds["Tc"][m]),
                  "UCIQE_ref": np.exp(preds["UCIQE"][m])}).to_csv(f"{OUT}/tub_ref_pred.csv", index=False)
    conf = {}
    for name, cols in {"ExTurb-C": ["Tc", "lnrho"], "DynRange": ["DynRange"], "UCIQE": ["UCIQE"]}.items():
        conf[name] = {"MFT": conformal_mft(mtr, mte, cols), "TUB": conformal_tub_loso(tub, cols)}
    print(json.dumps(conf, indent=1))
    with open(f"{OUT}/conformal.json", "w") as f:
        json.dump(conf, f, indent=1)


if __name__ == "__main__":
    main()
