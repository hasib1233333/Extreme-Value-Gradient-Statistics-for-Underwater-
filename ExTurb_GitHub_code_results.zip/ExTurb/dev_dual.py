import csv,numpy as np,sys
from scipy import ndimage as ndi
from scipy.stats import spearmanr
from joblib import Parallel,delayed
from datasets import load_rgb
from exturb import exturb,ExTurbParams,gev_pwm,block_maxima,luminance,resize_long
from analysis import g550
import json
P=ExTurbParams(**{k:v for k,v in json.load(open('results/exturb_params.json')).items() if k!='lam'})
def feats(path):
    img=resize_long(load_rgb(path,512),512); L=luminance(img); Ls=ndi.gaussian_filter(L,P.s1)
    out={}
    for B in (16,32):
        hi=gev_pwm(block_maxima(Ls,B)).loc; lo=-gev_pwm(block_maxima(-Ls,B)).loc
        r=np.clip(lo/max(hi,1e-6),0,0.999); out[f'Tv{B}']=-np.log(1-r)
        # dark-channel version
        dc=ndi.gaussian_filter(img.min(axis=2),P.s1); mx=ndi.gaussian_filter(img.max(axis=2),P.s1)
        lo2=-gev_pwm(block_maxima(-dc,B)).loc; hi2=gev_pwm(block_maxima(mx,B)).loc
        out[f'Tvd{B}']=-np.log(1-np.clip(lo2/max(hi2,1e-6),0,0.999))
    r=exturb(img,P); out['Tc']=r['T_c']; out['sb']=r['sigma_b']
    return out
for name in sys.argv[1:]:
    R=list(csv.DictReader(open(f'bench/{name}.csv')))
    F=Parallel(n_jobs=2)(delayed(feats)(r['file']) for r in R)
    json.dump([{**{k:r[k] for k in ('file','b550','water','dmean','scene')},**f} for r,f in zip(R,F)],open(f'results/dev_{name}.json','w'))
    y=np.array([float(r['b550']) for r in R]); d=np.array([float(r['dmean']) for r in R])
    G=np.array([g550(r['water'],float(r['b550']))[0] for r in R])
    for k in F[0]:
        x=np.array([f[k] for f in F]); print(name,k,round(spearmanr(x,y)[0],3),round(spearmanr(x,G*d)[0],3))
    Tc=np.array([f['Tc'] for f in F]); sb=np.array([f['sb'] for f in F])
    for k in ('Tv16','Tv32','Tvd16','Tvd32'):
        Tv=np.array([f[k] for f in F])
        for w in (0.25,0.5,0.75):
            for lam in (0,0.5):
                x=(1-w)*Tc+w*Tv+lam*np.log(sb+0.25)
                print(name,k,'w',w,'lam',lam,round(spearmanr(x,y)[0],3),round(spearmanr(x,G*d)[0],3))
